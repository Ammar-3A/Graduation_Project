import { useState, useEffect, useRef } from "react";
import { useNavigate } from 'react-router-dom';
import AuthForm from './components/AuthForm';

const BASE_URL = "http://127.0.0.1:8000";

export default function App() {
  const navigate = useNavigate();
  const messagesEndRef = useRef(null);
  const getToken = () => localStorage.getItem("token");

  const [isLoggedIn, setIsLoggedIn] = useState(!!getToken());
  
  const [messages, setMessages] = useState(() => {
    const savedMessages = localStorage.getItem("chat_history");
    return savedMessages ? JSON.parse(savedMessages) : [{ sender: "bot", text: "Welcome to TUMB Chat!" }];
  });

  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [context, setContext] = useState(null);
  const [chatMode, setChatMode] = useState("rule");

  useEffect(() => {
    if (!getToken()) {
      setIsLoggedIn(false);
    }
  }, [navigate]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    localStorage.setItem("chat_history", JSON.stringify(messages));
  }, [messages]);

  const formatActionData = (actionData) => {
    if (!actionData) return null;
    
    if (actionData.item_name && actionData.status === "success") {
      return `Post Created Successfully!\n\nItem: ${actionData.item_name}\nPrice: ${actionData.price} SAR\nCategory: ${actionData.category}\nID: ${actionData.id}`;
    }
    
    if (actionData.posts) {
      if (actionData.posts.length === 0) return "No posts found matching your criteria.";
      const postList = actionData.posts.map(p => `- ${p.item_name} (${p.price} SAR) [ID: ${p.post_id || p.id}]`).join('\n');
      return `Found ${actionData.count} post(s):\n\n${postList}`;
    }

    if (actionData.order_id && actionData.post_name) {
      return `Purchase Order Created!\n\nOrder ID: ${actionData.order_id}\nPost: ${actionData.post_name}\nPrice: ${actionData.price} SAR\nStatus: ${actionData.status}\n\nCheck your profile to view order details.`;
    }

    if (actionData.best_choice) {
      return `Comparison Results:\n\nBest Choice: ${actionData.best_choice.item_name}\nReason: ${actionData.best_choice.reason}`;
    }
    
    if (actionData.recommendations) {
      const recs = actionData.recommendations.map((p, i) => 
        `${i + 1}. ${p.item_name}\n   Price: ${p.price} SAR\n   Category: ${p.category}\n   ID: ${p.post_id || p.id}`
      ).join('\n\n');
      return `Recommendations (${actionData.based_on}):\n\n${recs}`;
    }
    
    if (actionData.report_id) {
      return `Report #${actionData.report_id} submitted successfully for Post ID: ${actionData.item_id}`;
    }
    
    return null;
  };

  const handleAuthSuccess = (msg) => {
    setIsLoggedIn(true);
    setMessages([{ sender: "bot", text: msg || "Logged in successfully." }]);
  };

  const sendMessage = async (textOverride = null, contextOverride = null) => {
    const text = (typeof textOverride === 'string' ? textOverride : input).trim();
    
    if (!text || loading) return;

    const token = getToken();
    const currentContext = contextOverride || context;

    if (text.toLowerCase() === "cancel") {
      if (currentContext) {
        setContext(null);
        setMessages(prev => [...prev, { sender: "user", text }, { sender: "bot", text: "Process cancelled." }]);
        fetch(`${BASE_URL}/chat`, {
          method: "POST",
          headers: { 
            "Content-Type": "application/json", 
            "Authorization": `Bearer ${token}` 
          },
          body: JSON.stringify({ message: "cancel", context: currentContext })
        });
      } else {
        setMessages(prev => [...prev, { sender: "user", text }, { sender: "bot", text: "No active process to cancel." }]);
      }
      setInput("");
      return;
    }

    if (text.toLowerCase() === "logout") {
      localStorage.removeItem("token");
      localStorage.removeItem("chat_history");
      setIsLoggedIn(false);
      setContext(null);
      setMessages([{ sender: "bot", text: "Logged out successfully." }]);
      setInput("");
      return;
    }

    setMessages((prev) => [...prev, { sender: "user", text }]);
    
    if (!textOverride) setInput("");
    setLoading(true);
    
    const history = messages.map(m => ({
      role: m.sender === "user" ? "user" : "assistant",
      content: m.text
    }));
    history.push({ role: "user", content: text });

    try {
        const response = await fetch(`${BASE_URL}/chat`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Authorization": `Bearer ${token}`,
            },
            body: JSON.stringify({ message: text, context: currentContext, mode: chatMode, history }),
        });

        if (response.status === 401 || response.status === 403) {
            localStorage.removeItem("token");
            localStorage.removeItem("chat_history");
            setIsLoggedIn(false);
            setContext(null);
            alert("Session expired. Please log in again.");
            return;
        }

        const data = await response.json();

        if (!response.ok) {
            setMessages(prev => [...prev, { sender: "bot", text: `Error: ${data.message || "An error occurred"}` }]);
            return;
        }

        setContext(data.context);
        
        if (data.messages && data.messages.length > 0) {
            data.messages.forEach((msg, i) => {
                setTimeout(() => {
                    setMessages(prev => [...prev, { sender: "bot", text: msg }]);
                }, i * 500);
            });
        }

        const formattedResult = formatActionData(data.data);
        if (formattedResult) {
            setTimeout(() => {
                setMessages(prev => [...prev, { sender: "bot", text: formattedResult }]);
            }, (data.messages?.length || 0) * 550);
        }
        
    } catch (error) {
        setMessages(prev => [...prev, { sender: "bot", text: "Connection error. Please try again." }]);
    } finally {
        setLoading(false);
    }
  };

  if (!isLoggedIn) return <AuthForm onSuccess={handleAuthSuccess} />;

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-50 p-4">
      
      <div className="w-full max-w-3xl bg-white shadow-md rounded-lg overflow-hidden flex flex-col h-[90vh]">
        
        <div className="bg-white border-b border-gray-200 px-6 py-4 flex justify-between items-center">
          <div className="flex flex-col">
            <div className="flex items-center gap-3">
              <h1 className="text-2xl font-semibold text-gray-800">TUMB</h1>
              <button
                onClick={() => setChatMode(prev => prev === "rule" ? "llm" : "rule")}
                className={`px-3 py-1 text-xs rounded-full font-medium transition-colors border ${
                  chatMode === "llm" 
                    ? "bg-purple-100 text-purple-700 border-purple-200" 
                    : "bg-blue-100 text-blue-700 border-blue-200"
                }`}
              >
                {chatMode === "llm" ? "LLM Agent" : "Rule Based"}
              </button>
            </div>
            {context && (
              <div className="mt-1">
                <span className="text-xs text-gray-500 block">
                  Active Flow: {context.flow_key}
                </span>

                <pre className="mt-2 max-h-40 overflow-auto text-[10px] text-gray-600 bg-gray-50 border border-gray-200 rounded p-2">
                  {JSON.stringify(context, null, 2)}
                </pre>
              </div>
            )}
          </div>
          
          <button 
            onClick={() => navigate('/profile')} 
            className="px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 rounded transition border border-gray-200"
          >
            Profile
          </button>
        </div>
        
        <div className="flex-1 overflow-y-auto p-6 space-y-3 bg-white">
          {messages.map((msg, i) => (
            <div key={i} className={`flex ${msg.sender === "user" ? "justify-end" : "justify-start"}`}>
              <div className={`max-w-[80%] px-4 py-3 rounded text-sm whitespace-pre-line ${
                msg.sender === "user" 
                  ? "bg-blue-500 text-white" 
                  : "bg-gray-100 text-gray-800 border border-gray-200"
              }`}>
                {msg.text}
              </div>
            </div>
          ))}
          {loading && <div className="text-xs text-gray-400 ml-2">Typing...</div>}
          <div ref={messagesEndRef} />
        </div>
        
        <div className="p-4 bg-white border-t border-gray-200">
          <div className="flex gap-2">
            <input 
              className="flex-1 border border-gray-300 rounded px-4 py-2 text-sm focus:outline-none focus:border-blue-400" 
              placeholder={context ? "Continue or type 'cancel'..." : "Type a message..."}
              value={input} 
              onChange={(e) => setInput(e.target.value)} 
              onKeyDown={(e) => e.key === "Enter" && sendMessage()}
              disabled={loading}
            />
            <button 
              onClick={() => sendMessage()} 
              className="bg-blue-500 text-white px-6 py-2 rounded text-sm hover:bg-blue-600 disabled:opacity-50 transition"
              disabled={loading}
            >
              Send
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}