import { create } from 'zustand';
import { User } from '../api/types';

interface AppState {
  // SESSION STATE (Aligned with Backend)
  sessionUserId: string | null;
  activeUser: User | null;

  // Selectors
  isLoggedIn: () => boolean;
  isAdmin: () => boolean;

  // AUTH
  setCurrentUser: (user: User | null) => void;
  logout: () => void;

  // AUTH/PROFILE ACTIONS
  updateMyProfile: (updates: Partial<User>) => void;
}

// H-2/M-5: Simplified — backend always returns a single `name` field
export const getFullName = (user: any) => user?.name || '';

export const useAppStore = create<AppState>((set, get) => ({
  sessionUserId: null,
  activeUser: null,

  isLoggedIn: () => !!get().activeUser,
  isAdmin: () => !!get().activeUser?.isAdmin,

  setCurrentUser: (user) => set({
    activeUser: user,
    sessionUserId: user ? user.id : null
  }),

  logout: () => set({
    activeUser: null,
    sessionUserId: null
  }),

  updateMyProfile: (updates) => {
    const activeUser = get().activeUser;
    if (activeUser) {
      set({ activeUser: { ...activeUser, ...updates } });
    }
  },
}));
