import client from '../client';
import { ENDPOINTS } from '../endpoints';
import { ChatResponse } from '../types';

export const chatService = {
  async postChat(message: string, mode: string = 'rule', history: Array<{role: string, content: string}> = []): Promise<ChatResponse> {
    const response = await client.post(ENDPOINTS.CHAT, { message, mode, history });
    return response.data;
  },

  async loadMore(actionName: string, lastId: number | null, filters: Record<string, any>): Promise<any> {
    const response = await client.post(ENDPOINTS.LOAD_MORE, {
      action_name: actionName,
      last_id: lastId,
      filters: filters || {}
    });
    return response.data;
  }
};
