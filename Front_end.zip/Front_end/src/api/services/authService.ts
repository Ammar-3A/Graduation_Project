import client from '../client';
import { ENDPOINTS } from '../endpoints';
import * as SecureStore from 'expo-secure-store';
import { AuthResponse, RegisterResponse, UserRegister } from '../types';

export const authService = {
  // Registers a new user with JSON payload
  register: async (userData: UserRegister): Promise<RegisterResponse> => {
    const response = await client.post(ENDPOINTS.REGISTER, userData);
    return response.data;
  },

  // Verifies OTP registration
  verifyRegistration: async (email: string, otp: string): Promise<AuthResponse> => {
    const response = await client.post(ENDPOINTS.VERIFY_REGISTRATION, { email, otp });
    return response.data;
  },

  // Resends OTP
  resendOtp: async (email: string): Promise<RegisterResponse> => {
    const response = await client.post(ENDPOINTS.RESEND_OTP, { email });
    return response.data;
  },

  // Logs in user with OAuth2 URLSearchParams payload and saves token
  loginUser: async (email: string, password: string): Promise<AuthResponse> => {
    const params = new URLSearchParams();
    params.append('username', email); // OAuth2 expects username field
    params.append('password', password);

    const response = await client.post(ENDPOINTS.LOGIN, params.toString(), {
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      }
    });

    if (response.data && response.data.access_token) {
      await SecureStore.setItemAsync('access_token', response.data.access_token);
    }
    return response.data;
  },

  // Logs in admin with OAuth2 payload and saves token
  loginAdmin: async (email: string, password: string): Promise<AuthResponse> => {
    const params = new URLSearchParams();
    params.append('username', email);
    params.append('password', password);

    const response = await client.post(ENDPOINTS.ADMIN_LOGIN, params.toString(), {
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      }
    });

    if (response.data && response.data.access_token) {
      await SecureStore.setItemAsync('access_token', response.data.access_token);
    }
    return response.data;
  },

  // Logs out user by removing token from SecureStore
  logout: async (): Promise<void> => {
    await SecureStore.deleteItemAsync('access_token');
  }
};
