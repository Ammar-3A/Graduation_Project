import client from '../client';
import { ENDPOINTS } from '../endpoints';

export const adminService = {
  getStats: async () => {
    const response = await client.get(ENDPOINTS.ADMIN_STATS);
    return response.data;
  },

  getMonitoring: async () => {
    const response = await client.get(ENDPOINTS.ADMIN_MONITORING);
    return response.data;
  },

  getUsers: async () => {
    const response = await client.get(ENDPOINTS.ADMIN_USERS);
    return response.data;
  },

  getPosts: async () => {
    const response = await client.get(ENDPOINTS.ADMIN_POSTS);
    return response.data;
  },

  getReports: async () => {
    const response = await client.get(ENDPOINTS.ADMIN_REPORTS);
    return response.data;
  },

  suspendUser: async (userId: number) => {
    const response = await client.post(`/admin/users/${userId}/suspend`);
    return response.data;
  },

  activateUser: async (userId: number) => {
    const response = await client.post(`/admin/users/${userId}/activate`);
    return response.data;
  },

  deletePost: async (postId: number) => {
    const response = await client.delete(`/admin/posts/${postId}`);
    return response.data;
  },

  resolveReport: async (reportId: number) => {
    const response = await client.post(ENDPOINTS.RESOLVE_REPORT(reportId));
    return response.data;
  },

  getAdminProfile: async (): Promise<{ id: number; name: string; email: string }> => {
    const response = await client.get(ENDPOINTS.ADMIN_PROFILE);
    return response.data;
  },
};
