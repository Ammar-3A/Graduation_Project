import client from '../client';
import { ENDPOINTS } from '../endpoints';
import { User } from '../types';

export const userService = {
  getUserProfile: async (): Promise<User> => {
    const response = await client.get(ENDPOINTS.USER_PROFILE);
    return response.data;
  }
};
