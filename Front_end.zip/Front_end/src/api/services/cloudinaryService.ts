import axios from 'axios';

const CLOUD_NAME = 'dccz03bkb';
const UPLOAD_PRESET = 'TUMB_upload';
const CLOUDINARY_URL = `https://api.cloudinary.com/v1_1/${CLOUD_NAME}/image/upload`;

interface CloudinaryResponse {
  secure_url: string;
  [key: string]: any;
}

export const cloudinaryService = {
  /**
   * Uploads an image to Cloudinary using FormData.
   * Handles React Native specific FormData requirements.
   * @param uri Local URI of the image from expo-image-picker
   * @returns The secure_url of the uploaded image
   */
  async uploadImage(uri: string): Promise<string> {
    const filename = uri.split('/').pop() || 'image.jpg';
    const match = /\.(\w+)$/.exec(filename);
    const type = match ? `image/${match[1]}` : `image`;

    const formData = new FormData();
    // In React Native, FormData requires an object with uri, name, and type for files
    formData.append('file', {
      uri,
      name: filename,
      type,
    } as any);
    formData.append('upload_preset', UPLOAD_PRESET);

    try {
      const response = await axios.post<CloudinaryResponse>(CLOUDINARY_URL, formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });

      if (response.data && response.data.secure_url) {
        return response.data.secure_url;
      } else {
        throw new Error('Cloudinary response did not contain secure_url');
      }
    } catch (error: any) {
      console.error('Cloudinary upload error:', error.response?.data || error.message);
      throw new Error('Failed to upload image to Cloudinary');
    }
  },
};
