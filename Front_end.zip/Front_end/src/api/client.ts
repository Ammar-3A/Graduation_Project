import axios, { AxiosError, AxiosResponse, InternalAxiosRequestConfig } from 'axios';
import * as SecureStore from 'expo-secure-store';
import { useAppStore } from '../store/useAppStore';

const client = axios.create({
  baseURL: 'http://10.0.2.2:8000/',
});

// Request interceptor: auto-attach Bearer token from SecureStore
client.interceptors.request.use(async (config: InternalAxiosRequestConfig) => {
  try {
    const token = await SecureStore.getItemAsync('access_token');
    if (token && config.headers) {
      config.headers.Authorization = `Bearer ${token}`;
    }
  } catch (error) {
    console.error('Error fetching token from SecureStore', error);
  }
  return config;
});

// Response interceptor: handles common errors and formats them for the UI
client.interceptors.response.use(
  (response: AxiosResponse) => response,
  async (error: AxiosError) => {
    // 1. Handle 401 Unauthorized
    if (error.response && error.response.status === 401) {
      try {
        await SecureStore.deleteItemAsync('access_token');
        useAppStore.getState().logout();
      } catch (e) {
        console.error('Error during 401 handling', e);
      }
    }

    // 2. Handle Timeout or Network errors
    if (error.code === 'ECONNABORTED' || !error.response) {
      const friendlyError = {
        ...error,
        message: 'The server is not responding. Please check your connection and try again.',
      };
      return Promise.reject(friendlyError);
    }

    return Promise.reject(error);
  }
);

export default client;