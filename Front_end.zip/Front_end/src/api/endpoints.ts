// Centralized API endpoint URL constants
export const ENDPOINTS = {
  LOGIN: '/auth/login',
  REGISTER: '/auth/register',
  VERIFY_REGISTRATION: '/auth/verify-registration',
  RESEND_OTP: '/auth/resend-otp',
  USER_PROFILE: '/auth/profile',
  CHAT: '/chat',
  LOAD_MORE: '/load-more',
  // Admin Endpoints
  ADMIN_LOGIN: '/admin/login',
  ADMIN_PROFILE: '/admin/profile',
  ADMIN_STATS: '/admin/stats',
  ADMIN_MONITORING: '/admin/monitoring',
  ADMIN_USERS: '/admin/users',
  ADMIN_POSTS: '/admin/posts',
  ADMIN_REPORTS: '/admin/reports',
  RESOLVE_REPORT: (id: number) => `/admin/reports/${id}/resolve`,
} as const;

export type EndpointKey = keyof typeof ENDPOINTS;
