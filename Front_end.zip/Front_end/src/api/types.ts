export interface User {
  id: string;
  email: string;
  name: string;
  phone_number?: string;
  interest?: string;
  isAdmin?: boolean;
  status?: 'active' | 'suspended';
}

export interface UserRegister {
  email: string;
  name: string;
  phone_number: string;
  password: string;
  interest: string;
}

export interface FlowState {
  flow_key: string;
  current_step: string;
  data: Record<string, any>;
}

export interface Post {
  id: number;
  post_id?: number; // legacy/consistency
  item_name: string;
  price: number;
  description: string;
  category: string;
  image?: string;
  seller_id?: string;
  status?: string;
}

export interface ChatResponse {
  status: string;
  messages?: string[];
  flow_state?: FlowState;
  data?: {
    action_name?: string;
    action_data?: any;
    [key: string]: any;
  };
}

export interface AuthResponse {
  message: string;
  access_token?: string;
}

export interface RegisterResponse {
  message: string;
  expires_in?: number;
}

export interface Order {
  id: string;
  post_id: number;
  post_name: string;
  price: number;
  status: string;
  seller_name?: string;
  seller_phone?: string;
  created_at?: string;
}
