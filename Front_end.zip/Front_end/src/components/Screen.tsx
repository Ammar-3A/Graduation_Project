import React from 'react';
import { View, StyleSheet, ViewProps } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { colors } from '../theme/colors';

interface ScreenProps extends ViewProps {
  children: React.ReactNode;
  safeArea?: boolean;
  safeTop?: boolean;
  safeBottom?: boolean;
}

export const Screen: React.FC<ScreenProps> = ({ 
  children, 
  safeArea = true, 
  safeTop = true,
  safeBottom = true,
  style, 
  ...props 
}) => {
  const insets = useSafeAreaInsets();
  return (
    <View
      style={[
        styles.container,
        safeArea && { 
          paddingTop: safeTop ? insets.top : 0, 
          paddingBottom: safeBottom ? insets.bottom : 0 
        },
        style,
      ]}
      {...props}
    >
      {children}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
});
