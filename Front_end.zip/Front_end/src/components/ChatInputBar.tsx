import React, { useState } from 'react';
import { View, TextInput, TouchableOpacity, StyleSheet, Platform } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import { colors } from '../theme/colors';
import { spacing } from '../theme/spacing';
import { typography } from '../theme/typography';
import { cloudinaryService } from '../api/services/cloudinaryService';
import { ActivityIndicator, Alert } from 'react-native';

export interface ChatInputBarProps {
  onSend: (text: string) => void;
  flowKey?: string;
  currentStep?: string;
}

export const ChatInputBar: React.FC<ChatInputBarProps> = ({ onSend, flowKey, currentStep }) => {
  const [text, setText] = useState('');
  const [isUploading, setIsUploading] = useState(false);
  const insets = useSafeAreaInsets();

  const isImageStep = (flowKey === 'create post' || flowKey === 'edit post') && currentStep === 'image';

  const handleSend = () => {
    if (text.trim()) {
      onSend(text.trim());
      setText('');
    }
  };

  const handlePickImage = async () => {
    const permissionResult = await ImagePicker.requestMediaLibraryPermissionsAsync();

    if (permissionResult.granted === false) {
      Alert.alert(
        "Access Denied",
        "You've refused to allow this app to access your photos! Please enable permissions in your settings to upload images.",
        [{ text: "OK" }]
      );
      return;
    }

    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ['images'],
      allowsEditing: true,
      quality: 1,
    })

    if (!result.canceled && result.assets && result.assets.length > 0) {
      const localUri = result.assets[0].uri;

      setIsUploading(true);
      try {
        const cloudinaryUrl = await cloudinaryService.uploadImage(localUri);
        onSend(cloudinaryUrl);
      } catch (error) {
        Alert.alert(
          "Upload Failed",
          "Could not upload the image. The process has been canceled."
        );
        onSend("cancel");
      } finally {
        setIsUploading(false);
      }
    }
  };

  const placeholderText = isImageStep
    ? "press here to Upload the image"
    : isUploading ? "Uploading image..." : "Ask TUMB Bot...";

  return (
    <View style={[styles.container, { paddingBottom: Math.max(insets.bottom, 0) }]}>
      <TouchableOpacity
        style={styles.inputWrapper}
        activeOpacity={isImageStep ? 0.7 : 1}
        onPress={isImageStep ? handlePickImage : undefined}
        disabled={isUploading}
      >
        <View pointerEvents={isImageStep ? 'none' : 'auto'} style={styles.flex1}>
          <TextInput
            style={[
              styles.input,
              (isUploading || isImageStep) && styles.disabledInput,
              isImageStep && styles.imageStepInput
            ]}
            placeholder={placeholderText}
            placeholderTextColor={isImageStep ? colors.primaryLight : colors.textSecondary}
            value={isImageStep ? "" : text}
            onChangeText={setText}
            multiline={!isImageStep}
            maxLength={500}
            onSubmitEditing={handleSend}
            editable={!isUploading && !isImageStep}
          />
        </View>
        {isUploading && (
          <View style={styles.uploadOverlay}>
            <ActivityIndicator color={colors.primaryLight} size="small" />
          </View>
        )}
      </TouchableOpacity>

      {!isImageStep && (
        <TouchableOpacity
          style={[styles.sendButton, (!text.trim() || isUploading) && styles.sendButtonDisabled]}
          onPress={handleSend}
          disabled={!text.trim() || isUploading}
        >
          <Ionicons name="send" size={20} color={text.trim() && !isUploading ? '#fff' : 'rgba(255,255,255,0.3)'} />
        </TouchableOpacity>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  keyboardAvoidingContainer: {
    width: '100%',
  },
  container: {
    flexDirection: 'row',
    padding: spacing.sm,
    backgroundColor: colors.background,
    borderTopWidth: 1,
    borderTopColor: colors.border,
    alignItems: 'center',
    gap: spacing.sm,
  },
  inputWrapper: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
  },
  flex1: {
    flex: 1,
  },
  uploadOverlay: {
    position: 'absolute',
    right: 16,
    top: 0,
    bottom: 0,
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 10,
  },
  input: {
    backgroundColor: colors.surfaceHighlight,
    borderRadius: 24,
    paddingHorizontal: spacing.lg,
    paddingTop: 14,
    paddingBottom: 14,
    ...typography.body,
    color: colors.text,
    maxHeight: 100,
    borderWidth: 1,
    borderColor: colors.border,
  },
  imageStepInput: {
    textAlign: 'center',
    borderColor: colors.primaryLight,
    borderWidth: 1,
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
  },
  sendButton: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  sendButtonDisabled: {
    opacity: 0.5,
  },
  sendIcon: {
    marginLeft: 4,
  },
  disabledButton: {
    opacity: 0.6,
  },
  disabledInput: {
    backgroundColor: 'rgba(255, 255, 255, 0.03)',
    borderColor: 'transparent',
  },
});
