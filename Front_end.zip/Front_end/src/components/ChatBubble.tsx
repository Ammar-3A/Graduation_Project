import React, { useState } from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity, ActivityIndicator } from 'react-native';
import { colors } from '../theme/colors';
import { typography } from '../theme/typography';
import { spacing } from '../theme/spacing';
import { ImageViewerModal } from './ImageViewerModal';

interface ChatBubbleProps {
  text: string;
  isOwn: boolean;
  senderName?: string;
}

export const ChatBubble: React.FC<ChatBubbleProps> = ({ text, isOwn, senderName }) => {
  const isImage = text.startsWith('http') || text.startsWith('file://');
  const [viewerVisible, setViewerVisible] = useState(false);
  const [imageLoading, setImageLoading] = useState(false);

  // (new) Skip rendering entirely when the bot sends an empty string (card-only message)
  if (!text && !isOwn) return null;

  return (
    <View style={[styles.container, isOwn ? styles.ownContainer : styles.otherContainer]}>
      {!isOwn && senderName && <Text style={styles.senderName}>{senderName.toUpperCase()}</Text>}

      {isImage ? (
        <>
          <TouchableOpacity onPress={() => setViewerVisible(true)} style={styles.imageBubble}>
            <View style={styles.imageWrapper}>
              <Image
                source={{ uri: text }}
                style={styles.chatImage}
                resizeMode="cover"
                onLoadStart={() => setImageLoading(true)}
                onLoadEnd={() => setImageLoading(false)}
              />
              {imageLoading && (
                <View style={styles.loadingOverlay}>
                  <ActivityIndicator color={colors.primaryLight} />
                </View>
              )}
            </View>
          </TouchableOpacity>
          <ImageViewerModal
            visible={viewerVisible}
            item={{ image: text }}
            onClose={() => setViewerVisible(false)}
            mode="image"
          />
        </>
      ) : (
        <View style={[styles.bubble, isOwn ? styles.ownBubble : styles.otherBubble]}>
          <Text style={[styles.text, isOwn ? styles.ownText : styles.otherText]}>
            {text}
          </Text>
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    marginVertical: spacing.xs,
    maxWidth: '80%',
    alignSelf: 'flex-start',
  },
  ownContainer: {
    alignSelf: 'flex-end',
  },
  otherContainer: {
    alignSelf: 'flex-start',
  },
  senderName: {
    ...typography.caption,
    color: colors.textSecondary,
    marginBottom: spacing.xs,
    marginLeft: spacing.sm,
  },
  bubble: {
    padding: spacing.md,
    borderRadius: 20,
  },
  ownBubble: {
    backgroundColor: colors.primary,
    borderBottomRightRadius: 4,
  },
  otherBubble: {
    backgroundColor: colors.surfaceHighlight,
    borderBottomLeftRadius: 4,
  },
  text: {
    ...typography.body,
    color: colors.text,
  },
  ownText: {
    color: '#ffffff',
  },
  otherText: {
    color: colors.text,
  },
  imageBubble: {
    borderRadius: 20,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: colors.border,
  },
  chatImage: {
    width: 200,
    height: 200,
    backgroundColor: colors.surfaceHighlight,
  },
  imageWrapper: {
    width: 200,
    height: 200,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0,0,0,0.05)',
    justifyContent: 'center',
    alignItems: 'center',
  },
});