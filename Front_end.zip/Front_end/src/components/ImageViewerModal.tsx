import { Ionicons } from '@expo/vector-icons';
import React from 'react';
import { Image, Modal, ScrollView, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { colors } from '../theme/colors';
import { spacing } from '../theme/spacing';
import { typography } from '../theme/typography';

const PLACEHOLDER = require('../images/placeholder.png');

interface ImageViewerModalProps {
  visible: boolean;
  item: any | null;
  onClose: () => void;
  mode?: 'full' | 'image';
}

const resolveImage = (item: any) => {
  const uri = item?.image || item?.images?.[0];
  if (!uri) return PLACEHOLDER;
  return { uri };
};

export const ImageViewerModal: React.FC<ImageViewerModalProps> = ({ visible, item, onClose, mode = 'full' }) => {
  const [fullscreen, setFullscreen] = React.useState(false);

  React.useEffect(() => {
    if (!visible) setFullscreen(false);
  }, [visible]);

  const imageSource = resolveImage(item);
  const title = item?.item_name || 'Unknown Item';
  const description = item?.description || 'Unknown Description';
  const hasSeller = !!(item?.seller_name);

  return (
    <Modal
      visible={visible}
      transparent={true}
      animationType={mode === 'image' ? 'fade' : 'slide'}
      onRequestClose={onClose}
    >
      {mode === 'image' ? (
        <TouchableOpacity
          style={styles.fullscreenOverlay}
          activeOpacity={1}
          onPress={onClose}
        >
          <Image source={imageSource} style={styles.fullscreenImage} resizeMode="contain" />
          <TouchableOpacity style={styles.closeButtonAbsolute} onPress={onClose}>
            <Ionicons name="close" size={24} color="#fff" />
          </TouchableOpacity>
          <Text style={styles.fullscreenHint}>Tap anywhere to close</Text>
        </TouchableOpacity>
      ) : (
        <>
          <Modal
            visible={fullscreen}
            transparent={false}
            animationType="fade"
            onRequestClose={() => setFullscreen(false)}
          >
            <TouchableOpacity
              style={styles.fullscreenOverlay}
              activeOpacity={1}
              onPress={() => setFullscreen(false)}
            >
              <Image source={imageSource} style={styles.fullscreenImage} resizeMode="contain" />
              <Text style={styles.fullscreenHint}>Tap anywhere to close</Text>
            </TouchableOpacity>
          </Modal>

          <TouchableOpacity style={styles.backdrop} activeOpacity={1} onPress={onClose} />

          {item && (
            <View style={styles.card}>
              <TouchableOpacity onPress={onClose} style={styles.closeButton}>
                <Ionicons name="close" size={22} color={colors.text} />
              </TouchableOpacity>

              <ScrollView
                contentContainerStyle={styles.scrollInside}
                showsVerticalScrollIndicator={false}
              >
                <TouchableOpacity onPress={() => setFullscreen(true)} activeOpacity={0.85}>
                  <Image source={imageSource} style={styles.image} resizeMode="cover" />
                  <View style={styles.enlargeHintRow}>
                    <Ionicons name="expand-outline" size={12} color="rgba(255,255,255,0.45)" />
                    <Text style={styles.imageTapHint}>Tap to enlarge</Text>
                  </View>
                </TouchableOpacity>

                <View style={styles.infoBox}>
                  <Text style={styles.titleText}>{title}</Text>
                  <Text style={styles.priceHighlight}>SAR {item?.price != null ? String(item.price) : ''}</Text>
                  <View style={styles.detailsRow}>
                    {item?.category && (
                      <View style={styles.pill}>
                        <Text style={styles.pillText}>{item.category}</Text>
                      </View>
                    )}
                    {item?.quantity != null && (
                      <View style={styles.pill}>
                        <Text style={styles.pillText}>Quantity: {String(item.quantity)}</Text>
                      </View>
                    )}
                  </View>
                  {description ? (
                    <>
                      <Text style={styles.descTitle}>Description</Text>
                      <Text style={styles.descText}>{description}</Text>
                    </>
                  ) : null}
                  {hasSeller && (
                    <View style={styles.sellerBox}>
                      <Text style={styles.sellerTitle}>Seller Info:</Text>
                      {item.seller_id && <Text style={styles.sellerRow}>Seller ID: {item.seller_id}</Text>}
                      {item.seller_name && <Text style={styles.sellerRow}>Seller name: {item.seller_name}</Text>}
                      {item.seller_phone && <Text style={styles.sellerRow}>Seller phone: {item.seller_phone}</Text>}
                      {item.seller_email && <Text style={styles.sellerRow}>Seller email: {item.seller_email}</Text>}
                    </View>
                  )}
                </View>
              </ScrollView>
            </View>
          )}
        </>
      )}
    </Modal>
  );
};

const styles = StyleSheet.create({
  backdrop: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: '#000',
  },
  card: {
    position: 'absolute',
    top: '10%',
    left: '5%',
    right: '5%',
    maxHeight: '82%',
    backgroundColor: '#1B2430',
    borderRadius: 20,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: '#2E3A4E',
    shadowColor: '#000',
    shadowOpacity: 0.5,
    shadowRadius: 20,
    elevation: 20,
  },
  closeButton: {
    position: 'absolute',
    top: 10,
    right: 10,
    zIndex: 10,
    padding: 6,
    backgroundColor: 'rgba(0,0,0,0.45)',
    borderRadius: 20,
  },
  scrollInside: {
    paddingBottom: 32,
  },
  image: {
    width: '100%',
    height: 210,
    backgroundColor: '#0D1117',
  },
  enlargeHintRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 10,
    paddingVertical: 4,
    backgroundColor: 'rgba(0,0,0,0.3)',
  },
  infoBox: {
    padding: spacing.lg,
  },
  titleText: {
    ...typography.h2,
    color: colors.text,
    marginBottom: spacing.xs,
  },
  priceHighlight: {
    ...typography.h3,
    color: colors.primaryLight,
    marginBottom: spacing.md,
  },
  detailsRow: {
    flexDirection: 'row',
    gap: spacing.sm,
    marginBottom: spacing.md,
  },
  pill: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.xs,
    borderRadius: 12,
  },
  pillText: {
    ...typography.caption,
    color: colors.text,
  },
  descTitle: {
    ...typography.body,
    fontWeight: 'bold',
    color: colors.textSecondary,
    marginBottom: spacing.xs,
  },
  descText: {
    ...typography.body,
    color: colors.text,
    lineHeight: 22,
  },
  sellerBox: {
    marginTop: spacing.md,
    padding: spacing.md,
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#2E3A4E',
  },
  sellerTitle: {
    ...typography.caption,
    color: colors.textSecondary,
    fontWeight: '700',
    marginBottom: spacing.sm,
    letterSpacing: 0.5,
  },
  sellerRow: {
    ...typography.body,
    color: colors.text,
    marginBottom: spacing.xs,
  },
  sellerMeta: {
    ...typography.caption,
    color: colors.textSecondary,
    marginTop: spacing.xs,
  },
  fullscreenOverlay: {
    flex: 1,
    backgroundColor: '#000',
    justifyContent: 'center',
    alignItems: 'center',
  },
  fullscreenImage: {
    width: '100%',
    height: '90%',
  },
  fullscreenHint: {
    ...typography.caption,
    color: 'rgba(255,255,255,0.4)',
    marginTop: spacing.md,
  },
  imageTapHint: {
    ...typography.caption,
    color: 'rgba(255,255,255,0.35)',
    textAlign: 'center',
    marginTop: 4,
    marginBottom: spacing.sm,
  },
  closeButtonAbsolute: {
    position: 'absolute',
    top: 40,
    right: 20,
    zIndex: 100,
    backgroundColor: 'rgba(0,0,0,0.5)',
    padding: 8,
    borderRadius: 20,
  },
});