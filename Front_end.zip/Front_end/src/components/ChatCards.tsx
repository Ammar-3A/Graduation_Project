import React, { useState } from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity } from 'react-native';
import { colors } from '../theme/colors';
import { typography } from '../theme/typography';
import { spacing } from '../theme/spacing';
import { Card } from './Card';
import { Ionicons } from '@expo/vector-icons';
import { ImageViewerModal } from './ImageViewerModal';

const PLACEHOLDER = require('../images/placeholder.png');


const resolveImage = (item: any) => {
  const uri = item?.image;
  if (!uri) return PLACEHOLDER;
  return { uri };
};

// ─────────────────────────────────────────────
// OrderSummaryCard
// ─────────────────────────────────────────────
export const OrderSummaryCard = ({ data }: { data: any }) => {
  return (
    <Card style={styles.cardContainer}>
      <View style={styles.cardHeader}>
        <Ionicons name="checkmark-circle" size={20} color={colors.success} />
        <Text style={styles.cardTitle}>Request Summary</Text>
      </View>
      <View style={styles.divider} />
      <Text style={styles.itemTitle}>{data.item_name} | #{data.post_id}</Text>
      <Text style={styles.itemDetail}>Price: SAR {data.price}</Text>
      <Text style={styles.itemDetail}>Quantity: {data.quantity}</Text>
      <View style={styles.divider} />
      <Text style={styles.sectionLabel}>Seller Contact</Text>
      <Text style={styles.itemDetail}>Name: {data.seller_name}</Text>
      <Text style={styles.itemDetail}>Phone: {data.seller_phone}</Text>
      <Text style={styles.itemDetail}>Email: {data.seller_email}</Text>
    </Card>
  );
};

// ─────────────────────────────────────────────
// ComparisonCard
// ─────────────────────────────────────────────
export const ComparisonCard = ({ data }: { data: any }) => {
  const item1 = data.post1 || data.item1;
  const item2 = data.post2 || data.item2;
  const bestId = data.best_choice?.id;
  const item1IsBest = item1?.id === bestId;
  const item2IsBest = item2?.id === bestId;
  const [viewerVisible, setViewerVisible] = useState(false);
  const [viewerMode, setViewerMode] = useState<'full' | 'image'>('full');
  const [selectedItem, setSelectedItem] = useState<any | null>(null);

  const handleOpenItem = (item?: any) => {
    if (!item) return;
    setSelectedItem(item);
    setViewerMode('full');
    setViewerVisible(true);
  };

  const handleOpenImage = (item?: any) => {
    if (!item) return;
    setSelectedItem(item);
    setViewerMode('image');
    setViewerVisible(true);
  };

  // M-5: Guard against missing comparison data (e.g., backend could only find 1 item)
  if (!item1 || !item2) {
    return (
      <View style={{ padding: spacing.md }}>
        <Text style={{ color: colors.textSecondary }}>Comparison data unavailable.</Text>
      </View>
    );
  }

  return (
    <>
      <View style={styles.compareWrapper}>
        <View style={styles.compareHeaderBox}>
          <Ionicons name="swap-horizontal" size={16} color={colors.primaryLight} />
          <Text style={styles.compareHeaderTitle}>COMPARISON TABLE</Text>
        </View>

        <View style={styles.compareTableGrid}>

          {/* Best Value Badge Row */}
          <View style={styles.gridRow}>
            <View style={[styles.gridCellHeader, styles.gridCellEmpty]} />
            <View style={styles.gridCell}>
              {item1IsBest && (
                <View style={styles.bestBadge}>
                  <Ionicons name="star" size={11} color="#FFD700" />
                  <Text style={styles.bestBadgeText}>BEST</Text>
                </View>
              )}
            </View>
            <View style={styles.gridCell}>
              {item2IsBest && (
                <View style={styles.bestBadge}>
                  <Ionicons name="star" size={11} color="#FFD700" />
                  <Text style={styles.bestBadgeText}>BEST</Text>
                </View>
              )}
            </View>
          </View>

          {/* Images Row */}
          <View style={styles.gridRow}>
            <View style={[styles.gridCellHeader, styles.gridCellEmpty]} />
            <View style={styles.gridCell}>
              {/* (fix) resolveImage instead of inline ternary */}
              <TouchableOpacity
                activeOpacity={0.8}
                onPress={() => handleOpenImage(item1)}
                style={[styles.compareImageContainer, item1IsBest && styles.bestImageBorder]}
              >
                <Image source={resolveImage(item1)} style={styles.compareImageImg} />
              </TouchableOpacity>
            </View>
            <View style={styles.gridCell}>
              <TouchableOpacity
                activeOpacity={0.8}
                onPress={() => handleOpenImage(item2)}
                style={[styles.compareImageContainer, item2IsBest && styles.bestImageBorder]}
              >
                <Image source={resolveImage(item2)} style={styles.compareImageImg} />
              </TouchableOpacity>
            </View>
          </View>

          {/* Item Name Row */}
          <View style={styles.gridRow}>
            <View style={styles.gridCellHeader}>
              <Text style={styles.gridRowLabel}>Item Name</Text>
            </View>
            <View style={styles.gridCell}>
              <Text style={styles.gridValueBold}>{item1.item_name || item1.title}</Text>
            </View>
            <View style={styles.gridCell}>
              <Text style={styles.gridValueBold}>{item2.item_name || item2.title}</Text>
            </View>
          </View>

          {/* Post ID Row */}
          <View style={styles.gridRow}>
            <View style={styles.gridCellHeader}>
              <Text style={styles.gridRowLabel}>Post ID</Text>
            </View>
            <View style={styles.gridCell}>
              <Text style={styles.gridValueItalic}>#{item1.id}</Text>
            </View>
            <View style={styles.gridCell}>
              <Text style={styles.gridValueItalic}>#{item2.id}</Text>
            </View>
          </View>

          {/* Price Row */}
          <View style={styles.gridRow}>
            <View style={styles.gridCellHeader}>
              <Text style={styles.gridRowLabel}>Price</Text>
            </View>
            <View style={styles.gridCell}>
              <Text style={styles.gridValueBlue}>{item1.price} SAR</Text>
            </View>
            <View style={styles.gridCell}>
              <Text style={styles.gridValueBlue}>{item2.price} SAR</Text>
            </View>
          </View>

          {/* Description Row */}
          <View style={styles.gridRow}>
            <View style={styles.gridCellHeader}>
              <Text style={styles.gridRowLabel}>Description</Text>
            </View>
            <View style={styles.gridCell}>
              <Text style={styles.gridValueItalic} numberOfLines={1}>
                {item1.description || 'No description available.'}
              </Text>
            </View>
            <View style={styles.gridCell}>
              <Text style={styles.gridValueItalic} numberOfLines={1}>
                {item2.description || 'No description available.'}
              </Text>
            </View>
          </View>

          {/* Category Row */}
          <View style={styles.gridRow}>
            <View style={styles.gridCellHeader}>
              <Text style={styles.gridRowLabel}>Category</Text>
            </View>
            <View style={styles.gridCell}>
              <View style={styles.categoryPill}>
                <Text style={styles.categoryPillText}>{item1.category}</Text>
              </View>
            </View>
            <View style={styles.gridCell}>
              <View style={styles.categoryPill}>
                <Text style={styles.categoryPillText}>{item2.category}</Text>
              </View>
            </View>
          </View>

          {/* Action Row */}
          <View style={[styles.gridRow, styles.gridRowLast]}>
            <View style={[styles.gridCellHeader, styles.gridCellEmpty]} />
            <View style={styles.gridCell}>
              <TouchableOpacity
                style={styles.gridButtonPrimary}
                onPress={() => handleOpenItem(item1)}
              >
                <Text style={styles.gridButtonTextWhite}>View</Text>
              </TouchableOpacity>
            </View>
            <View style={styles.gridCell}>
              <TouchableOpacity
                style={styles.gridButtonPrimary}
                onPress={() => handleOpenItem(item2)}
              >
                <Text style={styles.gridButtonTextWhite}>View</Text>
              </TouchableOpacity>
            </View>
          </View>

        </View>
      </View>

      <ImageViewerModal
        visible={viewerVisible}
        item={selectedItem}
        onClose={() => { setViewerVisible(false); setSelectedItem(null); }}
        mode={viewerMode}
      />
    </>
  );
};

// ─────────────────────────────────────────────
// SearchResultsCard
// ─────────────────────────────────────────────
export const SearchResultsCard = ({ results }: { results: any[] }) => {
  const [viewerVisible, setViewerVisible] = useState(false);
  const [viewerMode, setViewerMode] = useState<'full' | 'image'>('full');
  const [selectedItem, setSelectedItem] = useState<any | null>(null);

  const handleOpenItem = (item?: any) => {
    if (!item) return;
    setSelectedItem(item);
    setViewerMode('full');
    setViewerVisible(true);
  };

  const handleOpenImage = (item?: any) => {
    if (!item) return;
    setSelectedItem(item);
    setViewerMode('image');
    setViewerVisible(true);
  };

  const resolveName = (item: any) => item.item_name || 'Unknown Item';
  const resolveKey = (item: any, index: number) => `${item.id ?? item.request_id ?? index}-${index}`;

  return (
    <>
      <View style={styles.resultsContainer}>
        {(results || []).map((item, index) => (
          <Card key={resolveKey(item, index)} style={styles.resultItem}>
            <View style={styles.row}>
              {/* (fix) Tappable thumbnail — opens image preview modal */}
              <TouchableOpacity onPress={() => handleOpenImage(item)} activeOpacity={0.8}>
                <Image
                  source={resolveImage(item)}
                  style={styles.imageThumbSmall}
                />
              </TouchableOpacity>
              <View style={styles.infoCol}>
                <Text style={styles.itemTitle} numberOfLines={1}>{resolveName(item)}</Text>
                <Text style={styles.priceHighlight}>SAR {item.price}</Text>
                {item.quantity !== undefined && (
                  <Text style={styles.itemDetail}>Quantity: {item.quantity}</Text>
                )}
                {item.category && <Text style={styles.itemDetail}>{item.category}</Text>}
                {(item.id || item.post_id) && (
                  <Text style={styles.idLabel}>ID: {item.post_id || item.id}</Text>
                )}
              </View>
              <TouchableOpacity
                style={styles.viewButton}
                onPress={() => handleOpenItem(item)}
              >
                <Text style={styles.viewButtonText}>View</Text>
              </TouchableOpacity>
            </View>
          </Card>
        ))}
      </View>

      <ImageViewerModal
        visible={viewerVisible}
        item={selectedItem}
        onClose={() => { setViewerVisible(false); setSelectedItem(null); }}
        mode={viewerMode}
      />
    </>
  );
};

// ─────────────────────────────────────────────
// RequestsListCard
// ─────────────────────────────────────────────
export const RequestsListCard = ({ requests }: { requests: any[] }) => {
  const [viewerVisible, setViewerVisible] = useState(false);
  const [selectedItem, setSelectedItem] = useState<any | null>(null);

  return (
    <>
      <View style={styles.resultsContainer}>
        {(requests || []).map((req, index) => (
          <Card key={`req-${req.request_id ?? index}`} style={styles.requestCard}>
            <View style={styles.cardHeader}>
              <Ionicons name="receipt-outline" size={16} color={colors.primaryLight} />
              <Text style={styles.cardTitle}>{req.item_name || 'Unknown Item'}</Text>
            </View>
            <View style={styles.divider} />

            <View style={styles.requestMeta}>
              <Text style={styles.priceHighlight}>SAR {req.price}</Text>
              <View style={styles.requestPill}>
                <Text style={styles.pillTextSmall}>Quantity: {req.quantity}</Text>
              </View>
            </View>

            {req.created_at && (
              <Text style={styles.idLabel}>
                Ordered: {new Date(req.created_at).toLocaleDateString('en-US')}
              </Text>
            )}

            <View style={styles.divider} />
            <Text style={styles.sectionLabel}>SELLER CONTACT</Text>
            {req.seller_name && (
              <View style={styles.contactRow}>
                <Ionicons name="person-outline" size={13} color={colors.primaryLight} />
                <Text style={styles.contactText}>{req.seller_name}</Text>
              </View>
            )}
            {req.seller_phone && (
              <View style={styles.contactRow}>
                <Ionicons name="call-outline" size={13} color={colors.primaryLight} />
                <Text style={styles.contactText}>{req.seller_phone}</Text>
              </View>
            )}
            {req.seller_email && (
              <View style={styles.contactRow}>
                <Ionicons name="mail-outline" size={13} color={colors.primaryLight} />
                <Text style={styles.contactText}>{req.seller_email}</Text>
              </View>
            )}

            {req.post_desc && (
              <Text style={[styles.itemDetail, { marginTop: spacing.xs }]} numberOfLines={2}>
                {req.post_desc}
              </Text>
            )}

            <TouchableOpacity
              style={styles.viewButtonFull}
              onPress={() => { setSelectedItem(req); setViewerVisible(true); }}
            >
              <Text style={styles.viewButtonText}>View Details</Text>
            </TouchableOpacity>
          </Card>
        ))}
      </View>

      <ImageViewerModal
        visible={viewerVisible}
        item={selectedItem}
        onClose={() => { setViewerVisible(false); setSelectedItem(null); }}
      />
    </>
  );
};

// ─────────────────────────────────────────────
// ReportSuccessCard
// ─────────────────────────────────────────────
export const ReportSuccessCard = ({ data }: { data: any }) => (
  <Card style={[styles.cardContainer, styles.reportCard]}>
    <View style={styles.reportHeader}>
      <Ionicons name="shield-checkmark" size={28} color={colors.success} />
      <View style={styles.infoCol}>
        <Text style={styles.cardTitle}>Report Submitted</Text>
        <Text style={styles.itemDetail}>Thank you. Our team will review this report.</Text>
      </View>
    </View>
    {data?.report_id && <Text style={styles.idLabel}>Report ID: #{data.report_id}</Text>}
  </Card>
);

// ─────────────────────────────────────────────
// Styles
// ─────────────────────────────────────────────
const styles = StyleSheet.create({
  cardContainer: {
    backgroundColor: '#1B2430',
    borderColor: colors.border,
    padding: spacing.md,
    marginTop: spacing.sm,
    maxWidth: '90%',
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
  },
  cardTitle: {
    ...typography.h3,
    color: colors.text,
  },
  divider: {
    height: 1,
    backgroundColor: colors.border,
    marginVertical: spacing.sm,
  },
  itemTitle: {
    ...typography.h3,
    marginBottom: 4,
  },
  itemDetail: {
    ...typography.caption,
    color: colors.textSecondary,
    marginBottom: 2,
  },
  sectionLabel: {
    ...typography.caption,
    color: colors.text,
    fontWeight: '600',
    marginTop: spacing.xs,
    marginBottom: 4,
  },
  priceHighlight: {
    ...typography.body,
    fontWeight: 'bold',
    color: colors.primaryLight,
    marginBottom: 4,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  imageThumb: {
    width: 96,
    height: 96,
    borderRadius: 8,
    marginRight: spacing.md,
    backgroundColor: colors.surfaceHighlight,
  },
  imageThumbSmall: {
    width: 72,
    height: 72,
    borderRadius: 6,
    marginRight: spacing.sm,
    backgroundColor: colors.surfaceHighlight,
  },
  infoCol: {
    flex: 1,
  },
  idLabel: {
    ...typography.caption,
    color: colors.textSecondary,
    marginTop: spacing.xs,
    fontSize: 10,
  },
  compareWrapper: {
    backgroundColor: '#1E2532',
    borderRadius: 16,
    borderWidth: 1,
    borderColor: '#2E3A4E',
    overflow: 'hidden',
    marginTop: spacing.sm,
    maxWidth: '95%',
  },
  compareHeaderBox: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderBottomWidth: 1,
    borderBottomColor: '#2E3A4E',
  },
  compareHeaderTitle: {
    ...typography.caption,
    color: colors.text,
    fontWeight: 'bold',
    letterSpacing: 0.5,
  },
  bestBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 3,
    backgroundColor: 'rgba(255, 215, 0, 0.15)',
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#FFD700',
  },
  bestBadgeText: {
    ...typography.caption,
    color: '#FFD700',
    fontWeight: 'bold',
    fontSize: 10,
  },
  bestImageBorder: {
    borderWidth: 2,
    borderColor: '#FFD700',
  },
  compareTableGrid: {
    flexDirection: 'column',
  },
  gridRow: {
    flexDirection: 'row',
    borderBottomWidth: 1,
    borderBottomColor: '#2E3A4E',
  },
  gridRowLast: {
    borderBottomWidth: 0,
    paddingBottom: spacing.sm,
  },
  gridCellHeader: {
    width: 80,
    padding: spacing.sm,
    justifyContent: 'center',
    borderRightWidth: 1,
    borderRightColor: '#2E3A4E',
  },
  gridCellEmpty: {
    borderRightWidth: 1,
  },
  gridCell: {
    flex: 1,
    padding: spacing.sm,
    justifyContent: 'center',
    alignItems: 'center',
    borderRightWidth: 1,
    borderRightColor: '#2E3A4E',
  },
  gridRowLabel: {
    ...typography.caption,
    color: colors.textSecondary,
    fontWeight: '600',
  },
  gridValueBold: {
    ...typography.body,
    fontWeight: 'bold',
    color: colors.text,
    textAlign: 'center',
  },
  gridValueBlue: {
    ...typography.body,
    fontWeight: 'bold',
    color: colors.primaryLight,
  },
  gridValueItalic: {
    ...typography.caption,
    fontStyle: 'italic',
    color: colors.textSecondary,
    textAlign: 'center',
  },
  compareImageContainer: {
    width: 84,
    height: 84,
    borderRadius: 12,
    overflow: 'hidden',
    backgroundColor: '#fff',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 2,
  },
  compareImageImg: {
    width: '100%',
    height: '100%',
    resizeMode: 'contain',
  },
  categoryPill: {
    borderWidth: 1,
    borderColor: '#42506B',
    borderRadius: 12,
    paddingHorizontal: 12,
    paddingVertical: 4,
  },
  categoryPillText: {
    ...typography.caption,
    color: colors.textSecondary,
    fontSize: 10,
  },
  gridButtonPrimary: {
    backgroundColor: colors.primaryLight,
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.sm,
    borderRadius: 16,
    width: '100%',
    alignItems: 'center',
  },
  gridButtonTextWhite: {
    ...typography.caption,
    color: '#fff',
    fontWeight: 'bold',
  },
  resultsContainer: {
    gap: spacing.sm,
    marginTop: spacing.sm,
  },
  resultItem: {
    padding: spacing.sm,
    maxWidth: '90%',
  },
  viewButton: {
    backgroundColor: colors.primary,
    paddingHorizontal: spacing.sm,
    paddingVertical: 6,
    borderRadius: 12,
  },
  viewButtonText: {
    ...typography.caption,
    color: '#fff',
    fontWeight: 'bold',
  },
  requestCard: {
    padding: spacing.md,
    maxWidth: '95%',
    gap: 6,
  },
  requestMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
  },
  requestPill: {
    backgroundColor: 'rgba(255,255,255,0.08)',
    paddingHorizontal: spacing.sm,
    paddingVertical: 3,
    borderRadius: 10,
  },
  pillTextSmall: {
    ...typography.caption,
    color: colors.textSecondary,
    fontSize: 11,
  },
  contactRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
    marginTop: 4,
  },
  contactText: {
    ...typography.body,
    color: colors.text,
    fontSize: 13,
  },
  viewButtonFull: {
    backgroundColor: colors.primary,
    paddingVertical: 8,
    paddingHorizontal: spacing.md,
    borderRadius: 12,
    alignItems: 'center',
    marginTop: spacing.sm,
  },
  reportCard: {
    borderLeftWidth: 3,
    borderLeftColor: colors.success,
  },
  reportHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
  },
});