import React from 'react';
import { TouchableOpacity, View, Text, StyleSheet } from 'react-native';
import { colors } from '../theme/colors';
import { spacing } from '../theme/spacing';
import { typography } from '../theme/typography';
import { Ionicons } from '@expo/vector-icons';

export interface ChatActionCardProps {
  title: string;
  subtitle: string;
  icon: keyof typeof Ionicons.glyphMap;
  onPress: () => void;
  isPrimary?: boolean;
  isNew?: boolean;
}

export const ChatActionCard: React.FC<ChatActionCardProps> = ({ 
  title, 
  subtitle, 
  icon, 
  onPress, 
  isPrimary,
  isNew 
}) => {
  return (
    <TouchableOpacity 
      style={[
        styles.container, 
        isPrimary ? styles.containerPrimary : styles.containerDefault
      ]} 
      onPress={onPress}
      activeOpacity={0.8}
    >
      <View style={styles.leftContent}>
        <View style={styles.iconContainer}>
          <Ionicons name={icon} size={24} color={isPrimary ? colors.primary : colors.text} />
        </View>
        <View style={styles.textContainer}>
          <View style={styles.titleRow}>
            <Text style={[styles.title, isPrimary && styles.titlePrimary]}>{title}</Text>
            {isNew && (
              <View style={styles.newBadge}>
                <Text style={styles.newBadgeText}>NEW</Text>
              </View>
            )}
          </View>
          <Text style={[styles.subtitle, isPrimary && styles.subtitlePrimary]}>{subtitle}</Text>
        </View>
      </View>
      <Ionicons 
        name="chevron-forward" 
        size={20} 
        color={isPrimary ? '#FFFFFF' : colors.textSecondary} 
      />
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: spacing.md,
    borderRadius: 24,
    marginBottom: spacing.sm,
    borderWidth: 1,
    maxWidth: '90%', // Keep it looking like a chat bubble width
  },
  containerDefault: {
    backgroundColor: colors.surface,
    borderColor: colors.border,
  },
  containerPrimary: {
    backgroundColor: colors.primary, // Using primary color directly for the solid blue Action Card
    borderColor: colors.primary,
    shadowColor: colors.primary, // intense blue shadow
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 5,
  },
  leftContent: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  iconContainer: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: colors.surfaceHighlight, // lighter circle around the icon
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: spacing.md,
  },
  textContainer: {
    flex: 1,
  },
  titleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
    marginBottom: 2,
  },
  title: {
    ...typography.h3,
    color: colors.text,
  },
  titlePrimary: {
    color: '#ffffff',
  },
  subtitle: {
    ...typography.body,
    color: colors.textSecondary,
    fontSize: 13,
  },
  subtitlePrimary: {
    color: '#ffffff',
    opacity: 0.9,
  },
  newBadge: {
    backgroundColor: 'rgba(30, 136, 229, 0.2)', // Semi-transparent primary
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: colors.primary,
  },
  newBadgeText: {
    color: colors.primaryLight,
    fontSize: 10,
    fontWeight: 'bold',
  },
});
