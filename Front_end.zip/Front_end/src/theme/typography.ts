export const typography = {
  h1: { fontSize: 24, fontWeight: '700' as const, color: '#FFFFFF' },
  h2: { fontSize: 20, fontWeight: '600' as const, color: '#FFFFFF' },
  h3: { fontSize: 16, fontWeight: '600' as const, color: '#FFFFFF' },
  body: { fontSize: 14, fontWeight: '400' as const, color: '#9CA3AF' },
  caption: { fontSize: 12, fontWeight: '400' as const, color: '#9CA3AF' },
};
