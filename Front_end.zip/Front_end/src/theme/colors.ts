export const colors = {
  background: '#151A24', // deep navy background from UI
  surface: '#222B3B', // rounded cards and inputs
  surfaceHighlight: '#2A3446', 
  primary: '#1E88E5', // primary blue
  primaryLight: '#3A9DF2',
  text: '#FFFFFF',
  textSecondary: '#9CA3AF', // soft gray
  border: '#2E3A4E',
  danger: '#EF4444',
  success: '#10B981',
  warning: '#F5A623',
};
