import { useState } from 'react';
import { Keyboard } from 'react-native';
import { chatService } from '../api/services/chatService';
import { ChatResponse, Post, Order } from '../api/types';

export interface ChatMessage {
  id: string;
  text: string;
  isOwn: boolean;
  senderName?: string;
  cardType?: 'order_summary' | 'comparison' | 'search_results' | 'requests_list' | 'report_success' | 'quick_actions';
  cardData?: any;
}

// Manages conversational state machine and multi-step flow transitions.
export function useChatFlow() {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '0',
      text: 'Type: Buy, Create post, Search, Compare, Recommendation, Report, Edit post, Delete post, My requests, My post',
      isOwn: false,
      senderName: 'TUMB Bot'
    },
    {
      id: '1',
      text: 'Welcome back! How can I help you find what you need today? Here are some quick actions for you.',
      isOwn: false,
      senderName: 'TUMB Bot',
      cardType: 'quick_actions'
    },
  ]);
  const [isLoading, setIsLoading] = useState(false);
  const [flowStatus, setFlowStatus] = useState<string | null>(null);
  const [flowKey, setFlowKey] = useState<string | null>(null);
  const [currentStep, setCurrentStep] = useState<string | null>(null);
  const [chatMode, setChatMode] = useState<'rule' | 'llm'>('rule');

  const updateMessageCardData = (id: string, updater: (prev: any) => any) => {
    setMessages(prev => prev.map(msg =>
      msg.id === id ? { ...msg, cardData: updater(msg.cardData) } : msg
    ));
  };

  const pushMessage = (msg: Omit<ChatMessage, 'id'>) => {
    setMessages(prev => [...prev, { ...msg, id: Date.now().toString() + Math.random().toString() }]);
  };

  const pushBot = (text: string, cardType?: ChatMessage['cardType'], cardData?: any) => {
    pushMessage({ text, isOwn: false, senderName: 'TUMB Bot', cardType, cardData });
  };

  const pushUser = (text: string) => {
    pushMessage({ text, isOwn: true });
  };

  // Decouples backend actions from specialized rich-text UI components.
  const parseCardType = (actionName?: string, actionData?: any): ChatMessage['cardType'] | undefined => {
    if (!actionName) return undefined;
    switch (actionName) {
      case 'create_post':
        pushBot(`The post "${actionData?.item_name || 'N/A'}" has been created successfully.`);
        return undefined;
      case 'update_post':
        pushBot(`The post "${actionData?.item_name || 'N/A'}" has been updated successfully.`);
        return undefined;
      case 'delete_post':
        pushBot(`The post "${actionData?.item_name || 'N/A'}" has been deleted successfully.`);
        return undefined;
      case 'search_post':
      case 'user_posts':
      case 'user_recommendations':
        {
          const items = actionData?.posts || actionData?.recommendations || [];
          if (items.length === 0) {
            pushBot("No results found.");
            return undefined;
          }
          return 'search_results';
        }
      case 'compare_posts':
        return 'comparison';
      case 'create_request':
        return 'order_summary';
      case 'user_requests':
        {
          const requests = actionData?.requests || [];
          if (requests.length === 0) {
            pushBot("You don't have any requests yet.");
            return undefined;
          }
          return 'requests_list';
        }
      case 'report_post':
        return 'report_success';
      default:
        return undefined;
    }
  };

  const buildHistory = (currentMessages: ChatMessage[]): Array<{ role: string, content: string }> => {
    return currentMessages
      .filter(m => m.text && m.text.trim() !== '')
      .map(m => ({
        role: m.isOwn ? 'user' : 'assistant',
        content: m.text,
      }));
  };

  const handleInput = async (rawText: string) => {
    const trimmed = rawText.trim();
    if (!trimmed) return;

    pushUser(trimmed);
    if (trimmed.toLowerCase() === 'help') {
      pushBot(
        'Here are the available actions you can perform:',
        'quick_actions'
      );
      return;
    }
    setIsLoading(true);

    try {
      // Build LangChain-compatible history including the new user message
      const history = [...buildHistory(messages), { role: 'user', content: trimmed }];

      const response: ChatResponse = await chatService.postChat(trimmed, chatMode, history);
      const msgs = response.messages || [];

      if (chatMode === 'llm') {
        // LLM mode: text reply + optional rich card data from tool calls
        if (msgs.length > 0) {
          msgs.forEach((msgText, index) => {
            const isLast = index === msgs.length - 1;
            if (isLast && response.data) {
              pushBot(msgText, parseCardType(response.data.action_name, response.data.action_data), response.data);
            } else {
              pushBot(msgText);
            }
          });
        } else if (response.data) {
          pushBot('', parseCardType(response.data.action_name, response.data.action_data), response.data);
        }
        setFlowStatus(null);
        setFlowKey(null);
        setCurrentStep(null);
      } else {
        // Rule-based mode: existing flow logic
        if (response.flow_state && response.status !== 'terminated' && response.status !== 'error') {
          const key = response.flow_state.flow_key;
          const step = response.flow_state.current_step;
          setFlowKey(key);
          setCurrentStep(step);

          const statusMap: Record<string, string> = {
            'create post': 'Selling in progress',
            'buy': 'Buying in progress',
            'search': 'Searching in progress',
            'compare': 'Comparing in progress',
            'report': 'Reporting in progress',
            'edit post': 'Editing in progress',
            'delete post': 'Deleting in progress',
          };
          setFlowStatus(statusMap[key] || `${key.charAt(0).toUpperCase() + key.slice(1)} in progress`);
        } else {
          if (flowKey) {
            Keyboard.dismiss();
          }
          setFlowStatus(null);
          setFlowKey(null);
          setCurrentStep(null);
        }

        if (msgs.length > 0) {
          msgs.forEach((msgText, index) => {
            const isLast = index === msgs.length - 1;
            if (isLast && response.data) {
              pushBot(msgText, parseCardType(response.data.action_name, response.data.action_data), response.data);
            } else {
              pushBot(msgText);
            }
          });
        } else if (response.data) {
          pushBot('', parseCardType(response.data.action_name, response.data.action_data), response.data);
        }
      }

    } catch (err: any) {
      console.error('Chat error:', err.response?.data || err.message);
      pushBot('Something went wrong. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleLoadMore = async (messageId: string, actionName: string, lastId: number, filters: any) => {
    setIsLoading(true);
    try {
      const { last_id: _drop, ...cleanFilters } = filters || {};
      const response = await chatService.loadMore(actionName, lastId, cleanFilters);
      const actionData = response.action_data || response;
      const newItems: any[] = actionData.posts || actionData.recommendations || [];

      // Update state while ensuring UI stability during list pagination.
      updateMessageCardData(messageId, (prev) => {
        const prevActionData = prev?.action_data || {};
        const existing: any[] = prevActionData.posts || prevActionData.recommendations || [];
        const combined = [...existing, ...newItems];

        const seen = new Set<number>();
        const deduped = combined.filter(item => {
          if (seen.has(item.id)) return false;
          seen.add(item.id);
          return true;
        });

        return {
          ...prev,
          action_name: actionName,
          action_data: {
            ...prevActionData,
            posts: deduped,
            recommendations: undefined,
            has_more: actionData.has_more ?? false,
            next_cursor: actionData.next_cursor ?? null,
            filters: actionData.filters ?? prevActionData.filters,
          }
        };
      });
    } catch (err: any) {
      pushBot('Failed to load more results.');
    } finally {
      setIsLoading(false);
    }
  };

  const resetFlow = () => {
    setFlowStatus(null);
    setFlowKey(null);
    setCurrentStep(null);
  };

  return { messages, handleInput, isLoading, handleLoadMore, resetFlow, flowStatus, flowKey, currentStep, chatMode, setChatMode };
}
