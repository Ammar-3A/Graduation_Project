import React, { useEffect, useRef } from 'react';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { StyleSheet, Text, View, ScrollView, KeyboardAvoidingView, Platform, TouchableOpacity, ActivityIndicator } from 'react-native';
import { Screen } from '../../src/components/Screen';
import { ChatBubble } from '../../src/components/ChatBubble';
import { ChatInputBar } from '../../src/components/ChatInputBar';
import { ChatActionCard } from '../../src/components/ChatActionCard';
import { typography } from '../../src/theme/typography';
import { spacing } from '../../src/theme/spacing';
import { colors } from '../../src/theme/colors';
import { Ionicons } from '@expo/vector-icons';
import { useChatFlow } from '../../src/chat/useChatFlow';
import { Keyboard, TouchableWithoutFeedback } from 'react-native';
import {
  OrderSummaryCard,
  ComparisonCard,
  SearchResultsCard,
  RequestsListCard,
  ReportSuccessCard,
} from '../../src/components/ChatCards';
import { PrimaryButton } from '../../src/components/PrimaryButton';

export default function ChatTab() {
  const { text } = useLocalSearchParams<{ text?: string }>();
  const router = useRouter();
  const { messages, handleInput, resetFlow, isLoading, handleLoadMore, flowStatus, flowKey, currentStep, chatMode, setChatMode } = useChatFlow();
  const scrollViewRef = useRef<ScrollView>(null);
  const chatStartTime = React.useMemo(() => {
    const now = new Date();
    return now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
  }, []);

  // Trigger initial interaction if navigation context provides a starting query.
  useEffect(() => {
    if (text) {
      handleInput(text);
      router.setParams({ text: undefined });
    }
  }, [text]);

  // Ensure scroll position tracks new conversational entries.
  useEffect(() => {
    setTimeout(() => {
      scrollViewRef.current?.scrollToEnd({ animated: true });
    }, 100);
  }, [messages.length]);

  return (
    <Screen style={styles.container} safeTop safeBottom={false}>
      <View style={styles.header}>
        <View style={styles.headerLeft}>
          <View style={styles.avatarContainer}>
            <Ionicons name="logo-android" size={20} color={colors.primaryLight} />
            <View style={styles.onlineDot} />
          </View>
          <View>
            <Text style={styles.headerTitle}>TUMB Bot</Text>
            <Text style={styles.headerSubtitle}>Online</Text>
          </View>
        </View>
        <TouchableOpacity
          style={[
            styles.modeToggle,
            chatMode === 'llm' ? styles.modeToggleLLM : styles.modeToggleRule,
          ]}
          onPress={() => setChatMode(prev => prev === 'rule' ? 'llm' : 'rule')}
          activeOpacity={0.7}
        >
          <Ionicons
            name={chatMode === 'llm' ? 'sparkles' : 'chatbubbles-outline'}
            size={14}
            color={chatMode === 'llm' ? '#A855F6' : colors.primaryLight}
          />
          <Text style={[
            styles.modeToggleText,
            chatMode === 'llm' ? styles.modeToggleTextLLM : styles.modeToggleTextRule,
          ]}>
            {chatMode === 'llm' ? 'AI Agent' : 'Rule Based'}
          </Text>
        </TouchableOpacity>
      </View>

      <KeyboardAvoidingView
        style={styles.contentFlex}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        keyboardVerticalOffset={0}
      >
        <ScrollView
          ref={scrollViewRef}
          style={styles.chatArea}
          contentContainerStyle={styles.chatContent}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
          keyboardDismissMode="none"
        >
          <View>
            <View style={styles.datePillContainer}>
              <View style={styles.datePill}>
                <Text style={styles.dateText}>Today {chatStartTime}</Text>
              </View>
            </View>

            {messages.map((msg) => (
              <React.Fragment key={msg.id}>
                <ChatBubble text={msg.text} isOwn={msg.isOwn} senderName={msg.senderName} />

                {msg.cardType === 'quick_actions' && (
                  <View style={styles.quickActionsContainer}>
                    <ChatActionCard
                      title="Search"
                      subtitle="for a product"
                      icon="search"
                      onPress={() => { Keyboard.dismiss(); handleInput('search'); }}
                    />
                    <ChatActionCard
                      title="Buy Something"
                      subtitle="Shop local student deals"
                      icon="bag-handle"
                      onPress={() => { Keyboard.dismiss(); handleInput('buy'); }}
                    />
                    <ChatActionCard
                      title="Sell an Item"
                      subtitle="Post a listing in seconds"
                      icon="camera"
                      onPress={() => { Keyboard.dismiss(); handleInput('create post'); }}
                    />
                    <ChatActionCard
                      title="Edit My Posts"
                      subtitle="Edit active listings"
                      icon="list"
                      onPress={() => { Keyboard.dismiss(); handleInput('Edit post'); }}
                    />
                    <ChatActionCard
                      title="Compare Items"
                      subtitle="Price & feature check"
                      icon="swap-horizontal"
                      onPress={() => { Keyboard.dismiss(); handleInput('compare'); }}
                    />
                    <ChatActionCard
                      title="Recommendation"
                      subtitle="Based on your interests"
                      icon="sparkles"
                      onPress={() => { Keyboard.dismiss(); handleInput('recommendation'); }}
                    />
                    <ChatActionCard
                      title="My Requests"
                      subtitle="View your orders & contact sellers"
                      icon="receipt"
                      onPress={() => { Keyboard.dismiss(); handleInput('my requests'); }}
                    />
                    <ChatActionCard
                      title="Report a Problem"
                      subtitle="Help & Support"
                      icon="warning"
                      onPress={() => { Keyboard.dismiss(); handleInput('report'); }}
                    />

                  </View>
                )}

                {msg.cardType === 'order_summary' && (
                  <View style={styles.cardWrapper}>
                    <OrderSummaryCard data={msg.cardData?.action_data || msg.cardData} />
                  </View>
                )}


                {msg.cardType === 'comparison' && (
                  <View style={styles.cardWrapper}>
                    <ComparisonCard data={msg.cardData?.action_data || msg.cardData} />
                  </View>
                )}

                {msg.cardType === 'search_results' && (
                  <View style={styles.cardWrapper}>
                    <SearchResultsCard results={
                      msg.cardData?.action_data?.posts ??
                      msg.cardData?.action_data?.recommendations ??
                      []
                    } />
                    {msg.cardData?.action_data?.has_more && (
                      <View style={{ marginTop: spacing.md, alignItems: 'center' }}>
                        <PrimaryButton
                          title="Load More Results"
                          style={{ paddingVertical: 8, paddingHorizontal: spacing.lg, minHeight: 36, borderRadius: 16 }}
                          onPress={() => handleLoadMore(msg.id, msg.cardData.action_name, msg.cardData.action_data.next_cursor, msg.cardData.action_data.filters)}
                        />
                      </View>
                    )}
                  </View>
                )}

                {msg.cardType === 'requests_list' && (
                  <View style={styles.cardWrapper}>
                    <RequestsListCard requests={msg.cardData?.action_data?.requests || []} />
                  </View>
                )}

                {msg.cardType === 'report_success' && (
                  <View style={styles.cardWrapper}>
                    <ReportSuccessCard data={msg.cardData?.action_data || msg.cardData} />
                  </View>
                )}
              </React.Fragment>
            ))}
          </View>
        </ScrollView>

        {isLoading && (
          <View style={styles.loadingContainer}>
            <ActivityIndicator size="small" color={colors.primaryLight} />
            <Text style={styles.loadingText}>TUMB Bot is thinking...</Text>
          </View>
        )}
        {flowStatus && (
          <View style={styles.statusBar}>
            <View style={styles.statusLeft}>
              <Ionicons name="information-circle-outline" size={16} color={colors.primaryLight} />
              <Text style={styles.statusText}>{flowStatus}</Text>
            </View>
            <TouchableOpacity style={styles.cancelButton} onPress={() => handleInput('cancel')}>
              <Text style={styles.cancelText}>Cancel</Text>
              <Ionicons name="close-circle" size={16} color={colors.danger} />
            </TouchableOpacity>
          </View>
        )}
        <ChatInputBar onSend={handleInput} flowKey={flowKey || undefined} currentStep={currentStep || undefined} />
      </KeyboardAvoidingView>
    </Screen>
  );
}

const styles = StyleSheet.create({
  keyboardContainer: {
    flex: 1,
    backgroundColor: colors.background,
  },
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  contentFlex: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  headerLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
  },
  avatarContainer: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#1E293B',
    alignItems: 'center',
    justifyContent: 'center',
  },
  onlineDot: {
    position: 'absolute',
    right: 0,
    bottom: 0,
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: colors.success,
    borderWidth: 2,
    borderColor: '#1E293B',
  },
  headerTitle: {
    ...typography.h3,
    color: colors.text,
  },
  headerSubtitle: {
    ...typography.caption,
    color: colors.success,
  },
  chatArea: {
    flex: 1,
  },
  chatContent: {
    padding: spacing.md,
    paddingBottom: spacing.xxl,
  },
  datePillContainer: {
    alignItems: 'center',
    marginVertical: spacing.md,
  },
  datePill: {
    backgroundColor: colors.surfaceHighlight,
    paddingHorizontal: spacing.md,
    paddingVertical: 4,
    borderRadius: 12,
  },
  dateText: {
    ...typography.caption,
    color: colors.textSecondary,
  },
  quickActionsContainer: {
    marginTop: spacing.sm,
    marginBottom: spacing.md,
    marginLeft: 40,
    gap: spacing.sm,
  },
  cardWrapper: {
    marginLeft: 40,
    marginBottom: spacing.md,
  },
  loadingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: spacing.sm,
    gap: spacing.sm,
  },
  loadingText: {
    ...typography.caption,
    color: colors.textSecondary,
    fontStyle: 'italic',
  },
  statusBar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.lg,
    paddingVertical: 12,
    backgroundColor: '#0F172A',
    borderTopWidth: 1,
    borderTopColor: 'rgba(255, 255, 255, 0.05)',
  },
  statusLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  statusText: {
    ...typography.caption,
    color: colors.primaryLight,
    fontWeight: '600',
    fontSize: 12,
  },
  cancelButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: 'rgba(239, 68, 68, 0.12)',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 14,
  },
  cancelText: {
    ...typography.caption,
    color: colors.danger,
    fontWeight: 'bold',
    fontSize: 11,
    textTransform: 'uppercase',
  },
  modeToggle: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    borderWidth: 1,
  },
  modeToggleRule: {
    backgroundColor: 'rgba(58, 157, 242, 0.1)',
    borderColor: 'rgba(58, 157, 242, 0.25)',
  },
  modeToggleLLM: {
    backgroundColor: 'rgba(168, 85, 246, 0.12)',
    borderColor: 'rgba(168, 85, 246, 0.3)',
  },
  modeToggleText: {
    fontSize: 11,
    fontWeight: '700',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  modeToggleTextRule: {
    color: colors.primaryLight,
  },
  modeToggleTextLLM: {
    color: '#A855F6',
  },
});
