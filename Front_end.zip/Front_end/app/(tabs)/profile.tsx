import React from 'react';
import { StyleSheet, Text, View, Image, ScrollView, Alert } from 'react-native';
import { Screen } from '../../src/components/Screen';
import { ActionRow } from '../../src/components/ActionRow';
import { useAppStore, getFullName } from '../../src/store/useAppStore';
import { colors } from '../../src/theme/colors';
import { typography } from '../../src/theme/typography';
import { spacing } from '../../src/theme/spacing';
import { PrimaryButton } from '../../src/components/PrimaryButton';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { authService } from '../../src/api/services/authService';

export default function ProfileTab() {
  const router = useRouter();
  const { logout } = useAppStore();
  const user = useAppStore(state => state.activeUser);

  if (!user) {
    return (
      <Screen style={styles.container}>
        <Text style={styles.title}>Not logged in</Text>
      </Screen>
    );
  }

  const handleSignOut = () => {
    Alert.alert(
      "Sign Out",
      "Are you sure you want to sign out?",
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Sign Out",
          style: "destructive",
          onPress: async () => {
            try {
              await authService.logout();
              logout();
              router.replace('/(auth)/login');
            } catch (error) {
              console.error('Logout failed', error);
            }
          }
        }
      ]
    );
  };

  return (
    <Screen style={styles.container} safeArea>
      <ScrollView showsVerticalScrollIndicator={false}>

        <View style={styles.profileHeader}>
          <View style={styles.avatarContainer}>
            <Ionicons name="person-circle" size={100} color={colors.textSecondary} />
          </View>

          <Text style={styles.userName}>{user.name}</Text>
        </View>


        <View style={styles.section}>
          <Text style={styles.sectionTitle}>QUICK ACTIONS</Text>
          <View style={styles.cardGroup}>
            <ActionRow
              title="My posts"
              icon="list-outline"
              onPress={() => router.push({ pathname: '/chat', params: { text: 'my posts' } })}
            />
            <ActionRow
              title="My requests"
              icon="receipt-outline"
              onPress={() => router.push({ pathname: '/chat', params: { text: 'my requests' } })}
            />
            <ActionRow
              title="Edit post"
              icon="create-outline"
              onPress={() => router.push({ pathname: '/chat', params: { text: 'Edit post' } })}
            />
            <ActionRow
              title="Delete my post"
              icon="trash-outline"
              onPress={() => router.push({ pathname: '/chat', params: { text: 'Delete post' } })}
            />
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>ACCOUNT</Text>
          <View style={styles.cardGroup}>
            <ActionRow
              title="Account Details"
              icon="person-outline"
              onPress={() => router.push('/profile/account-details')}
            />
          </View>
        </View>



        <View style={styles.section}>
          <Text style={styles.sectionTitle}>SUPPORT</Text>
          <View style={styles.cardGroup}>
            <ActionRow
              title="About TUMB"
              icon="information-circle-outline"
              onPress={() => router.push('/profile/about')}
            />
          </View>
        </View>

        <View style={styles.signOutContainer}>
          <PrimaryButton
            title="Sign Out"
            onPress={handleSignOut}
            style={styles.signOutButton}
          />
        </View>

      </ScrollView>
    </Screen>
  );
}

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: spacing.md,
  },
  title: {
    ...typography.h1,
    textAlign: 'center',
    marginTop: spacing.xxl,
  },
  profileHeader: {
    alignItems: 'center',
    marginTop: spacing.xl,
    marginBottom: spacing.xxl,
  },
  avatarContainer: {
    position: 'relative',
    marginBottom: spacing.xs,
  },
  userName: {
    ...typography.h1,
    color: colors.text,
    marginBottom: spacing.xs,
  },
  section: {
    marginBottom: spacing.xl,
  },
  sectionTitle: {
    ...typography.caption,
    textTransform: 'uppercase',
    letterSpacing: 1,
    marginBottom: spacing.sm,
    marginLeft: spacing.sm,
  },
  signOutContainer: {
    marginTop: spacing.md,
    marginBottom: spacing.xxl,
  },
  cardGroup: {
    backgroundColor: colors.surface,
    borderRadius: 20,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: colors.border,
    marginBottom: spacing.xxl,
  },
  signOutButton: {
    borderColor: colors.danger,
    borderRadius: 24,
    marginBottom: spacing.xl,
    height: 56,
  },
});
