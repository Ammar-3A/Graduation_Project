import React from 'react';
import { StyleSheet, Text, View, ScrollView, TouchableOpacity, Image } from 'react-native';
import { Screen } from '../../src/components/Screen';
import { typography } from '../../src/theme/typography';
import { spacing } from '../../src/theme/spacing';
import { colors } from '../../src/theme/colors';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';

export default function AboutScreen() {
  const router = useRouter();

  return (
    <Screen style={styles.container} safeArea>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
          <Ionicons name="arrow-back" size={24} color={colors.text} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>About TUMB</Text>
        <View style={{ width: 40 }} />
      </View>

      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        <View style={styles.logoContainer}>
          <View style={styles.logoPlaceholder}>
            <Ionicons name="cube" size={64} color={colors.primaryLight} />
          </View>
          <Text style={styles.appName}>TUMB</Text>
          <Text style={styles.version}>Version 1.0.0</Text>
        </View>

        <View style={styles.infoBox}>
          <Text style={styles.description}>
            TUMB (Taibah University Marketplace & Bot) is the premier marketplace exclusively for Taibah University students. 
            Our platform connects students to safely buy, sell, and trade essential academic items using our intelligent Chat Bot engine.
          </Text>
        </View>

        <View style={styles.linkGroup}>
          <TouchableOpacity style={styles.linkRow}>
            <Text style={styles.linkLabel}>Terms of Service</Text>
            <Ionicons name="open-outline" size={20} color={colors.textSecondary} />
          </TouchableOpacity>
          <View style={styles.divider} />
          <TouchableOpacity style={styles.linkRow}>
            <Text style={styles.linkLabel}>Privacy Policy</Text>
            <Ionicons name="open-outline" size={20} color={colors.textSecondary} />
          </TouchableOpacity>
        </View>

        <Text style={styles.copyright}>© 2026 Taibah University Students Group.</Text>
      </ScrollView>
    </Screen>
  );
}

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: spacing.md,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: spacing.md,
  },
  backButton: {
    padding: spacing.xs,
  },
  headerTitle: {
    ...typography.h2,
  },
  scrollContent: {
    paddingBottom: spacing.xxl,
  },
  logoContainer: {
    alignItems: 'center',
    marginTop: spacing.xl,
    marginBottom: spacing.xxl,
  },
  logoPlaceholder: {
    width: 120,
    height: 120,
    borderRadius: 32,
    backgroundColor: 'rgba(56, 189, 248, 0.1)',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: spacing.md,
  },
  appName: {
    ...typography.h1,
    color: colors.text,
    letterSpacing: 2,
  },
  version: {
    ...typography.caption,
    color: colors.textSecondary,
    marginTop: 4,
  },
  infoBox: {
    backgroundColor: colors.surfaceHighlight,
    padding: spacing.lg,
    borderRadius: 16,
    marginBottom: spacing.xl,
  },
  description: {
    ...typography.body,
    color: colors.text,
    lineHeight: 24,
    textAlign: 'center',
  },
  linkGroup: {
    backgroundColor: colors.surface,
    borderRadius: 16,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: colors.border,
    marginBottom: spacing.xxl,
  },
  linkRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: spacing.md,
  },
  linkLabel: {
    ...typography.body,
    color: colors.text,
  },
  divider: {
    height: 1,
    backgroundColor: colors.border,
    marginLeft: spacing.md,
  },
  copyright: {
    ...typography.caption,
    color: colors.textSecondary,
    textAlign: 'center',
  },
});
