import React from 'react';
import { StyleSheet, Text, View, ScrollView } from 'react-native';
import { Screen } from '../../src/components/Screen';
import { useAppStore } from '../../src/store/useAppStore';
import { typography } from '../../src/theme/typography';
import { spacing } from '../../src/theme/spacing';
import { colors } from '../../src/theme/colors';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';

export default function AccountDetailsScreen() {
  const router = useRouter();
  const user = useAppStore(state => state.activeUser);

  if (!user) {
    return (
      <Screen style={styles.container}>
        <Text style={styles.title}>Not logged in</Text>
      </Screen>
    );
  }

  return (
    <Screen style={styles.container} safeArea>
      <View style={styles.header}>
        <Ionicons name="arrow-back" size={24} color={colors.text} onPress={() => router.back()} />
        <Text style={styles.headerTitle}>Account Details</Text>
        <View style={{ width: 24 }} />
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
        {/* (new) Display only the textual information returned from the backend */}
        <View style={styles.infoCard}>
          <View style={styles.infoRow}>
            <Text style={styles.label}>Name</Text>
            <Text style={styles.valueText}>{user.name}</Text>
          </View>
          
          <View style={styles.infoRow}>
            <Text style={styles.label}>Email Address</Text>
            <Text style={styles.valueText}>{user.email}</Text>
          </View>

          <View style={styles.infoRow}>
            <Text style={styles.label}>Phone Number</Text>
            <Text style={styles.valueText}>{user.phone_number}</Text>
          </View>

          <View style={styles.infoRow}>
            <Text style={styles.label}>Selected Interest</Text>
            <Text style={styles.valueText}>{user.interest}</Text>
          </View>
        </View>
      </ScrollView>
    </Screen>
  );
}

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: spacing.md,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: spacing.md,
    marginBottom: spacing.lg,
  },
  headerTitle: {
    ...typography.h2,
  },
  title: {
    ...typography.h1,
    textAlign: 'center',
    marginTop: spacing.xxl,
  },
  scrollContent: {
    paddingBottom: spacing.xxl,
  },
  infoCard: {
    backgroundColor: colors.surfaceHighlight,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: colors.border,
    padding: spacing.lg,
    gap: spacing.lg,
  },
  infoRow: {
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.border,
    paddingBottom: spacing.md,
  },
  label: {
    ...typography.caption,
    color: colors.textSecondary,
    marginBottom: spacing.xs,
    textTransform: 'uppercase',
    letterSpacing: 1,
  },
  valueText: {
    ...typography.h3,
    color: colors.text,
  },
});
