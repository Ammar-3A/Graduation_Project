import { DarkTheme, DefaultTheme, ThemeProvider } from '@react-navigation/native';
import { useFonts } from 'expo-font';
import { Stack, useRouter, useSegments } from 'expo-router';
import * as SplashScreen from 'expo-splash-screen';
import { useEffect } from 'react';
import 'react-native-reanimated';
import { useColorScheme } from 'react-native';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { useAppStore } from '../src/store/useAppStore';
import { useState } from 'react';
import { View, ActivityIndicator } from 'react-native';
import { userService } from '../src/api/services/userService';
import { colors } from '../src/theme/colors';

export { ErrorBoundary } from 'expo-router';

export const unstable_settings = {
  initialRouteName: '(tabs)',
};

SplashScreen.preventAutoHideAsync();

function useProtectedRoute(loaded: boolean) {
  const segments = useSegments();
  const router = useRouter();
  const { setCurrentUser } = useAppStore();
  // M-1: Use primitive boolean selectors so the effect dep array is reactive
  const loggedIn = useAppStore(state => !!state.activeUser);
  const isAdmin = useAppStore(state => !!state.activeUser?.isAdmin);
  const [authChecked, setAuthChecked] = useState(false);

  // (new) fetch profile automatically to check if token exists and is valid
  useEffect(() => {
    async function checkAuth() {
      try {
        const profile = await userService.getUserProfile();
        // backend returns a single user object, store it directly
        setCurrentUser(profile);
      } catch (err) {
        setCurrentUser(null);
      } finally {
        setAuthChecked(true);
      }
    }
    checkAuth();
  }, []);

  useEffect(() => {
    if (!loaded || !authChecked) return;

    const inAuthGroup = segments[0] === '(auth)';
    const inAdminGroup = segments[0] === 'admin';

    if (!loggedIn && !inAuthGroup) {
      // Redirect to the login page if not logged in
      router.replace('/(auth)/login');
    } else if (loggedIn) {
      if (isAdmin) {
        // Admins go to dashboard if they are in auth or tabs group
        if (inAuthGroup || segments[0] === '(tabs)' || segments[0] === 'chat') {
          router.replace('/admin/dashboard');
        }
      } else {
        // Normal users go to chat if they are in auth or admin group
        if (inAuthGroup || inAdminGroup) {
          router.replace('/(tabs)/chat');
        }
      }
    }
  }, [loggedIn, isAdmin, segments, loaded, authChecked]);

  return { authChecked };
}

export default function RootLayout() {
  const [loaded, error] = useFonts({
    SpaceMono: require('../assets/fonts/SpaceMono-Regular.ttf'),
  });

  useEffect(() => {
    if (error) throw error;
  }, [error]);

  const { authChecked } = useProtectedRoute(loaded);

  useEffect(() => {
    if (loaded && authChecked) {
      SplashScreen.hideAsync();
    }
  }, [loaded, authChecked]);

  // (new) show loading spinner while validating token bounds
  if (!loaded || !authChecked) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: colors.background }}>
        <ActivityIndicator size="large" color={colors.primaryLight} />
      </View>
    );
  }

  return <RootLayoutNav />;
}

function RootLayoutNav() {
  const colorScheme = useColorScheme();

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <ThemeProvider value={colorScheme === 'dark' ? DarkTheme : DefaultTheme}>
        <Stack screenOptions={{ headerShown: false }}>
          <Stack.Screen name="(tabs)" options={{ animation: 'fade' }} />
        </Stack>
      </ThemeProvider>
    </GestureHandlerRootView>
  );
}