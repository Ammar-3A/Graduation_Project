import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, KeyboardAvoidingView, Platform, ScrollView, ActivityIndicator } from 'react-native';
import { Screen } from '../../src/components/Screen';
import { PrimaryButton } from '../../src/components/PrimaryButton';
import { Input } from '../../src/components/Input';
import { typography } from '../../src/theme/typography';
import { spacing } from '../../src/theme/spacing';
import { colors } from '../../src/theme/colors';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { useAppStore } from '../../src/store/useAppStore';
import { Ionicons } from '@expo/vector-icons';
import { authService } from '../../src/api/services/authService';
import { userService } from '../../src/api/services/userService';
import { adminService } from '../../src/api/services/adminService';

export default function LoginScreen() {
  const router = useRouter();
  const { registeredEmail } = useLocalSearchParams();
  const { setCurrentUser } = useAppStore();
  
  // (new) auto-populate email if user just arrived from the registration screen
  const [email, setEmail] = useState<string>((registeredEmail as string) || '');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  // (new) state for API loading and exact error message
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [isAdminLogin, setIsAdminLogin] = useState(false); // new

  // (new) handles login API call
  const handleLogin = async () => {
    const cleanEmail = email.trim().toLowerCase();
    if (!cleanEmail || !password) {
      setErrorMessage('Please enter email and password');
      return;
    }
    setLoading(true);
    setErrorMessage('');
    try {
      if (isAdminLogin) {
        await authService.loginAdmin(cleanEmail, password);
        // H-1: Fetch real admin profile from dedicated /admin/profile endpoint
        const adminProfile = await adminService.getAdminProfile();
        setCurrentUser({
          id: String(adminProfile.id),
          name: adminProfile.name,
          email: adminProfile.email,
          isAdmin: true,
        });
        router.replace('/admin/dashboard');
      } else {
        await authService.loginUser(cleanEmail, password);
        // (new) fetches actual user profile and pushes it centrally immediately
        const profile = await userService.getUserProfile();
        setCurrentUser(profile);
        router.replace('/(tabs)/chat');
      }
    } catch (err) {
      const error = err as any;
      const msg = error.response?.data?.detail || error.response?.data?.message || error.message || 'Login failed';
      setErrorMessage(typeof msg === 'string' ? msg : JSON.stringify(msg));
    } finally {
      setLoading(false);
    }
  };

  return (
    <Screen style={styles.container} safeArea>
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 40 : 0}
      >
        <ScrollView 
          contentContainerStyle={styles.scrollContent}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        >
      <View style={styles.logoContainer}>
        <View style={styles.logoLogo}>
          <Ionicons name="storefront" size={32} color={colors.primaryLight} />
        </View>
      </View>

      <View style={styles.header}>
        <Text style={styles.title}>Login to TUMB</Text>
        <Text style={styles.subtitle}>Taibah University Marketplace</Text>
      </View>

      <View style={styles.form}>
        <Input 
          label="University Email"
          icon="mail"
          placeholder="id@taibahu.edu.sa"
          value={email}
          onChangeText={setEmail}
          autoCapitalize="none"
          keyboardType="email-address"
        />

        <Input 
          label="Password"
          icon="lock-closed"
          placeholder="••••••••"
          value={password}
          onChangeText={setPassword}
          secureTextEntry={!showPassword}
          rightIcon={
            <TouchableOpacity onPress={() => setShowPassword(!showPassword)}>
              <Ionicons name={showPassword ? "eye-off" : "eye"} size={20} color={colors.textSecondary} />
            </TouchableOpacity>
          }
        />

        <TouchableOpacity 
          style={styles.adminToggle} 
          onPress={() => setIsAdminLogin(!isAdminLogin)}
        >
          <Ionicons 
            name={isAdminLogin ? "checkbox" : "square-outline"} 
            size={20} 
            color={isAdminLogin ? colors.primaryLight : colors.textSecondary} 
          />
          <Text style={[styles.adminToggleText, isAdminLogin && { color: colors.primaryLight }]}>
            Login as Admin
          </Text>
        </TouchableOpacity>

        {errorMessage !== '' && (
          <Text style={styles.errorText}>{errorMessage}</Text>
        )}

        <PrimaryButton 
          title={loading ? "Logging in..." : "Login"} 
          onPress={handleLogin} 
          disabled={loading}
          icon={loading ? <ActivityIndicator color={colors.text} /> : <Ionicons name="log-in-outline" size={20} color={colors.text} />}
          style={styles.loginButton}
        />
      </View>

        <View style={styles.footer}>
          <Text style={styles.footerText}>Don't have an account? </Text>
          <TouchableOpacity onPress={() => router.push('/(auth)/register')}>
            <Text style={styles.signupText}>Sign up</Text>
          </TouchableOpacity>
        </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </Screen>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollContent: {
    flexGrow: 1,
    padding: spacing.xl,
    justifyContent: 'center',
  },
  logoContainer: {
    alignItems: 'center',
    marginBottom: spacing.xl,
  },
  logoLogo: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: colors.surfaceHighlight,
    alignItems: 'center',
    justifyContent: 'center',
  },
  header: {
    alignItems: 'center',
    marginBottom: spacing.xxl,
  },
  title: {
    ...typography.h1,
    fontSize: 32, // larger for this screen
    marginBottom: spacing.xs,
  },
  subtitle: {
    ...typography.body,
    color: colors.textSecondary,
  },
  form: {
    gap: spacing.sm,
  },
  forgotPassword: {
    alignSelf: 'flex-end',
    marginBottom: spacing.xl,
  },
  forgotPasswordText: {
    ...typography.body,
    color: colors.primaryLight,
  },
  loginButton: {
    marginTop: spacing.md,
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: spacing.xxl,
  },
  footerText: {
    ...typography.body,
  },
  signupText: {
    ...typography.body,
    color: colors.primaryLight,
    fontWeight: '600',
  },
  adminToggle: { // new
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
    marginBottom: spacing.md,
    alignSelf: 'center',
  },
  adminToggleText: { // new
    ...typography.body,
    color: colors.textSecondary,
    fontSize: 14,
  },
  errorText: {
    ...typography.body,
    color: colors.danger,
    textAlign: 'center',
    marginBottom: spacing.sm,
  },
});
