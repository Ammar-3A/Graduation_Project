import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, KeyboardAvoidingView, Platform, ScrollView } from 'react-native';
import { Screen } from '../../src/components/Screen';
import { PrimaryButton } from '../../src/components/PrimaryButton';
import { Input } from '../../src/components/Input';
import { typography } from '../../src/theme/typography';
import { spacing } from '../../src/theme/spacing';
import { colors } from '../../src/theme/colors';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { authService } from '../../src/api/services/authService';

export default function RegisterScreen() {
  const router = useRouter();
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [interest, setInterest] = useState('');
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  const handleRegister = async () => {
    const cleanEmail = email.trim().toLowerCase();
    if (!fullName || !cleanEmail || !password || !phoneNumber || !interest) {
      setErrorMessage('Please fill all fields');
      return;
    }

    if (!phoneNumber.startsWith('05') || phoneNumber.length !== 10) {
      setErrorMessage('Phone number must start with 05 and be exactly 10 digits');
      return;
    }

    setLoading(true);
    setErrorMessage('');
    try {
      const response = await authService.register({
        name: fullName,
        email: cleanEmail,
        phone_number: phoneNumber,
        password,
        interest
      });
      router.push({
        pathname: '/(auth)/otp-verification',
        params: { email: cleanEmail, expires_in: response.expires_in || 180 }
      });
    } catch (err) {
      const error = err as any;
      const msg = error.response?.data?.detail || error.response?.data?.message || error.message || 'Registration failed';
      setErrorMessage(typeof msg === 'string' ? msg : JSON.stringify(msg));
    } finally {
      setLoading(false);
    }
  };

  return (
    <Screen style={styles.container} safeArea>
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 40 : 0}
      >
        <ScrollView
          contentContainerStyle={styles.scrollContent}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        >
          <View style={styles.logoContainer}>
            <View style={styles.logoLogo}>
              <Ionicons name="storefront" size={32} color={colors.primaryLight} />
            </View>
          </View>

          <View style={styles.header}>
            <Text style={styles.title}>Register Account</Text>
            <Text style={styles.subtitle}>Join the Taibah University student community marketplace.</Text>
          </View>

          <View style={styles.form}>
            <Input
              label="Full Name"
              icon="person"
              placeholder="First and Last Names"
              value={fullName}
              onChangeText={setFullName}
            />

            <Input
              label="Email Address"
              icon="mail"
              placeholder="TU4312345@taibahu.edu.sa"
              value={email}
              onChangeText={setEmail}
              autoCapitalize="none"
              keyboardType="email-address"
            />

            <Input
              label="Phone Number"
              icon="call"
              placeholder="05xxxxxxxx"
              value={phoneNumber}
              onChangeText={setPhoneNumber}
              keyboardType="phone-pad"
              maxLength={10}
            />

            <View style={styles.formGroup}>
              <Text style={styles.inputLabel}>Select Interest</Text>
              <View style={styles.interestContainer}>
                {['Lab equipment', 'Clothing', 'Electronics'].map(item => (
                  <TouchableOpacity
                    key={item}
                    style={[styles.interestPill, interest === item && styles.interestPillActive]}
                    onPress={() => setInterest(item)}
                  >
                    <Text style={[styles.interestPillText, interest === item && styles.interestPillTextActive]}>{item}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>

            <Input
              label="Password"
              icon="lock-closed"
              placeholder="••••••••"
              value={password}
              onChangeText={setPassword}
              secureTextEntry={!showPassword}
              rightIcon={
                <TouchableOpacity onPress={() => setShowPassword(!showPassword)}>
                  <Ionicons name={showPassword ? "eye-off" : "eye"} size={20} color={colors.textSecondary} />
                </TouchableOpacity>
              }
            />

            {errorMessage !== '' && (
              <Text style={styles.errorText}>{errorMessage}</Text>
            )}

            <PrimaryButton
              title={loading ? "Creating Account..." : "Create Account"}
              onPress={handleRegister}
              disabled={loading}
              style={styles.registerButton}
            />
          </View>

          <View style={styles.footer}>
            <Text style={styles.footerText}>Already have an account? </Text>
            <TouchableOpacity onPress={() => router.push('/(auth)/login')}>
              <Text style={styles.loginText}>Login</Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </Screen>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollContent: {
    flexGrow: 1,
    padding: spacing.xl,
    justifyContent: 'center',
  },
  logoContainer: {
    alignItems: 'center',
    marginBottom: spacing.xl,
  },
  logoLogo: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: colors.surfaceHighlight,
    alignItems: 'center',
    justifyContent: 'center',
  },
  header: {
    alignItems: 'center',
    marginBottom: spacing.xxl,
  },
  title: {
    ...typography.h1,
    fontSize: 32,
    marginBottom: spacing.sm,
  },
  subtitle: {
    ...typography.body,
    color: colors.textSecondary,
    textAlign: 'center',
    paddingHorizontal: spacing.xl,
  },
  form: {
    gap: spacing.sm,
  },
  formGroup: {
    marginBottom: spacing.xs,
  },
  inputLabel: {
    ...typography.caption,
    color: colors.textSecondary,
    marginBottom: spacing.xs,
    marginLeft: spacing.xs,
  },
  interestContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.sm,
    marginTop: spacing.xs,
  },
  interestPill: {
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.surface,
  },
  interestPillActive: {
    backgroundColor: colors.primary,
    borderColor: colors.primary,
  },
  interestPillText: {
    ...typography.body,
    color: colors.textSecondary,
  },
  interestPillTextActive: {
    color: '#fff',
    fontWeight: 'bold',
  },
  registerButton: {
    marginTop: spacing.xl,
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: spacing.xxl,
  },
  footerText: {
    ...typography.body,
  },
  loginText: {
    ...typography.body,
    color: colors.primaryLight,
    fontWeight: '600',
  },
  errorText: {
    ...typography.body,
    color: colors.danger,
    textAlign: 'center',
    marginBottom: spacing.sm,
  },
});
