import React, { useState, useCallback } from 'react';
import { StyleSheet, Text, View, ScrollView, RefreshControl, Alert, TouchableOpacity } from 'react-native';
import { Screen } from '../../src/components/Screen';
import { ActionRow } from '../../src/components/ActionRow';
import { Card } from '../../src/components/Card';
import { typography } from '../../src/theme/typography';
import { spacing } from '../../src/theme/spacing';
import { colors } from '../../src/theme/colors';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { adminService } from '../../src/api/services/adminService';
import { authService } from '../../src/api/services/authService';
import { useAppStore } from '../../src/store/useAppStore';
import { useFocusEffect } from '@react-navigation/native';

export default function AdminDashboard() {
  const router = useRouter();

  const [stats, setStats] = useState<any>(null);
  const [monitoring, setMonitoring] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const fetchData = async () => {
    try {
      const [s, m] = await Promise.all([
        adminService.getStats(),
        adminService.getMonitoring()
      ]);
      setStats(s);
      setMonitoring(m);
    } catch (err) {
      console.error('Error fetching admin data:', err);
    } finally {
      setLoading(false);
    }
  };

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await fetchData();
    setRefreshing(false);
  }, []);

  useFocusEffect(
    useCallback(() => {
      fetchData();
    }, [])
  );

  const handleLogout = () => {
    Alert.alert(
      "Sign Out",
      "Are you sure you want to sign out?",
      [
        { text: "Cancel", style: "cancel" },
        { 
          text: "Sign Out", 
          style: "destructive",
          onPress: async () => {
            try {
              await authService.logout();
              useAppStore.getState().logout();
              router.replace('/(auth)/login');
            } catch (error) {
              console.error('Logout failed', error);
            }
          }
        }
      ]
    );
  };

  return (
    <Screen style={styles.container} safeArea>
      <View style={styles.header}>
        <View style={styles.headerTitles}>
          <Text style={styles.title}>Admin Dashboard</Text>
          <Text style={styles.subtitle}>TUMB Moderation</Text>
        </View>
        <TouchableOpacity onPress={handleLogout} style={styles.logoutButton}>
          <Ionicons name="log-out-outline" size={24} color={colors.danger} />
        </TouchableOpacity>
      </View>

      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: spacing.xl }}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            tintColor={colors.primaryLight}
            colors={[colors.primaryLight]}
          />
        }
      >
        <Text style={styles.sectionTitle}>MONITORING SYSTEM</Text>
        <View style={styles.grid}>
          <Card style={styles.gridCard}>
            <View style={styles.cardHeader}>
              <Ionicons name="server" size={24} color={monitoring?.status === 'running' ? colors.success : colors.danger} />
              <View style={[styles.dot, { backgroundColor: monitoring?.status === 'running' ? colors.success : colors.danger }]} />
            </View>
            <Text style={styles.cardLabel}>SERVER STATUS</Text>
            <Text style={styles.cardValue}>{monitoring?.status === 'running' ? 'Online' : 'Offline'}</Text>
            <Text style={styles.cardSubValue}>API responding correctly</Text>
          </Card>
          <Card style={styles.gridCard}>
            <View style={styles.cardHeader}>
              <Ionicons name="layers" size={24} color={monitoring?.db_connected ? colors.primaryLight : colors.danger} />
              <View style={[styles.dot, { backgroundColor: monitoring?.db_connected ? colors.primaryLight : colors.danger }]} />
            </View>
            <Text style={styles.cardLabel}>DB CONNECTION</Text>
            <Text style={styles.cardValue}>{monitoring?.db_connected ? 'Connected' : 'Disconnected'}</Text>
            <Text style={styles.cardSubValue}>Latency: {monitoring?.latency || '--'}ms</Text>
          </Card>
        </View>

        <Text style={styles.sectionTitle}>STATISTICS</Text>
        <View style={[styles.grid, { marginBottom: spacing.xl }]}>
          <Card style={styles.statCard}>
            <Text style={styles.statLabel}>Total Users</Text>
            <Text style={styles.statValue}>{stats?.totalUsers ?? '--'}</Text>
          </Card>
          <Card style={styles.statCard}>
            <Text style={styles.statLabel}>Total Posts</Text>
            <Text style={styles.statValue}>{stats?.totalPosts ?? '--'}</Text>
          </Card>
          <Card style={styles.statCard}>
            <Text style={styles.statLabel}>Total Reports</Text>
            <Text style={styles.statValue}>{stats?.totalReports ?? '--'}</Text>
          </Card>
        </View>

        <Text style={styles.sectionTitle}>MANAGEMENT</Text>
        <View style={styles.cardGroup}>
          <ActionRow
            title="Manage Users"
            icon="people"
            onPress={() => router.push('/admin/manage-users' as any)}
          />
          <ActionRow
            title="Manage Posts"
            icon="document-text"
            onPress={() => router.push('/admin/manage-posts' as any)}
          />
          <ActionRow
            title="Manage Reports"
            icon="alert-circle"
            onPress={() => router.push('/admin/manage-reports' as any)}
          />
        </View>

        <View style={{ height: spacing.xxl }} />
      </ScrollView>
    </Screen>
  );
}

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: spacing.md,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
    marginBottom: spacing.lg,
  },
  headerTitles: {
    alignItems: 'flex-start',
  },
  logoutButton: {
    padding: spacing.xs,
  },
  title: {
    ...typography.h2,
  },
  subtitle: {
    ...typography.caption,
  },
  sectionTitle: {
    ...typography.caption,
    textTransform: 'uppercase',
    letterSpacing: 1,
    marginBottom: spacing.sm,
    marginLeft: spacing.sm,
  },
  grid: {
    flexDirection: 'row',
    gap: spacing.md,
    marginBottom: spacing.xl,
  },
  gridCard: {
    flex: 1,
    padding: spacing.lg,
    backgroundColor: colors.surfaceHighlight,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: spacing.md,
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  cardLabel: {
    ...typography.caption,
    textTransform: 'uppercase',
    marginBottom: spacing.xs,
  },
  cardValue: {
    ...typography.h2,
    marginBottom: spacing.xs,
  },
  cardSubValue: {
    ...typography.caption,
  },
  cardGroup: {
    backgroundColor: colors.surfaceHighlight,
    borderRadius: 24,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: colors.border,
  },
  statCard: {
    flex: 1,
    padding: spacing.md,
    alignItems: 'center',
    backgroundColor: colors.surfaceHighlight,
  },
  statLabel: {
    ...typography.caption,
    fontSize: 10,
    color: colors.textSecondary,
    marginBottom: spacing.xs,
  },
  statValue: {
    ...typography.h2,
    fontSize: 20,
  },
});