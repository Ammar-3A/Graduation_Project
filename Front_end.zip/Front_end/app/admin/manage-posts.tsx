import React, { useState } from 'react';
import { StyleSheet, Text, View, FlatList, TextInput, Image, TouchableOpacity, Alert, ActivityIndicator } from 'react-native';
import { Screen } from '../../src/components/Screen';
import { Card } from '../../src/components/Card';
import { typography } from '../../src/theme/typography';
import { spacing } from '../../src/theme/spacing';
import { colors } from '../../src/theme/colors';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { BottomSheet, BottomSheetAction } from '../../src/components/BottomSheet';
import { ImageViewerModal } from '../../src/components/ImageViewerModal';
import { adminService } from '../../src/api/services/adminService';

const PLACEHOLDER = require('../../src/images/placeholder.png');

const resolveImage = (item: any) => {
  const uri = item?.image;
  if (!uri) return PLACEHOLDER;
  return { uri };
};

export default function ManagePostsScreen() {
  const router = useRouter();
  const [posts, setPosts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedPostId, setSelectedPostId] = useState<number | null>(null);
  const [isViewerVisible, setIsViewerVisible] = useState(false);
  const [viewerItem, setViewerItem] = useState<any>(null);

  const fetchPosts = async () => {
    try {
      setLoading(true);
      const data = await adminService.getPosts();
      setPosts(data.posts);
    } catch (err) {
      console.error('Error fetching posts:', err);
      Alert.alert('Error', 'Failed to fetch posts');
    } finally {
      setLoading(false);
    }
  };

  React.useEffect(() => {
    fetchPosts();
  }, []);

  const filteredPosts = posts.filter(p => {
    const query = searchQuery.trim().toLowerCase();
    if (!query) return true;

    const itemName = (p.item_name || '').toLowerCase();
    const itemId = (p.id || '').toString();

    return itemName.includes(query) || itemId.includes(query);
  });

  const selectedPost = posts.find(p => p.id === selectedPostId);

  const actions: BottomSheetAction[] = selectedPost ? [
    {
      id: 'view',
      label: 'View Post',
      icon: 'eye-outline',
      onPress: () => {
        setViewerItem(selectedPost);
        setIsViewerVisible(true);
        setSelectedPostId(null);
      }
    },
    {
      id: 'delete',
      label: 'Delete Post',
      icon: 'trash-outline',
      destructive: true,
      onPress: async () => {
        Alert.alert(
          'Confirm Delete',
          'Are you sure you want to delete this post permanently?',
          [
            { text: 'Cancel', style: 'cancel' },
            {
              text: 'Confirm',
              style: 'destructive',
              onPress: async () => {
                try {
                  await adminService.deletePost(selectedPost.id);
                  Alert.alert('Success', 'Post deleted');
                  fetchPosts();
                } catch (err) {
                  Alert.alert('Error', 'Failed to delete post');
                }
              }
            }
          ]
        );
      }
    }
  ] : [];

  return (
    <Screen style={styles.container} safeArea>
      <View style={styles.header}>
        <Ionicons name="arrow-back" size={24} color={colors.text} onPress={() => router.back()} />
        <Text style={styles.headerTitle}>Manage Posts</Text>
        <View style={{ width: 24 }} />
      </View>

      <View style={styles.searchContainer}>
        <Ionicons name="search" size={20} color={colors.textSecondary} />
        <TextInput
          style={styles.searchInput}
          placeholder="Search by title or ID..."
          placeholderTextColor={colors.textSecondary}
          value={searchQuery}
          onChangeText={setSearchQuery}
          keyboardType="default"
          autoCapitalize="none"
        />
      </View>

      {loading && posts.length === 0 ? (
        <View style={styles.center}>
          <ActivityIndicator color={colors.primaryLight} />
        </View>
      ) : (
        <FlatList
          data={filteredPosts}
          keyExtractor={item => (item.id ?? item.post_id ?? Math.random()).toString()}
          contentContainerStyle={styles.list}
          showsVerticalScrollIndicator={false}
          renderItem={({ item }) => (
            <Card style={styles.card}>
              <View style={styles.cardRow}>
                <Image
                  source={resolveImage(item)}
                  style={styles.imageThumb}
                />
                <View style={styles.itemInfo}>
                  <Text style={styles.itemTitle} numberOfLines={1}>{item.item_name}</Text>
                  <Text style={styles.itemPrice}>{item.price} SAR</Text>

                  <View style={styles.statusRow}>
                    <Text style={styles.itemId}>Post ID: {item.id}</Text>
                  </View>
                  <Text style={styles.txt}>Category: {item.category}</Text>

                  <View style={styles.sellerDetails}>
                    <Text style={styles.sellerLabel}>Seller Info:</Text>
                    <Text style={styles.sellerValue}>Seller ID: {item.seller_id}</Text>
                    <Text style={styles.sellerValue}>Name: {item.seller_name}</Text>
                    <Text style={styles.sellerValue}>Email: {item.seller_email}</Text>
                    <Text style={styles.sellerValue}>Phone: {item.seller_phone}</Text>
                  </View>
                </View>
              </View>
              <View style={styles.divider} />
              <TouchableOpacity
                style={styles.manageButton}
                onPress={() => setSelectedPostId(item.id)}
              >
                <Text style={styles.manageButtonText}>Moderate Post</Text>
                <Ionicons name="chevron-down" size={16} color={colors.primaryLight} />
              </TouchableOpacity>
            </Card>
          )}
        />
      )}


      <BottomSheet
        visible={!!selectedPostId}
        onClose={() => setSelectedPostId(null)}
        title={selectedPost ? 'Moderate Post' : ''}
        actions={actions}
      />

      <ImageViewerModal
        visible={isViewerVisible}
        item={viewerItem}
        onClose={() => {
          setIsViewerVisible(false);
          setViewerItem(null);
        }}
        mode="full"
      />
    </Screen>
  );
}

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: spacing.md,
  },
  center: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: spacing.md,
    marginBottom: spacing.sm,
  },
  headerTitle: {
    ...typography.h2,
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.surfaceHighlight,
    borderRadius: 16,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    marginBottom: spacing.lg,
    gap: spacing.sm,
    borderWidth: 1,
    borderColor: colors.border,
  },
  searchInput: {
    flex: 1,
    ...typography.body,
    color: colors.text,
    height: 32,
  },
  list: {
    gap: spacing.md,
    paddingBottom: spacing.xxl,
  },
  card: {
    padding: spacing.md,
    backgroundColor: '#1E2532',
    borderColor: '#2E3A4E',
  },
  cardRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: spacing.md,
  },
  imageThumb: {
    width: 64,
    height: 64,
    borderRadius: 12,
    backgroundColor: colors.surfaceHighlight,
  },
  itemInfo: {
    flex: 1,
  },
  itemTitle: {
    ...typography.h3,
    marginBottom: 2,
  },
  itemPrice: {
    ...typography.body,
    color: colors.primaryLight,
    fontWeight: 'bold',
    marginBottom: 2,
  },
  txt: {
    ...typography.caption,
    color: colors.textSecondary,
    marginBottom: 6,
  },
  statusRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
    flexWrap: 'wrap',
  },
  sellerDetails: {
    marginTop: 8,
    padding: 8,
    backgroundColor: colors.surfaceHighlight,
    borderRadius: 8,
    gap: 2,
  },
  sellerLabel: {
    ...typography.caption,
    fontWeight: 'bold',
    color: colors.primaryLight,
    marginBottom: 2,
  },
  sellerValue: {
    ...typography.caption,
    color: colors.text,
  },
  itemId: {
    ...typography.caption,
    color: colors.textSecondary,
    marginRight: spacing.sm,
  },
  divider: {
    height: 1,
    backgroundColor: '#2E3A4E',
    marginVertical: spacing.md,
  },
  manageButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.xs,
    paddingVertical: spacing.xs,
  },
  manageButtonText: {
    ...typography.body,
    color: colors.primaryLight,
    fontWeight: '600',
  },
});