import React, { useState, useCallback } from 'react';
import { StyleSheet, Text, View, FlatList, TextInput, TouchableOpacity, Alert, ActivityIndicator } from 'react-native';
import { Screen } from '../../src/components/Screen';
import { Card } from '../../src/components/Card';
import { useAppStore, getFullName } from '../../src/store/useAppStore';
import { typography } from '../../src/theme/typography';
import { spacing } from '../../src/theme/spacing';
import { colors } from '../../src/theme/colors';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { BottomSheet, BottomSheetAction } from '../../src/components/BottomSheet';
import { PillTag } from '../../src/components/PillTag';
import { adminService } from '../../src/api/services/adminService';

export default function ManageUsersScreen() {
  const router = useRouter();
  const [users, setUsers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedUserId, setSelectedUserId] = useState<number | null>(null);

  const fetchUsers = async () => {
    try {
      setLoading(true);
      const data = await adminService.getUsers();
      setUsers(data.users);
    } catch (err) {
      console.error('Error fetching users:', err);
      Alert.alert('Error', 'Failed to fetch users');
    } finally {
      setLoading(false);
    }
  };

  React.useEffect(() => {
    fetchUsers();
  }, []);

  const sortedUsers = [...users].sort((a, b) => a.id - b.id);

  const filteredUsers = sortedUsers.filter(u =>
    (u.name || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
    u.id.toString().includes(searchQuery)
  );

  const selectedUser = users.find(u => u.id === selectedUserId);

  const toggleUserStatus = async (user: any) => {
    try {
      if (user.is_active !== false) {
        await adminService.suspendUser(user.id);
        Alert.alert('Success', 'User suspended');
      } else {
        await adminService.activateUser(user.id);
        Alert.alert('Success', 'User activated');
      }
      await fetchUsers();
      setSelectedUserId(null);
    } catch (err) {
      Alert.alert('Error', 'Failed to update user status');
    }
  };

  const actions: BottomSheetAction[] = selectedUser ? [
    {
      id: 'suspend',
      label: selectedUser.is_active !== false ? 'Suspend User' : 'Activate User',
      icon: selectedUser.is_active !== false ? 'warning-outline' : 'checkmark-circle-outline',
      destructive: selectedUser.is_active !== false,
      onPress: () => toggleUserStatus(selectedUser)
    }
  ] : [];

  return (
    <Screen style={styles.container} safeArea>
      <View style={styles.header}>
        <Ionicons name="arrow-back" size={24} color={colors.text} onPress={() => router.back()} />
        <Text style={styles.headerTitle}>Manage Users</Text>
        <View style={{ width: 24 }} />
      </View>

      <View style={styles.searchContainer}>
        <Ionicons name="search" size={20} color={colors.textSecondary} />
        <TextInput
          style={styles.searchInput}
          placeholder="Search by name or ID..."
          placeholderTextColor={colors.textSecondary}
          value={searchQuery}
          onChangeText={setSearchQuery}
        />
      </View>

      {loading && users.length === 0 ? (
        <View style={styles.center}>
          <ActivityIndicator color={colors.primaryLight} />
        </View>
      ) : (
        <FlatList
          data={filteredUsers}
          keyExtractor={item => item.id.toString()}
          contentContainerStyle={styles.list}
          showsVerticalScrollIndicator={false}
          renderItem={({ item }) => (
            <Card style={styles.card}>
              <View style={styles.cardRow}>
                <View style={styles.avatarContainer}>
                  <Ionicons name="person-circle" size={64} color={colors.textSecondary} />
                </View>
                <View style={styles.userInfo}>
                  <Text style={styles.userName}>{getFullName(item)}</Text>
                  <View style={styles.statusRow}>
                    <Text style={styles.userId}>ID: {item.id}</Text>
                    <PillTag
                      label={(item.is_active !== false ? 'active' : 'suspended').toUpperCase()}
                      color={item.is_active !== false ? colors.success : colors.danger}
                    />
                    {item.isAdmin && <PillTag label="ADMIN" color={colors.primaryLight} />}
                  </View>
                </View>
              </View>
              <View style={styles.divider} />
              <TouchableOpacity
                style={styles.manageButton}
                onPress={() => setSelectedUserId(item.id)}
              >
                <Text style={styles.manageButtonText}>Manage</Text>
                <Ionicons name="chevron-down" size={16} color={colors.primaryLight} />
              </TouchableOpacity>
            </Card>
          )}
        />
      )}

      <BottomSheet
        visible={!!selectedUserId}
        onClose={() => setSelectedUserId(null)}
        title={selectedUser ? `Manage ${getFullName(selectedUser)}` : ''}
        actions={actions}
      />
    </Screen>
  );
}

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: spacing.md,
  },
  center: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: spacing.md,
    marginBottom: spacing.sm,
  },
  headerTitle: {
    ...typography.h2,
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.surfaceHighlight,
    borderRadius: 16,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    marginBottom: spacing.lg,
    gap: spacing.sm,
    borderWidth: 1,
    borderColor: colors.border,
  },
  searchInput: {
    flex: 1,
    ...typography.body,
    color: colors.text,
    height: 32,
  },
  list: {
    gap: spacing.md,
    paddingBottom: spacing.xxl,
  },
  card: {
    padding: spacing.md,
    backgroundColor: '#1E2532',
    borderColor: '#2E3A4E',
  },
  cardRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
  },
  avatarContainer: {
    width: 64,
    height: 64,
    justifyContent: 'center',
    alignItems: 'center',
  },
  userInfo: {
    flex: 1,
  },
  userName: {
    ...typography.h3,
    marginBottom: 2,
  },
  statusRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
  },
  userId: {
    ...typography.caption,
    color: colors.textSecondary,
    marginRight: spacing.sm,
  },
  divider: {
    height: 1,
    backgroundColor: '#2E3A4E',
    marginVertical: spacing.md,
  },
  manageButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.xs,
    paddingVertical: spacing.xs,
  },
  manageButtonText: {
    ...typography.body,
    color: colors.primaryLight,
    fontWeight: '600',
  },
});