import React, { useState, useEffect } from 'react';
import { StyleSheet, Text, View, FlatList, TouchableOpacity, Alert, ActivityIndicator } from 'react-native';
import { Screen } from '../../src/components/Screen';
import { Card } from '../../src/components/Card';
import { typography } from '../../src/theme/typography';
import { spacing } from '../../src/theme/spacing';
import { colors } from '../../src/theme/colors';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { adminService } from '../../src/api/services/adminService';

export default function ManageReportsScreen() {
  const router = useRouter();
  const [reports, setReports] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const fetchReports = async () => {
    try {
      setLoading(true);
      const data = await adminService.getReports();
      setReports(data.reports);
    } catch (err) {
      console.error('Error fetching reports:', err);
      Alert.alert('Error', 'Failed to fetch reports');
    } finally {
      setLoading(false);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    try {
      const data = await adminService.getReports();
      setReports(data.reports);
    } catch (err) {
      console.error('Error refreshing reports:', err);
    } finally {
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchReports();
  }, []);

  const handleResolve = async (reportId: number) => {
    Alert.alert(
      'Confirm Resolve',
      'Are you sure you want to mark this report as resolved?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Resolve',
          onPress: async () => {
            try {
              await adminService.resolveReport(reportId);
              Alert.alert('Success', 'The report has been marked as resolved.');
              fetchReports();
            } catch (err) {
              console.error('Error resolving report:', err);
              Alert.alert('Error', 'Failed to resolve report');
            }
          }
        }
      ]
    );
  };

  const renderReportItem = ({ item }: { item: any }) => (
    <Card style={styles.reportCard}>
      <View style={styles.reportHeader}>
        <View style={styles.reportInfo}>
          <Text style={styles.reasonLabel}>REASON:</Text>
          <Text style={styles.reasonText}>{item.reason}</Text>
        </View>
        <Ionicons name="warning" size={24} color={colors.warning} />
      </View>

      <View style={styles.detailRow}>
        <Text style={styles.detailLabel}>Report ID</Text>
        <Text style={styles.detailValue}>{item.id}</Text>
      </View>

      <View style={styles.detailRow}>
        <Text style={styles.detailLabel}>Reporter ID:</Text>
        <Text style={styles.detailValue}>{item.reporter_id}</Text>
      </View>

      <View style={styles.detailRow}>
        <Text style={styles.detailLabel}>Item ID (Post):</Text>
        <Text style={styles.detailValue}>{item.item_id}</Text>
      </View>

      <View style={styles.detailRow}>
        <Text style={styles.detailLabel}>Post Status:</Text>
        <Text style={styles.detailValue}>{item.post_status}</Text>
      </View>

      <View style={styles.actions}>
        <TouchableOpacity
          style={styles.resolveButton}
          onPress={() => handleResolve(item.id)}
        >
          <Ionicons name="checkmark-circle" size={18} color={colors.text} />
          <Text style={styles.resolveButtonText}>Mark Resolved</Text>
        </TouchableOpacity>
      </View>
    </Card>
  );

  return (
    <Screen style={styles.container} safeArea>
      <View style={styles.header}>
        <Ionicons name="arrow-back" size={24} color={colors.text} onPress={() => router.back()} />
        <Text style={styles.title}>Manage Reports</Text>
        <View style={{ width: 24 }} />
      </View>

      {loading ? (
        <ActivityIndicator size="large" color={colors.primaryLight} style={{ marginTop: spacing.xxl }} />
      ) : (
        <FlatList
          data={reports}
          renderItem={renderReportItem}
          keyExtractor={(item) => item.id.toString()}
          contentContainerStyle={styles.listContent}
          ListEmptyComponent={
            <View style={styles.emptyContainer}>
              <Ionicons name="checkmark-circle-outline" size={64} color={colors.textSecondary} />
              <Text style={styles.emptyText}>All caught up! No active reports.</Text>
            </View>
          }
          refreshing={refreshing}
          onRefresh={onRefresh}
        />
      )}
    </Screen>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  title: {
    ...typography.h2,
  },
  listContent: {
    padding: spacing.md,
  },
  reportCard: {
    marginBottom: spacing.md,
    padding: spacing.md,
  },
  reportHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: spacing.md,
  },
  reportInfo: {
    flex: 1,
  },
  reasonLabel: {
    ...typography.caption,
    color: colors.textSecondary,
    marginBottom: spacing.xs,
  },
  reasonText: {
    ...typography.body,
    fontWeight: '600',
  },
  detailRow: {
    flexDirection: 'row',
    marginBottom: spacing.xs,
  },
  detailLabel: {
    ...typography.caption,
    width: 100,
    color: colors.textSecondary,
  },
  detailValue: {
    ...typography.caption,
    fontWeight: '600',
  },
  actions: {
    marginTop: spacing.md,
  },
  resolveButton: {
    backgroundColor: colors.primary,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.sm,
    paddingVertical: 12,
    borderRadius: 12,
    shadowColor: colors.primary,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 4,
  },
  resolveButtonText: {
    ...typography.body,
    fontWeight: '700',
    color: colors.text,
  },
  emptyContainer: {
    alignItems: 'center',
    marginTop: spacing.xxl,
    gap: spacing.md,
  },
  emptyText: {
    ...typography.body,
    color: colors.textSecondary,
    textAlign: 'center',
  },
});
