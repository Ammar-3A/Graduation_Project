"""
TUMB MCP Server

Exposes every ActionService method as an MCP tool.
Started automatically as a subprocess by the LLM agent.

"""
import asyncio
import json
import os
import sys

# Ensure the project root is on sys.path when launched as a subprocess
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp import types

from persistence.database import AsyncSessionLocal
from persistence.repository import (
    UserRepository, PostRepository,
    ReportRepository, RequestRepository,
)
from application.action_service import ActionService, ActionContext
from application.exceptions import ActionError

# server instance

server = Server("tumb-mcp")


async def _make_service():
    """Create a fresh ActionService with its own DB session."""
    session = AsyncSessionLocal()
    service = ActionService(
        user_repo=UserRepository(session),
        post_repo=PostRepository(session),
        report_repo=ReportRepository(session),
        request_repo=RequestRepository(session),
        
    )
    return service, session


# ── tool list ─────────────────────────────────────────────────────────────────

@server.list_tools()
async def list_tools() -> list[types.Tool]:
    return [

        types.Tool(
            name="search_posts",
            description=(
                "Search marketplace listings by item name and/or category. "
                "Returns up to 4 results with cursor-based pagination. "
                "Pass 'skip' as item_name to search by category only."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "item_name": {"type": "string", "description": "Keyword to search. Use 'skip' to ignore."},
                    "category":  {"type": "string", "description": "lab equipment | clothing | electronics"},
                    "cursor":    {"type": "integer", "description": "Last post ID from previous page for pagination"},
                    "user_id":   {"type": "integer"},
                },
                "required": ["user_id"],
            },
        ),

        types.Tool(
            name="create_post",
            description="Create a new listing to sell an item on the marketplace.",
            inputSchema={
                "type": "object",
                "properties": {
                    "item_name":   {"type": "string", "description": "Title of the listing (min 3 chars)"},
                    "category":    {"type": "string", "description": "lab equipment | clothing | electronics"},
                    "price":       {"type": "integer", "description": "Price in SAR"},
                    "description": {"type": "string", "description": "Item description (min 20 chars)"},
                    "quantity":    {"type": "integer", "description": "Available quantity"},
                    "image":       {"type": "string",  "description": "Optional image URL"},
                    "user_id":     {"type": "integer"},
                },
                "required": ["item_name", "category", "price", "description", "quantity", "user_id"],
            },
        ),

        types.Tool(
            name="buy_post",
            description="Send a purchase request to the seller of a listing. Returns seller contact info on success.",
            inputSchema={
                "type": "object",
                "properties": {
                    "post_id":  {"type": "integer", "description": "ID of the post to buy"},
                    "quantity": {"type": "integer", "description": "Number of items to buy (default 1)"},
                    "user_id":  {"type": "integer"},
                },
                "required": ["post_id", "user_id"],
            },
        ),

        types.Tool(
            name="compare_posts",
            description="Compare two listings side-by-side and get a best-value recommendation based on price.",
            inputSchema={
                "type": "object",
                "properties": {
                    "post_id_1": {"type": "integer"},
                    "post_id_2": {"type": "integer"},
                    "user_id":   {"type": "integer"},
                },
                "required": ["post_id_1", "post_id_2", "user_id"],
            },
        ),

        types.Tool(
            name="report_post",
            description="Report a listing for violating marketplace rules.",
            inputSchema={
                "type": "object",
                "properties": {
                    "post_id": {"type": "integer"},
                    "reason":  {"type": "string", "description": "Reason for reporting (min 10 chars)"},
                    "user_id": {"type": "integer"},
                },
                "required": ["post_id", "reason", "user_id"],
            },
        ),

        types.Tool(
            name="update_post",
            description="Update one or more fields of the user's own listing.",
            inputSchema={
                "type": "object",
                "properties": {
                    "post_id":     {"type": "integer"},
                    "item_name":   {"type": "string"},
                    "category":    {"type": "string", "description": "lab equipment | clothing | electronics"},
                    "price":       {"type": "integer"},
                    "description": {"type": "string"},
                    "quantity":    {"type": "integer"},
                    "image":       {"type": "string"},
                    "user_id":     {"type": "integer"},
                },
                "required": ["post_id", "user_id"],
            },
        ),

        types.Tool(
            name="delete_post",
            description="Permanently delete the user's own listing.",
            inputSchema={
                "type": "object",
                "properties": {
                    "post_id": {"type": "integer"},
                    "user_id": {"type": "integer"},
                },
                "required": ["post_id", "user_id"],
            },
        ),

        types.Tool(
            name="get_my_posts",
            description="List all active listings created by the current user, with pagination.",
            inputSchema={
                "type": "object",
                "properties": {
                    "cursor":  {"type": "integer", "description": "Last post ID from previous page"},
                    "user_id": {"type": "integer"},
                },
                "required": ["user_id"],
            },
        ),

        types.Tool(
            name="get_my_requests",
            description="List all purchase requests the user has sent, including seller contact details.",
            inputSchema={
                "type": "object",
                "properties": {
                    "user_id": {"type": "integer"},
                },
                "required": ["user_id"],
            },
        ),

        types.Tool(
            name="get_recommendations",
            description="Get personalised listing recommendations based on the user's registered interest/category.",
            inputSchema={
                "type": "object",
                "properties": {
                    "user_id": {"type": "integer"},
                },
                "required": ["user_id"],
            },
        ),
    ]


# tool execution

@server.call_tool()
async def call_tool(name: str, arguments: dict) -> list[types.TextContent]:
    service, session = await _make_service()
    user_id = int(arguments.get("user_id", 0))

    try:
        result = await _dispatch(name, arguments, user_id, service)
    except ActionError as e:
        result = {"error": e.message}
    except Exception as e:
        result = {"error": str(e)}
    finally:
        await session.close()

    return [types.TextContent(type="text", text=json.dumps(result, default=str))]


async def _dispatch(name: str, args: dict, user_id: int, service: ActionService) -> dict:
    """Route tool name → ActionService call."""

    if name == "search_posts":
        ctx = ActionContext(user_id=user_id, data={
            "item_name": args.get("item_name"),
            "category":  args.get("category"),
            "last_id":   args.get("cursor"),
        })
        return (await service.execute("search_post", ctx))["action_data"]

    elif name == "create_post":
        ctx = ActionContext(user_id=user_id, data={
            "item_name":   args["item_name"],
            "category":    args["category"],
            "price":       args["price"],
            "description": args["description"],
            "quantity":    args.get("quantity", 1),
            "image":       args.get("image"),
        })
        return (await service.execute("create_post", ctx))["action_data"]

    elif name == "buy_post":
        ctx = ActionContext(user_id=user_id, data={
            "post_id":  args["post_id"],
            "quantity": args.get("quantity", 1),
        })
        return (await service.execute("create_request", ctx))["action_data"]

    elif name == "compare_posts":
        ctx = ActionContext(user_id=user_id, data={
            "post_id_1": args["post_id_1"],
            "post_id_2": args["post_id_2"],
        })
        return (await service.execute("compare_posts", ctx))["action_data"]

    elif name == "report_post":
        ctx = ActionContext(user_id=user_id, data={
            "report_item_id": args["post_id"],
            "report_reason":  args["reason"],
        })
        return (await service.execute("report_post", ctx))["action_data"]

    elif name == "update_post":
        data = {k: v for k, v in args.items() if k != "user_id"}
        ctx = ActionContext(user_id=user_id, data=data)
        return (await service.execute("update_post", ctx))["action_data"]

    elif name == "delete_post":
        ctx = ActionContext(user_id=user_id, data={"post_id": args["post_id"]})
        return (await service.execute("delete_post", ctx))["action_data"]

    elif name == "get_my_posts":
        ctx = ActionContext(user_id=user_id, data={"last_id": args.get("cursor")})
        return (await service.execute("user_posts", ctx))["action_data"]

    elif name == "get_my_requests":
        ctx = ActionContext(user_id=user_id, data={})
        return (await service.execute("user_requests", ctx))["action_data"]

    elif name == "get_recommendations":
        ctx = ActionContext(user_id=user_id, data={})
        return (await service.get_recommendations(ctx))

    else:
        return {"error": f"Unknown tool: {name}"}


# entry point

async def main():
    async with stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream,
            write_stream,
            server.create_initialization_options(),
        )


if __name__ == "__main__":
    asyncio.run(main())
