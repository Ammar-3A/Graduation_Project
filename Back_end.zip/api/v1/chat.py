from fastapi import APIRouter, Depends

from application.action_service import ActionService, ActionContext
from application.llm_agent import run_agent
from core.security import auth_user
from persistence.cache_store import CacheStore
from schemas.pydantic_model import ChatRequest, ChatResponse, ChatLoadRequest
from application.rule_engine.flow_manager import FlowManager, OutcomeStatus, FlowState
from api.dependencies import get_flow_manager, get_cache_store, get_action_service

router = APIRouter()


# Main chat endpoint.
# body: user message payload from the frontend.
# current_user: authenticated user from Bearer JWT token in Authorization header.
# - Validates the token and fetches the user from the database.
# - Raises HTTPException (401) if invalid or expired.
# flow_manager: manages intent detection and step processing, and other flow logic.
# cache: persists the user's flow state between requests.


@router.post("/chat", response_model=ChatResponse)
async def chat(
        body: ChatRequest,
        current_user=Depends(auth_user),
        flow_manager: FlowManager = Depends(get_flow_manager),
        cache: CacheStore = Depends(get_cache_store),
):
    if body.mode == "llm":
        try:
            agent_result = await run_agent(
                user_id=current_user.id,
                name=current_user.name,
                messages=body.history
            )
            return ChatResponse(
                messages=[agent_result["reply"]],
                status="success",
                data=agent_result.get("data"),
            )
        except Exception as e:
            return ChatResponse(
                messages=[f"LLM Agent Error: {str(e)}"],
                status="error",
            )

    # Retrieve the user's active flow from the cache, if any.
    # The cache stores the flow state as a dict type, so we convert the dict to FlowState.
    # If nothing is cached, the user has no active flow (flow_state = None).
    raw_state = await cache.get(current_user.id)
    flow_state = FlowState(**raw_state) if raw_state else None

    # Pass the user's message and current flow state to the FlowManager to process.
    flow_outcome = await flow_manager.handle_input(
        user_id=current_user.id,
        message=body.message,
        flow_state=flow_state,
    )

    # Update the cache based on the outcome:
    # TERMINATED or ERROR -> flow is done, clear the cache.
    # if flow_state exists -> flow is still active, save the updated state.
    if flow_outcome.status in [OutcomeStatus.TERMINATED, OutcomeStatus.ERROR]:
        await cache.clear(current_user.id)
    elif flow_outcome.flow_state:
        await cache.save(current_user.id, flow_outcome.flow_state.to_dict())

    # Send the result back to the client:
    # messages: the text to show the user (e.g. the next step's prompt or error message)
    # flow_state: the current flow state
    # status: whether the step passed, failed, terminated, or error
    # data: the final result if the flow completed (e.g. created post info), otherwise None
    return ChatResponse(
        messages=flow_outcome.messages,
        flow_state=flow_outcome.flow_state.to_dict() if flow_outcome.flow_state else None,
        status=flow_outcome.status,
        data=flow_outcome.data,
    )


# Loads more results for paginated actions (e.g. "user_posts", "search_post").
# The client sends the action name, the last seen ID (cursor), and the original filters
# that were returned from the first request.
# Example request body from the client:
# {
#     "action_name": "search_post",
#     "last_id": 12,
#     "filters": { "item_name": "laptop", "category": "electronics" }
# }
@router.post("/load-more")
async def chat_load(
        request: ChatLoadRequest,
        current_user=Depends(auth_user),
        action_service: ActionService = Depends(get_action_service)
):
    # Merge last_id and filters together, then execute (e.g, "user_posts", "search_post") the same action
    # to fetch more results starting after the last seen ID (last_id).
    ctx = ActionContext(
        user_id=current_user.id,
        data={
            "last_id": request.last_id,
            **request.filters
        }
    )
    return await action_service.execute(request.action_name, ctx)
