from fastapi import APIRouter, Depends, HTTPException
from fastapi.security import OAuth2PasswordRequestForm

from api.dependencies import get_admin_service, get_auth_service
from application.admin_service import AdminService
from application.auth_service import AuthService
from application.exceptions import ApplicationError
from core.security import auth_admin
from persistence.ORM_model import Admin
from schemas.pydantic_model import AuthResponse, AdminCreate

router = APIRouter(prefix="/admin", tags=["Admin"])


@router.post("/register", response_model=AuthResponse)
async def register_admin_route(
        admin: AdminCreate,
        auth_service: AuthService = Depends(get_auth_service)
):
    try:
        return await auth_service.register_admin(admin)
    except ApplicationError as e:
        raise HTTPException(status_code=e.status_code, detail=e.message)


@router.post("/login", response_model=AuthResponse)
async def admin_login_route(
        credentials: OAuth2PasswordRequestForm = Depends(),
        auth_service: AuthService = Depends(get_auth_service)
):
    try:
        return await auth_service.login_admin(credentials.username, credentials.password)
    except ApplicationError as e:
        raise HTTPException(status_code=e.status_code, detail=e.message)


@router.get("/profile")
async def get_admin_profile_route(
        current_admin: Admin = Depends(auth_admin),
        admin_service: AdminService = Depends(get_admin_service)
):
    try:
        return await admin_service.get_admin_profile(current_admin.id)
    except ApplicationError as e:
        raise HTTPException(status_code=e.status_code, detail=e.message)


@router.get("/users")
async def get_all_users(
        admin_service: AdminService = Depends(get_admin_service),
        _admin=Depends(auth_admin)
):
    return await admin_service.get_all_users()


@router.get("/posts")
async def get_all_posts(
        admin_service: AdminService = Depends(get_admin_service),
        _admin=Depends(auth_admin)
):
    posts = await admin_service.get_all_posts()
    return posts


@router.get("/reports")
async def get_all_reports(
        admin_service: AdminService = Depends(get_admin_service),
        _admin=Depends(auth_admin)
):
    return await admin_service.get_all_reports()


@router.get("/stats")
async def get_stats(
        admin_service: AdminService = Depends(get_admin_service),
        _admin=Depends(auth_admin)
):
    return await admin_service.get_stats()


@router.post("/users/{user_id}/suspend")
async def suspend_user(
        user_id: int,
        admin_service: AdminService = Depends(get_admin_service),
        _admin=Depends(auth_admin)
):
    try:
        return await admin_service.suspend_user(user_id)
    except ApplicationError as e:
        raise HTTPException(status_code=e.status_code, detail=e.message)


@router.post("/users/{user_id}/activate")
async def activate_user(
        user_id: int,
        admin_service: AdminService = Depends(get_admin_service),
        _admin=Depends(auth_admin)
):
    try:
        return await admin_service.activate_user(user_id)
    except ApplicationError as e:
        raise HTTPException(status_code=e.status_code, detail=e.message)


@router.delete("/posts/{post_id}")
async def delete_post(
        post_id: int,
        admin_service: AdminService = Depends(get_admin_service),
        _admin=Depends(auth_admin)
):
    try:
        return await admin_service.delete_post(post_id)
    except ApplicationError as e:
        raise HTTPException(status_code=e.status_code, detail=e.message)


@router.get("/monitoring")
async def get_monitoring(
        admin_service: AdminService = Depends(get_admin_service),
        _admin=Depends(auth_admin)
):
    return await admin_service.get_monitoring_status()


@router.post("/reports/{report_id}/resolve")
async def resolve_report(
        report_id: int,
        admin_service: AdminService = Depends(get_admin_service),
        _admin=Depends(auth_admin)
):
    try:
        return await admin_service.resolve_report(report_id)
    except ApplicationError as e:
        raise HTTPException(status_code=e.status_code, detail=e.message)