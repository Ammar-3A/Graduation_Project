from fastapi import APIRouter, Depends, HTTPException
from api.dependencies import get_auth_service
from application.auth_service import AuthService, ApplicationError
from core.security import auth_user
from persistence.ORM_model import User
from schemas.pydantic_model import UserRegister
from schemas.pydantic_model import AuthResponse, RegisterResponse, VerifyOTPRequest, ResendOTPRequest
from fastapi.security import OAuth2PasswordRequestForm

router = APIRouter(prefix="/auth", tags=["Authentication"])
admin_router = APIRouter(prefix="/admin", tags=["Admin"])


@router.post("/register", response_model=RegisterResponse)
async def register_user_route(
        user: UserRegister,
        auth_service: AuthService = Depends(get_auth_service)
):
    try:
        return await auth_service.register_user(user)
    except ApplicationError as e:
        raise HTTPException(status_code=e.status_code, detail=e.message)


@router.post("/verify-registration", response_model=AuthResponse)
async def verify_registration_route(
        request: VerifyOTPRequest,
        auth_service: AuthService = Depends(get_auth_service)
):
    try:
        return await auth_service.verify_registration(request.email, request.otp)
    except ApplicationError as e:
        raise HTTPException(status_code=e.status_code, detail=e.message)


@router.post("/resend-otp", response_model=RegisterResponse)
async def resend_otp_route(
        request: ResendOTPRequest,
        auth_service: AuthService = Depends(get_auth_service)
):
    try:
        return await auth_service.resend_otp(request.email)
    except ApplicationError as e:
        raise HTTPException(status_code=e.status_code, detail=e.message)


@router.post("/login", response_model=AuthResponse)
async def login_user_route(
        credentials: OAuth2PasswordRequestForm = Depends(),
        auth_service: AuthService = Depends(get_auth_service)
):
    try:
        return await auth_service.login_user(credentials.username, credentials.password)
    except ApplicationError as e:
        raise HTTPException(status_code=e.status_code, detail=e.message)


@router.get("/profile")
async def get_profile(
        current_user: User = Depends(auth_user),
        auth_service: AuthService = Depends(get_auth_service)
):
    try:
        return await auth_service.get_user_profile(current_user.id)
    except ApplicationError as e:
        raise HTTPException(status_code=e.status_code, detail=e.message)
