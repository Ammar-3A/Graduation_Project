from fastapi import Depends
from sqlalchemy.ext.asyncio import AsyncSession
from application.action_service import ActionService
from application.admin_service import AdminService
from application.auth_service import AuthService
from application.rule_engine.flow_manager import FlowManager
from persistence.database import get_db
from persistence.redis import redis_client
from persistence.repository import UserRepository, PostRepository, ReportRepository, RequestRepository, AdminRepository
from persistence.cache_store import CacheStore


async def get_action_service(db: AsyncSession = Depends(get_db)):
    user_repo = UserRepository(db)
    post_repo = PostRepository(db)
    report_repo = ReportRepository(db)
    request_repo = RequestRepository(db)
    

    return ActionService(
        user_repo=user_repo,
        post_repo=post_repo,
        report_repo=report_repo,
        request_repo=request_repo,
        
    )


async def get_admin_service(db: AsyncSession = Depends(get_db)):
    user_repo = UserRepository(db)
    post_repo = PostRepository(db)
    report_repo = ReportRepository(db)
    admin_repo = AdminRepository(db)

    return AdminService(
        user_repo=user_repo,
        post_repo=post_repo,
        report_repo=report_repo,
        admin_repo=admin_repo
    )


async def get_flow_manager(
        action_service: ActionService = Depends(get_action_service),
):
    return FlowManager(action_service)


def get_auth_service(db: AsyncSession = Depends(get_db)):
    return AuthService(
        user_repo=UserRepository(db),
        admin_repo=AdminRepository(db)
    )


async def get_redis():
    return redis_client


async def get_cache_store(redis=Depends(get_redis)):
    return CacheStore(redis)