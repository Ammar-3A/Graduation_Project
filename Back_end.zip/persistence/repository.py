from typing import Generic, TypeVar, Type, Optional, Sequence
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, exists, update, delete, func
from sqlalchemy.orm import selectinload, joinedload
from persistence.ORM_model import User, Admin, Request, Post, Report
from schemas.pydantic_model import PostUpdate

T = TypeVar('T')


class BaseRepository(Generic[T]):
    def __init__(self, db: AsyncSession, model: Type[T]):
        self._db = db
        self.model = model

    async def get_by_id(self, obj_id: int) -> Optional[T]:
        result = await self._db.execute(
            select(self.model).where(self.model.id == obj_id)
        )
        return result.scalar_one_or_none()

    async def get_all(self) -> Sequence[T]:
        result = await self._db.execute(select(self.model))
        return result.scalars().all()

    async def create(self, entity: T) -> T:
        self._db.add(entity)
        await self._db.flush()
        await self._db.refresh(entity)
        return entity

    async def delete_by_id(self, obj_id: int) -> bool:
        result = await self._db.execute(
            update(self.model)
            .where(self.model.id == obj_id)
            .values(is_deleted=True)
        )

        await self._db.flush()
        return getattr(result, "rowcount", 0) > 0

    async def save(self):
        await self._db.commit()


class UserRepository(BaseRepository[User]):
    def __init__(self, db: AsyncSession):
        super().__init__(db, User)

    async def get_by_email(self, email: str) -> Optional[User]:
        result = await self._db.execute(
            select(User).where(User.email == email)
        )
        return result.scalar_one_or_none()

    async def create_user(self, name: str, email: str, phone_number: str, password: str, interest: str) -> User:
        new_user = User(
            name=name,
            email=email,
            phone_number=phone_number,
            password=password,
            interest=interest,
        )
        return await self.create(new_user)

    async def toggle_active_status(self, user_id: int, is_active: bool) -> Optional[User]:
        await self._db.execute(
            update(User).where(User.id == user_id).values(is_active=is_active)
        )
        await self._db.flush()
        return await self.get_by_id(user_id)


class AdminRepository(BaseRepository[Admin]):
    def __init__(self, db: AsyncSession):
        super().__init__(db, Admin)

    async def get_by_email(self, email: str) -> Optional[Admin]:
        result = await self._db.execute(
            select(Admin).where(Admin.email == email)
        )
        return result.scalar_one_or_none()

    async def create_admin(self, name: str, email: str, password: str) -> Admin:
        new_admin = Admin(name=name, email=email, password=password)
        return await self.create(new_admin)

    async def get_stats(self) -> dict:
        total_users = await self._db.scalar(select(func.count(User.id)))
        total_posts = await self._db.scalar(select(func.count(Post.id)))
        total_reports = await self._db.scalar(select(func.count(Report.id)))

        return {
            "totalUsers": total_users or 0,
            "totalPosts": total_posts or 0,
            "totalReports": total_reports or 0
        }


class PostRepository(BaseRepository[Post]):
    def __init__(self, db: AsyncSession):
        super().__init__(db, Post)

    async def create_post(
            self, item_name: str, price: int, description: str,
            category: str, quantity: int, seller_id: int, image: str
    ) -> Post:
        new_post = Post(
            item_name=item_name,
            price=price,
            description=description,
            category=category,
            quantity=quantity,
            seller_id=seller_id,
            image=image
        )
        return await self.create(new_post)

    async def update_post(self, post_id: int, update_data: PostUpdate) -> Optional[Post]:
        values = update_data.model_dump(exclude_unset=True)
        if values:
            await self._db.execute(
                update(Post).where(Post.id == post_id).values(**values)
            )
            await self._db.flush()
        return await self.get_by_id(post_id)

    async def search(
            self,
            user_id: int,
            name: Optional[str] = None,
            category: Optional[str] = None,
            last_id: Optional[int] = None,
            limit: int = 5
    ) -> Sequence[Post]:

        statement = select(Post).where(Post.quantity > 0, Post.seller_id != user_id, self.model.is_deleted == False)

        if name:
            statement = statement.where(Post.item_name.ilike(f"%{name}%"))
        if category:
            statement = statement.where(Post.category.ilike(category))
        if last_id:
            statement = statement.where(Post.id < last_id)

        statement = statement.options(selectinload(Post.seller)).order_by(Post.id.desc()).limit(limit)
        result = await self._db.execute(statement)
        return result.scalars().all()

    async def get_recommendations(self, user_id: int, user_interest: str, limit: int = 5) -> Sequence[Post]:
        result = await self._db.execute(
            select(Post)
            .where(Post.category == user_interest, Post.seller_id != user_id, self.model.is_deleted == False)
            .options(selectinload(Post.seller))
            .order_by(Post.id.desc())
            .limit(limit)
        )
        return result.scalars().all()

    async def get_by_seller_id(
            self,
            seller_id: int,
            last_id: Optional[int] = None,
            limit: int = 5
    ) -> Sequence[Post]:

        statement = select(Post).where(Post.seller_id == seller_id, self.model.is_deleted == False)

        if last_id:
            statement = statement.where(Post.id < last_id)

        statement = statement.options(selectinload(Post.seller)).order_by(Post.id.desc()).limit(limit)
        result = await self._db.execute(statement)
        return result.scalars().all()

    async def get_all_with_seller(self):
        statement = select(Post).where(self.model.is_deleted == False).options(joinedload(Post.seller))
        result = await self._db.execute(statement)
        return result.scalars().all()

    async def decrement_quantity(self, post_id: int, amount: int) -> bool:
        result = await self._db.execute(
            update(Post)
            .where(Post.id == post_id, Post.quantity >= amount, self.model.is_deleted == False)
            .values(quantity=Post.quantity - amount)
        )
        await self._db.flush()
        return getattr(result, "rowcount", 0) > 0

    async def get_by_id(self, post_id: int) -> Optional[Post]:
        statement = select(Post).where(Post.id == post_id, self.model.is_deleted == False)
        result = await self._db.execute(statement)
        return result.scalars().first()


class RequestRepository(BaseRepository[Request]):
    def __init__(self, db: AsyncSession):
        super().__init__(db, Request)

    async def create_request(self, post_id: int, buyer_id: int, seller_id: int, quantity: int) -> Request:
        new_request = Request(
            post_id=post_id,
            buyer_id=buyer_id,
            seller_id=seller_id,
            quantity=quantity
        )
        return await self.create(new_request)

    async def get_user_requests(self, buyer_id: int) -> Sequence[Request]:
        result = await self._db.execute(
            select(Request)
            .where(Request.buyer_id == buyer_id)
            .options(selectinload(Request.post), selectinload(Request.seller))
            .order_by(Request.created_at.desc())
        )
        return result.scalars().all()

    async def has_requested_post(self, buyer_id: int, post_id: int) -> bool:
        statement = select(exists().where(
            Request.buyer_id == buyer_id,
            Request.post_id == post_id
        ))
        result = await self._db.execute(statement)
        return result.scalar_one()


class ReportRepository(BaseRepository[Report]):
    def __init__(self, db: AsyncSession):
        super().__init__(db, Report)

    async def create_report(self, reporter_id: int, reported_id: int, item_id: int, reason: str) -> Report:
        new_report = Report(
            reporter_id=reporter_id,
            reported_id=reported_id,
            item_id=item_id,
            reason=reason
        )
        return await self.create(new_report)

    async def has_reported_item(self, reporter_id: int, item_id: int) -> bool:
        statement = select(
            exists().where(
                Report.reporter_id == reporter_id,
                Report.item_id == item_id
            )
        )
        result = await self._db.execute(statement)
        return result.scalar_one()

    async def resolve_report(self, report_id: int) -> bool:
        result = await self._db.execute(
            update(Report).where(Report.id == report_id).values(resolved=True)
        )
        await self._db.flush()
        return getattr(result, "rowcount", 0) > 0

    async def get_unresolved(self) -> list[Report]:
        statement = (
            select(Report)
            .options(joinedload(Report.post))
            .where(Report.resolved == False)
        )

        result = await self._db.execute(statement)
        return list(result.scalars().all())

    async def delete_reports_by_item_id(self, item_id: int):
        statement = delete(Report).where(Report.item_id == item_id)
        await self._db.execute(statement)