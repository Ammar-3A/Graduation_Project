import redis.asyncio as redis
from core.config import settings


def create_redis_client() -> redis.Redis:
    return redis.Redis(
        host=settings.REDIS_HOST,
        port=settings.REDIS_PORT,
        db=settings.REDIS_DB,
        decode_responses=True,
        password=settings.REDIS_PASSWORD
    )


redis_client = create_redis_client()


async def close_redis():
    await redis_client.aclose()
