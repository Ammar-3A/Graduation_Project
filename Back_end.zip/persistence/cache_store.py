import json
from typing import Optional, Dict, Any


class CacheStore:
    def __init__(self, redis, ttl=1800):
        self.redis = redis
        self.ttl = ttl

    @staticmethod
    def _gen_key(user_id: int):
        return f"flow_state:{user_id}"

    async def get(self, user_id: int) -> Optional[Dict[str, Any]]:
        raw_data = await self.redis.get(self._gen_key(user_id))
        return json.loads(raw_data) if raw_data else None

    async def save(self, user_id: int, flow_data: Dict[str, Any]):
        await self.redis.set(self._gen_key(user_id), json.dumps(flow_data), ex=self.ttl)

    async def clear(self, user_id: int):
        await self.redis.delete(self._gen_key(user_id))
