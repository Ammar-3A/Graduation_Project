import random
import json
from datetime import datetime, timedelta, timezone
import re

import jwt
from jwt.exceptions import InvalidTokenError
from password_strength import PasswordPolicy, tests
from pwdlib import PasswordHash
from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.ext.asyncio import AsyncSession
from persistence.redis import redis_client

from .config import settings
from persistence.database import get_db
from persistence.repository import UserRepository, AdminRepository
from persistence.ORM_model import User, Admin

user_oauth2_scheme = OAuth2PasswordBearer(
    tokenUrl="/auth/login",
    scheme_name="UserSecurity"
)

admin_oauth2_scheme = OAuth2PasswordBearer(
    tokenUrl="/admin/login",
    scheme_name="AdminSecurity"
)

password_hash = PasswordHash.recommended()

policy = PasswordPolicy.from_names(
    length=8,
    numbers=1,
    uppercase=1,
    # special=1,
)

def validate_university_email(email: str) -> str | None:
    pattern = r'^tu(3[5-9]|[4-9][0-9])\d{5}@taibahu\.edu\.sa$'

    if not re.match(pattern, email):
        return "Email must be a valid Taibah University email (e.g. TU4312345@taibahu.edu.sa)"

    return None


def get_password_errors(password: str) -> list[str]:
    failed = policy.test(password)

    messages = []
    for rule in failed:
        if isinstance(rule, tests.Length):
            messages.append("Password must be at least 8 characters long")
        elif isinstance(rule, tests.Numbers):
            messages.append("Password must contain at least one number")
        elif isinstance(rule, tests.Uppercase):
            messages.append("Password must contain at least one uppercase letter")
        # elif isinstance(rule, tests.Special):
        #     messages.append("Password must contain at least one special character")

    return messages


def validate_phone_number(phone: str) -> str | None:
    pattern = r'^0\d{9}$'

    if not re.match(pattern, phone):
        return "Phone number must start with 0 and be 10 digits long (e.g. 0501234567)"

    return None

def hash_password(password: str) -> str:
    return password_hash.hash(password)


def verify_password(plain_password: str, hashed_password: str) -> bool:
    return password_hash.verify(plain_password, hashed_password)


def create_access_token(data: dict, expires_delta: timedelta | None = None) -> str:
    to_encode = data.copy()

    expire = datetime.now(timezone.utc) + (
            expires_delta or timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    )
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, settings.SECRET_KEY, algorithm=settings.ALGORITHM)


def decode_access_token(token: str) -> dict | None:
    try:
        return jwt.decode(token, settings.SECRET_KEY, algorithms=[settings.ALGORITHM])
    except InvalidTokenError:
        return None


async def auth_user(
        db: AsyncSession = Depends(get_db),
        token: str = Depends(user_oauth2_scheme)
) -> User:
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )

    payload = decode_access_token(token)
    if not payload:
        raise credentials_exception

    email = payload.get("sub")
    user_type = payload.get("type")

    if not email or user_type != "user":
        raise credentials_exception

    user_repo = UserRepository(db)
    user = await user_repo.get_by_email(email)

    if not user:
        raise credentials_exception

    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Your account has been suspended"
        )

    return user


async def auth_admin(
        db: AsyncSession = Depends(get_db),
        token: str = Depends(admin_oauth2_scheme)
) -> Admin:
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Admin authentication required",
        headers={"WWW-Authenticate": "Bearer"},
    )

    payload = decode_access_token(token)
    if not payload:
        raise credentials_exception

    email = payload.get("sub")
    user_type = payload.get("type")

    if not email or user_type != "admin":
        raise credentials_exception

    admin_repo = AdminRepository(db)
    admin = await admin_repo.get_by_email(email)

    if not admin:
        raise credentials_exception

    return admin


def generate_otp() -> str:
    return str(random.randint(100000, 999999))


async def save_pending_user(email: str, user_data: dict, otp: str):
    data = {
        "user_data": user_data,
        "otp": otp
    }
    await redis_client.setex(f"register_otp:{email}", 180, json.dumps(data))


async def verify_otp(email: str, otp: str) -> dict | None:
    data_str = await redis_client.get(f"register_otp:{email}")
    if not data_str:
        return None
    data = json.loads(data_str)
    if data["otp"] == otp:
        return data["user_data"]
    return None
