from application.exceptions import ApplicationError
from core.security import hash_password, verify_password, create_access_token, get_password_errors, \
    validate_university_email, validate_phone_number
from persistence.repository import UserRepository, AdminRepository
from core.security import generate_otp, save_pending_user
from application.email_service import EmailService
from core.security import verify_otp
from persistence.redis import redis_client
import json
import asyncio


class AuthService:
    def __init__(self, user_repo: UserRepository, admin_repo: AdminRepository):
        self.user_repo = user_repo
        self.admin_repo = admin_repo

    async def register_user(self, user) -> dict:

        print(user.email)

        email_error = validate_university_email(user.email)
        if email_error:
            raise ApplicationError(email_error, status_code=422)

        phone_error = validate_phone_number(user.phone_number)
        if phone_error:
            raise ApplicationError(phone_error, status_code=422)

        pass_error = get_password_errors(user.password)
        if pass_error:
            raise ApplicationError("\n".join(pass_error), status_code=422)

        existing = await self.user_repo.get_by_email(user.email)
        if existing:
            raise ApplicationError("Email already registered", status_code=409)

        hashed_password = hash_password(user.password)
        user_data = {
            "name": user.name,
            "email": user.email,
            "phone_number": user.phone_number,
            "password": hashed_password,
            "interest": user.interest
        }

        otp = generate_otp()
        await save_pending_user(user.email, user_data, otp)

        email_service = EmailService()
        _email_sent_task = asyncio.create_task(email_service.send_otp_email(user.email, otp))

        return {"message": "OTP sent to email", "expires_in": 180}

    async def verify_registration(self, email: str, otp: str) -> dict:

        user_data = await verify_otp(email, otp)
        if not user_data:
            raise ApplicationError("Invalid or expired OTP", status_code=400)

        new_user = await self.user_repo.create_user(
            name=user_data["name"],
            email=user_data["email"],
            phone_number=user_data["phone_number"],
            password=user_data["password"],
            interest=user_data["interest"]
        )
        await self.user_repo.save()
        await redis_client.delete(f"register_otp:{email}")

        return {"message": "User registered successfully", "user_id": new_user.id}

    async def resend_otp(self, email: str) -> dict:

        cooldown = await redis_client.get(f"resend_cooldown:{email}")
        if cooldown:
            raise ApplicationError("Please wait 60 seconds before requesting a new OTP.", status_code=429)

        data_str = await redis_client.get(f"register_otp:{email}")
        if not data_str:
            raise ApplicationError("Session expired. Please register again.", status_code=400)

        data = json.loads(data_str)
        user_data = data["user_data"]

        otp = generate_otp()
        await save_pending_user(email, user_data, otp)
        await redis_client.setex(f"resend_cooldown:{email}", 60, "1")

        email_service = EmailService()
        _email_sent_task = asyncio.create_task(email_service.send_otp_email(email, otp))

        return {"message": "New OTP sent to email", "expires_in": 180}

    async def login_user(self, email: str, password: str) -> dict:
        user = await self.user_repo.get_by_email(email)
        if not user or not verify_password(password, user.password):
            raise ApplicationError("Incorrect email or password", status_code=401)

        if not user.is_active:
            raise ApplicationError("Your account has been suspended", status_code=403)

        token = create_access_token({"sub": user.email, "type": "user"})
        return {
            "message": "User login successful",
            "access_token": token,
        }

    async def login_admin(self, email: str, password: str) -> dict:
        admin_user = await self.admin_repo.get_by_email(email)
        if not admin_user or not verify_password(password, admin_user.password):
            raise ApplicationError("Incorrect email or password", status_code=401)

        token = create_access_token({"sub": admin_user.email, "type": "admin"})
        return {
            "message": "Admin login successful",
            "access_token": token,
        }

    async def register_admin(self, data) -> dict:
        existing = await self.admin_repo.get_by_email(data.email)
        if existing:
            raise ApplicationError("Email already registered", status_code=409)

        hashed_password = hash_password(data.password)
        admin = await self.admin_repo.create_admin(
            name=data.name,
            email=data.email,
            password=hashed_password
        )
        await self.admin_repo.save()
        return {"message": "Admin registered successfully", "admin_id": admin.id}

    async def get_user_profile(self, user_id: int) -> dict:
        user = await self.user_repo.get_by_id(user_id)
        if not user:
            raise ApplicationError("User not found", status_code=404)

        return {
            "id": user.id,
            "name": user.name,
            "email": user.email,
            "interest": user.interest,
            "phone_number": user.phone_number
        }
