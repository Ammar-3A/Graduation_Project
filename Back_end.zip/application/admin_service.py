from persistence.repository import AdminRepository, UserRepository, PostRepository, ReportRepository
from application.exceptions import ApplicationError
import time


class AdminService:
    def __init__(
            self,
            user_repo: UserRepository,
            post_repo: PostRepository,
            report_repo: ReportRepository,
            admin_repo: AdminRepository
    ):
        self.user_repo = user_repo
        self.post_repo = post_repo
        self.report_repo = report_repo
        self.admin_repo = admin_repo

    async def get_all_users(self) -> dict:
        users = await self.user_repo.get_all()
        return {
            "users": [
                {
                    "id": user.id,
                    "name": user.name,
                    "email": user.email,
                    "interest": user.interest,
                    "is_active": user.is_active
                }
                for user in users
            ]
        }

    async def get_all_posts(self) -> dict:
        posts = await self.post_repo.get_all_with_seller()
        return {
            "posts": [
                {
                    "id": post.id,
                    "item_name": post.item_name,
                    "price": post.price,
                    "category": post.category,
                    "description": post.description,
                    "image": post.image,
                    "seller_id": post.seller.id,
                    "seller_name": post.seller.name,
                    "seller_email": post.seller.email,
                    "seller_phone": post.seller.phone_number
                }
                for post in posts
            ]
        }

    async def get_all_reports(self) -> dict:
        reports = await self.report_repo.get_unresolved()
        return {
            "reports": [
                {
                    "id": report.id,
                    "reporter_id": report.reporter_id,
                    "item_id": report.item_id,
                    "reason": report.reason,
                    "post_status": "Deleted" if report.post.is_deleted else "Active",
                }
                for report in reports
            ]
        }

    async def get_stats(self) -> dict:
        return await self.admin_repo.get_stats()

    async def suspend_user(self, user_id: int) -> dict:
        user = await self.user_repo.get_by_id(user_id)
        if not user:
            raise ApplicationError("User not found", status_code=404)
        await self.user_repo.toggle_active_status(user_id, False)
        await self.user_repo.save()

        return {"message": f"User {user_id} suspended successfully"}

    async def activate_user(self, user_id: int) -> dict:
        user = await self.user_repo.get_by_id(user_id)
        if not user:
            raise ApplicationError("User not found", status_code=404)
        await self.user_repo.toggle_active_status(user_id, True)
        await self.user_repo.save()

        return {"message": f"User {user_id} activated successfully"}

    async def delete_user(self, user_id: int) -> dict:
        await self.user_repo.delete_by_id(user_id)
        await self.user_repo.save()

        return {"message": "User deleted successfully"}

    async def delete_post(self, post_id: int) -> dict:
        post = await self.post_repo.get_by_id(post_id)

        if not post:
            raise ApplicationError("Post not found", status_code=404)

        if post.is_deleted:
            raise ApplicationError("Post already deleted", status_code=400)

        await self.post_repo.delete_by_id(post_id)
        await self.post_repo.save()

        return {"message": "Post deleted successfully"}

    async def get_monitoring_status(self) -> dict:
        start_time = time.time()
        try:
            await self.admin_repo.get_stats()
            db_connected = True
        except Exception:
            db_connected = False

        latency = (time.time() - start_time) * 1000

        return {
            "status": "running",
            "db_connected": db_connected,
            "latency": round(latency, 2)
        }

    async def resolve_report(self, report_id: int) -> dict:
        report = await self.report_repo.get_by_id(report_id)
        if not report:
            raise ApplicationError("Report not found", status_code=404)

        is_resolved = await self.report_repo.resolve_report(report_id)

        if is_resolved:
            await self.report_repo.save()

        return {"message": f"Report {report_id} resolved"}

    async def get_admin_profile(self, admin_id: int) -> dict:
        admin = await self.admin_repo.get_by_id(admin_id)
        if not admin:
            raise ApplicationError("Admin not found", status_code=404)

        return {
            "id": admin.id,
            "name": admin.name,
            "email": admin.email
        }
