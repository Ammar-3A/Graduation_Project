from dataclasses import dataclass, field
from typing import List, Optional, Dict, Union, Callable
from .condition import *


@dataclass
class FlowStep:
    # Represents a single step in a flow.
    # Example: the "price" step in the post flow:
    # FlowStep(
    #     prompt="What is the price of your item?",
    #     data_key="price",        # the key used to store the user's input
    #     transition="description", # the next step to go to after this one
    #     validators=[NumberCondition(...)],
    #     async_validator=None
    # )
    prompt: str
    data_key: Optional[str] = None
    transition: Optional[Union[str, Callable]] = None
    validators: List[Condition] = field(default_factory=list)
    async_validator: Optional[str] = None


@dataclass
class FlowDef:
    # Represents a full conversation flow.
    # Contains all the steps, the starting step, and the action to run when the flow completes.
    steps: Dict[str, FlowStep]
    start_step: str = "start"
    finish_action: Optional[str] = None


buy_flow = FlowDef(
    steps={
        "start": FlowStep(
            prompt="Please enter the Post ID you want to buy:",
            data_key="post_id",
            transition="quantity",
            validators=[
                NumberCondition(error_msg="Post ID must be a number. Please try again.")
            ],
            async_validator="check_not_own_post"
        ),
        "quantity": FlowStep(
            prompt="Please enter the quantity you want to buy:",
            data_key="quantity",
            transition="confirm",
            validators=[
                NumberCondition(error_msg="Quantity must be a number. Please try again.")
            ],
        ),
        "confirm": FlowStep(
            prompt="Type 'yes' to confirm your buy, or 'cancel' to stop.",
            data_key=None,
            transition="end",
            validators=[
                ConfirmCondition(error_msg="Please type 'yes' to confirm or 'cancel' to stop.")
            ]
        )
    },
    start_step="start",
    finish_action="create_request"
)

compare_flow = FlowDef(
    steps={
        "start": FlowStep(
            prompt="Enter the first Post ID to compare:",
            data_key="post_id_1",
            transition="second_post",
            validators=[
                NumberCondition(error_msg="Post ID must be a number. Please try again.")
            ],
            async_validator="check_post_exists"
        ),
        "second_post": FlowStep(
            prompt="Enter the second Post ID to compare:",
            data_key="post_id_2",
            transition="end",
            validators=[
                NumberCondition(error_msg="Post ID must be a number. Please try again.")
            ],
            async_validator="check_post_exists"
        )
    },
    start_step="start",
    finish_action="compare_posts"
)

post_flow = FlowDef(
    steps={
        "start": FlowStep(
            prompt="What is the title of your post?",
            data_key="item_name",
            transition="category",
            validators=[
                MinLengthCondition(3, error_msg="Title must be at least 3 characters.")
            ]
        ),
        "category": FlowStep(
            prompt="Select a category for your post: Lab equipment, Clothing, or Electronics.",
            data_key="category",
            transition="price",
            validators=[
                ChoiceCondition(
                    choices=["lab equipment", "clothing", "electronics"],
                    error_msg="Invalid category. Please choose from: Lab equipment, Clothing, or Electronics."
                )
            ]
        ),
        "price": FlowStep(
            prompt="What is the price of your item? (numbers only)",
            data_key="price",
            transition="description",
            validators=[
                NumberCondition(error_msg="Price must be a valid number. Please try again.")
            ]
        ),
        "description": FlowStep(
            prompt="Provide a clear description for your item (at least 20 characters):",
            data_key="description",
            transition="quantity",
            validators=[
                MinLengthCondition(20, error_msg="Description must be at least 20 characters.")
            ]
        ),
        "quantity": FlowStep(
            prompt="Enter the available quantity for this item:",
            data_key="quantity",
            transition="image",
            validators=[
                NumberCondition(error_msg="Quantity must be a number."),
            ]
        ),
        "image": FlowStep(
            prompt="Upload an image for your item:",
            data_key="image",
            transition="confirm",
            validators=[]
        ),
        "confirm": FlowStep(
            prompt="Type 'yes' to confirm and publish your post, or 'cancel' to stop.",
            data_key=None,
            transition="end",
            validators=[
                ConfirmCondition(error_msg="Please type 'yes' to confirm or 'cancel' to stop.")
            ]
        )
    },
    start_step="start",
    finish_action="create_post",
)

report_flow = FlowDef(
    steps={
        "start": FlowStep(
            prompt="Enter the Post ID you want to report:",
            data_key="report_item_id",
            transition="reason",
            validators=[
                NumberCondition(error_msg="Post ID must be a number. Please try again.")
            ],
            async_validator="check_not_own_post"
        ),
        "reason": FlowStep(
            prompt="Please provide a reason for reporting this post (at least 10 characters):",
            data_key="report_reason",
            transition="end",
            validators=[
                MinLengthCondition(10, error_msg="Reason must be at least 10 characters.")
            ]
        )
    },
    start_step="start",
    finish_action="report_post"
)

search_flow = FlowDef(
    steps={
        "start": FlowStep(
            prompt="Which category would you like to search? Lab equipment, Clothing, or Electronics.",
            data_key="category",
            transition="name",
            validators=[
                ChoiceCondition(
                    choices=["lab equipment", "clothing", "electronics"],
                    error_msg="Invalid category. Please choose from: Lab equipment, Clothing, or Electronics."
                )
            ]
        ),
        "name": FlowStep(
            prompt="What is the name of the item you are looking for? (Type 'skip' to search by category only)",
            data_key="item_name",
            transition="end",
            validators=[
                MinLengthCondition(1, error_msg="Item name must be at least 2 characters.")
            ]
        ),
    },
    start_step="start",
    finish_action="search_post",
)

edit_post_flow = FlowDef(
    steps={
        "start": FlowStep(
            prompt="Enter the ID of the post you want to edit:",
            data_key="post_id",
            transition="select_field",
            validators=[
                NumberCondition(error_msg="Post ID must be a number. Please try again.")
            ],
            async_validator="check_own_post"
        ),
        "select_field": FlowStep(
            prompt="What would you like to update? Choose from: Item name, Quantity, Price, Description, Category, or Image.",
            data_key=None,
            validators=[
                ChoiceCondition(
                    choices=["item name", "price", "description", "category", "image", "quantity"],
                    error_msg="Invalid choice. Please select from: Item name, Price, Description, Category, or Image."
                )
            ],
            transition=lambda choice: choice,
        ),
        "item name": FlowStep(
            prompt="Enter the new item name:",
            data_key="item_name",
            transition="confirm",
            validators=[
                MinLengthCondition(min_length=3, error_msg="Item name must be at least 3 characters.")
            ]
        ),
        "price": FlowStep(
            prompt="Enter the new price: (numbers only)",
            data_key="price",
            transition="confirm",
            validators=[
                NumberCondition(error_msg="Price must be a valid number. Please try again.")
            ]
        ),
        "description": FlowStep(
            prompt="Enter the new description (at least 10 characters):",
            data_key="description",
            transition="confirm",
            validators=[
                MinLengthCondition(min_length=10, error_msg="Description must be at least 10 characters.")
            ]
        ),
        "category": FlowStep(
            prompt="Enter the new category: Lab equipment, Clothing, or Electronics.",
            data_key="category",
            transition="confirm",
            validators=[
                ChoiceCondition(
                    choices=["lab equipment", "clothing", "electronics"],
                    error_msg="Invalid category. Please choose from: Lab equipment, Clothing, or Electronics."
                )
            ]
        ),
        "image": FlowStep(
            prompt="Upload the new image for your post:",
            data_key="image",
            transition="confirm",
            validators=[]
        ),
        "quantity": FlowStep(
            prompt="Please enter the value of the new quantity:",
            data_key="quantity",
            transition="confirm",
            validators=[]
        ),
        "confirm": FlowStep(
            prompt="Type 'yes' to confirm your changes, or 'cancel' to stop.",
            data_key=None,
            transition="end",
            validators=[
                ConfirmCondition(error_msg="Please type 'yes' to confirm or 'cancel' to stop.")
            ]
        )
    },
    start_step="start",
    finish_action="update_post",
)

delete_post_flow = FlowDef(
    steps={
        "start": FlowStep(
            prompt="Enter the ID of the post you want to delete:",
            data_key="post_id",
            transition="confirm",
            validators=[
                NumberCondition(error_msg="Post ID must be a number. Please try again.")
            ],
            async_validator="check_own_post"
        ),
        "confirm": FlowStep(
            prompt="Are you sure you want to delete this post? Type 'yes' to confirm or 'cancel' to stop.",
            data_key=None,
            transition="end",
            validators=[
                ConfirmCondition(error_msg="Please type 'yes' to confirm or 'cancel' to stop.")
            ]
        )
    },
    start_step="start",
    finish_action="delete_post"
)
