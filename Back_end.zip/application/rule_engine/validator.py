from dataclasses import dataclass
from enum import Enum


class ValidationStatus(Enum):
    PASSED = "passed"
    REJECTED = "rejected"


@dataclass
class ValidationResult:
    status: ValidationStatus
    error_msg: str = None


class Validator:
    def __init__(self, step):
        self.step = step

    def validate(self, user_input: str):
        # Each step has a list of validators.
        # If any of them fails, we stop immediately and return REJECTED.
        # If all pass, we return PASSED.
        # Example: the "start" step in buy_flow has one validator:
        # validators=[NumberCondition(error_msg="Post ID must be a number. Please try again.")]
        # If the user enters "abc", NumberCondition fails and we return REJECTED.
        for validator in self.step.validators:
            is_valid, error_msg = validator.validate(user_input)
            if not is_valid:
                return ValidationResult(
                    status=ValidationStatus.REJECTED,
                    error_msg=error_msg
                )

        return ValidationResult(status=ValidationStatus.PASSED)
