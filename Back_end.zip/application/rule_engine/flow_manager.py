from __future__ import annotations

from enum import Enum

from application.action_service import ActionContext
from application.exceptions import ActionError
from .flow_def import *
from .validator import Validator, ValidationStatus
from dataclasses import dataclass, field, asdict
from typing import Optional, Dict, Any
from rapidfuzz import process

# Maps each flow_key to its corresponding FlowDef (e.g. post_flow, buy_flow, etc...)
FLOW_DEF = {
    "create post": post_flow,
    "search": search_flow,
    "compare": compare_flow,
    "report": report_flow,
    "buy": buy_flow,
    "edit post": edit_post_flow,
    "delete post": delete_post_flow,
}

KNOWN_COMMANDS = [
    "create post", "search", "compare", "report",
    "buy", "edit post", "delete post",
    "my posts", "my requests", "recommendation"
]

KNOWN_CATEGORIES = [
    "electronics", "lab equipment", "clothes",
]

KNOWN_FIELDS = [
    "item name", "quantity", "price", "description", "category", "image"
]


def correct_command(value: str, commands: list[str], threshold: int = 75) -> str:
    value = value.strip().lower()
    match, score, _ = process.extractOne(value, commands)
    return match if score >= threshold else value


class OutcomeStatus(str, Enum):
    SUCCESS = "success"
    FAILED = "failed"
    TERMINATED = "terminated"
    ERROR = "error"


@dataclass
class FlowState:
    # Tracks the current state of an active conversation flow.
    #
    # Example:
    # FlowState(
    #   flow_key='post',
    #   current_step='price',
    #   user_responses={
    #     'item_name': 'HP Pavilion x360 Laptop',
    #     'category': 'electronics'
    #   },
    #   attempts=0
    # )
    #
    # The attempts field counts invalid inputs.
    # The flow automatically ends if the maximum number of attempts is reached (MAX_ATTEMPTS = 3).

    flow_key: str
    current_step: str
    user_responses: Dict[str, Any] = field(default_factory=dict)
    attempts: int = 0

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    # Create a new FlowState for the next step with updated data.
    def next(self, next_step: str, collected_data: Dict[str, Any]) -> FlowState:
        return FlowState(
            flow_key=self.flow_key,
            current_step=next_step,
            user_responses=collected_data,
        )

    # this method returns a new FlowState with the attempts counter incremented by 1.
    def increment_attempts(self) -> FlowState:
        return FlowState(
            flow_key=self.flow_key,
            current_step=self.current_step,
            user_responses=self.user_responses,
            attempts=self.attempts + 1,
        )


@dataclass
class Outcome:
    # Represents the result of processing a single user input.
    # status: indicates whether the step passed, failed, terminated, or errored.
    # messages: list of messages to send back to the user.
    # flow_state: the updated flow state to persist (None if the flow has ended).
    # data: any final data returned after a flow completes (e.g. created post info).

    status: OutcomeStatus
    messages: list[str] = field(default_factory=list)
    flow_state: Optional[FlowState] = None
    data: Optional[Dict[str, Any]] = None


class FlowManager:
    MAX_ATTEMPTS = 3

    def __init__(self, action_service):
        self.action_service = action_service
        self.flows = FLOW_DEF

        # Quick actions are actions that don't require a multi-steps conversation.
        # They are executed immediately and return a result without multi-steps conversation.
        # Example: "my posts" -> directly fetches and returns the user's listings.
        self._quick_actions = {
            "my posts": "user_posts",
            "my requests": "user_requests",
            "recommendation": "user_recommendations",
        }

        # Async validators are used at specific steps to validate input against the database.
        # Unlike simple field-level validators (e.g. minimum length),
        # these perform asynchronous database checks such as:
        # - Does this post actually exist?
        # - Does the user own this post?
        # - Is the user trying to buy their own post?

        self._async_validators = {
            "check_post_exists": action_service.validate_post_exists,
            "check_own_post": action_service.validate_post_ownership,
            "check_not_own_post": action_service.validate_post_not_owner,
        }

    # This method evaluates every incoming message to either continue an active flow, trigger a quick action,
    # or start a new conversation flow.
    async def handle_input(self, message: str, flow_state: FlowState, user_id: int) -> Outcome:

        message = message.strip().lower()

        # If the user wants to cancel, terminate the active flow immediately.
        # If there's no active flow, just notify the user there's nothing to cancel.

        if message == "cancel":
            if flow_state:
                return Outcome(status=OutcomeStatus.TERMINATED, messages=["Process cancelled."])
            return Outcome(status=OutcomeStatus.SUCCESS, messages=["Nothing to cancel."])

        # If there's an active flow, continue processing the current step and correct the spelling in specific steps.
        if flow_state:
            if flow_state.current_step == "category" or (
                    flow_state.flow_key == "search" and flow_state.current_step == "start"):
                message = correct_command(message, KNOWN_CATEGORIES)
                print(f"# Debug (category, select field): ", message)
            elif flow_state.flow_key == "search" and flow_state.current_step == "name":
                message = correct_command(message, ["skip"])
                print(f"# Debug (Skip, for search): ", message)
            elif flow_state.current_step == "select_field":
                message = correct_command(message, KNOWN_FIELDS)
                print(f"# Debug (Fields): ", message)

            return await self._evaluate_step(message, flow_state, user_id)

        message = correct_command(message, KNOWN_COMMANDS)
        print(f"# Debug (if there is not state work): ", message)

        # If the message maps to a quick action (e.g. "my posts", "recommendation"),
        # execute it directly and return the result without starting a flow.
        if message in self._quick_actions:
            result = await self.action_service.execute(self._quick_actions.get(message), ActionContext(user_id))
            return Outcome(status=OutcomeStatus.TERMINATED, data=result)

        # If the message maps to a known  conversation flow (e.g. "create post", "buy", "search"),
        # initialize the flow and return the first step's prompt to the user.
        if message in self.flows:
            flow = self.flows[message]
            first_step = flow.steps[flow.start_step]
            return Outcome(
                status=OutcomeStatus.SUCCESS,
                messages=[first_step.prompt],
                flow_state=FlowState(flow_key=message, current_step=flow.start_step),
            )

        # If the message doesn't match any known flow keys, return a helpful error message.
        return Outcome(
            status=OutcomeStatus.ERROR,
            messages=[f"I am not sure what you mean by '{message}'. Type 'help' to see my commands."],
        )

    # Evaluates user input by running validations, saving valid data, and determining the next step.
    async def _evaluate_step(self, user_input: str, state: FlowState, user_id: int) -> Outcome:
        flow = self.flows[state.flow_key]
        current_step = flow.steps[state.current_step]

        # Validate the user's input using the step's simple field-level validators (e.g. min length, format).
        # Example: for the "title" step -> MinLengthCondition(3, error_msg="...")
        # If validation fails, handle the failed attempt (track retries, possibly terminate).
        validation = Validator(current_step).validate(user_input)
        if validation.status == ValidationStatus.REJECTED:
            return self._handle_failed_attempt(validation.error_msg, state)

        # If the step has an async validator, run it against the database.
        # Example: for the "edit post" flow, we check that the post_id provided by the user
        # actually exists and belongs to them before continuing.
        # If the async check fails, we treat it the same as a local validation failure.
        if current_step.async_validator:
            try:
                await self._async_validators[current_step.async_validator](user_input, user_id)
            except ActionError as e:
                return self._handle_failed_attempt(e.message, state)

        # We copy the data collected from previous steps, then add the current step's input.
        # Example before: {'item_name': 'HP Pavilion'}
        # Example after:  {'item_name': 'HP Pavilion', 'post_category': 'electronics'}
        collected_data = {**state.user_responses}
        if current_step.data_key:
            collected_data[current_step.data_key] = user_input

        # The transition can be a static string (e.g. 'price') or a callable
        # that decides the next step dynamically based on the user's input.
        # Example: in the "edit post" flow, "select_field" uses a lambda that routes
        # the user to the step matching their choice:
        # user types "price" -> goes to "price" step
        # user types "description" -> goes to "description" step
        transition = current_step.transition
        next_step = transition(user_input) if callable(transition) else transition

        # If there's no next step defined, or the next step doesn't exist in the flow,
        # the flow is complete and then execute the finish action and return the result.
        if not next_step or next_step not in flow.steps:
            return await self._complete_flow(flow, collected_data, user_id)

        # Move to the next step and return its prompt to the user.
        step = flow.steps[next_step]
        return Outcome(
            status=OutcomeStatus.SUCCESS,
            messages=[step.prompt],
            flow_state=state.next(next_step, collected_data),
        )

    # this method handles failed attempts and terminates the flow if the maximum limit is exceeded.
    def _handle_failed_attempt(self, error_msg: str, state: FlowState) -> Outcome:
        # Increase attempts in FlowState by one.
        updated_state = state.increment_attempts()

        # If the user has reached the maximum number of attempts, terminate the flow.
        # This is important to prevent abuse or infinite retry loops.
        if updated_state.attempts >= self.MAX_ATTEMPTS:
            return Outcome(
                status=OutcomeStatus.TERMINATED,
                messages=[f"{error_msg}\n\nToo many attempts. The process has been cancelled."],
            )

        # Otherwise, notify the user of the error and how many attempts they have left.
        remaining = self.MAX_ATTEMPTS - updated_state.attempts
        return Outcome(
            status=OutcomeStatus.FAILED,
            messages=[
                f"{error_msg}\n"
                f"You have {remaining} attempt(s) remaining out of {self.MAX_ATTEMPTS}.\n\n"
                f"Please enter a valid value or type 'cancel' to exit."
            ],
            flow_state=updated_state,
        )

    # This method executes the flow's finish (e.g, "create_post") action by passing the collected_data (user responses).
    async def _complete_flow(self, flow: FlowDef, collected_data: dict, user_id: int) -> Outcome:

        # In normal cases, every flow has a finish_action defined.
        # If not, we simply return the collected data as-is and terminate.
        if not flow.finish_action:
            return Outcome(status=OutcomeStatus.TERMINATED, data=collected_data)
        try:
            # Execute the flow's finish action (e.g. create_post, report_post)
            # and pass all the data collected across the flow's steps.
            result = await self.action_service.execute(
                flow.finish_action,
                ActionContext(user_id, collected_data),
            )
            return Outcome(status=OutcomeStatus.TERMINATED, data=result)
        except ActionError as e:
            return Outcome(
                status=OutcomeStatus.ERROR,
                messages=[f"Error: {e.message}. The process has been cancelled."],
            )
