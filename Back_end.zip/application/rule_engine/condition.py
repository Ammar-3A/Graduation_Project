from typing import Any


class Condition:
    def __init__(self, error_msg: str = "Invalid input"):
        self.error_msg = error_msg

    def validate(self, value: Any):
        if self.check(value):
            return True, ""
        return False, self.error_msg

    def check(self, value: Any):
        raise NotImplementedError


class MinLengthCondition(Condition):
    def __init__(self, min_length: int, error_msg: str):
        super().__init__(error_msg)
        self.min_length = min_length

    def check(self, value):
        if value is None:
            return False
        return len(str(value)) >= self.min_length


class NumberCondition(Condition):
    def check(self, value):
        if not str(value).isdigit():
            return False
        return int(value) > 0


class ChoiceCondition(Condition):
    def __init__(self, choices: list, error_msg: str = None):
        super().__init__(error_msg)
        self.choices = [str(c).lower().strip() for c in choices]

    def check(self, value):
        return str(value).lower().strip() in self.choices


class ConfirmCondition(Condition):
    def check(self, value):
        return str(value).lower().strip() == "yes"
