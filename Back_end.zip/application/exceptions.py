class ApplicationError(Exception):
    def __init__(self, message: str, status_code: int):
        self.message = message
        self.status_code = status_code
        super().__init__(self.message)


class ActionError(Exception):
    def __init__(self, message: str):
        self.message = message
        super().__init__(self.message)
