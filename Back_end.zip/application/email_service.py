import aiosmtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from dataclasses import dataclass

from application.exceptions import ApplicationError
from core.config import settings

@dataclass
class RequestEmailData:
    seller_email: str
    seller_phone: str
    seller_name: str
    buyer_name: str
    item_name: str
    quantity: int
    price: int
    request_id: int

class EmailService:
    def __init__(self):
        self.gmail = settings.GMAIL_ADDRESS
        self.password = settings.GMAIL_APP_PASSWORD

    async def send_request_notification(self, data: RequestEmailData) -> bool:
        try:
            total = data.price * data.quantity

            html = f"""
            <div style="font-family: Arial, sans-serif; max-width: 600px; margin: auto; padding: 24px;">
                <h2 style="color: #2d6a4f;"># New Purchase Request | TUMB APP</h2>
                <p>Hi <strong>{data.seller_name}</strong>,</p>
                <p>You have received a new purchase request from <strong>{data.buyer_name}</strong>.</p>

                <table style="width: 100%; border-collapse: collapse; margin-top: 16px;">
                    <tr style="background: #f4f4f4;">
                        <td style="padding: 10px; border: 1px solid #ddd;"><strong>Item</strong></td>
                        <td style="padding: 10px; border: 1px solid #ddd;">{data.item_name}</td>
                    </tr>
                    <tr>
                        <td style="padding: 10px; border: 1px solid #ddd;"><strong>Quantity</strong></td>
                        <td style="padding: 10px; border: 1px solid #ddd;">{data.quantity}</td>
                    </tr>
                    <tr style="background: #f4f4f4;">
                        <td style="padding: 10px; border: 1px solid #ddd;"><strong>Price per unit</strong></td>
                        <td style="padding: 10px; border: 1px solid #ddd;">{data.price} SAR</td>
                    </tr>
                    <tr>
                        <td style="padding: 10px; border: 1px solid #ddd;"><strong>Total</strong></td>
                        <td style="padding: 10px; border: 1px solid #ddd;"><strong>{total} SAR</strong></td>
                    </tr>
                    <tr style="background: #f4f4f4;">
                        <td style="padding: 10px; border: 1px solid #ddd;"><strong>Request ID</strong></td>
                        <td style="padding: 10px; border: 1px solid #ddd;">#{data.request_id}</td>
                    </tr>
                    <tr>
                        <td style="padding: 10px; border: 1px solid #ddd;"><strong>Seller Email</strong></td>
                        <td style="padding: 10px; border: 1px solid #ddd;">{data.seller_email}</td>
                    </tr>
                    <tr style="background: #f4f4f4;">
                        <td style="padding: 10px; border: 1px solid #ddd;"><strong>Seller Phone</strong></td>
                        <td style="padding: 10px; border: 1px solid #ddd;">{data.seller_phone}</td>
                    </tr>
                </table>

                <p style="margin-top: 24px; color: #555;">
                    Please follow up with the buyer to complete the transaction.
                </p>
                <p style="color: #d32f2f; font-size: 12px; margin-bottom: 4px;">
                    <strong>Important Note:</strong> This message is part of a university graduation project testing phase. It may contain errors or unexpected behavior. If you are not the intended recipient, please disregard this message.
                </p>
                <p style="color: #999; font-size: 12px;">This is an automated message. Do not reply directly to this email.</p>
            </div>
            """

            msg = MIMEMultipart('alternative')
            msg['Subject'] = f"New Purchase Request: {data.item_name} | TUMB APP"
            msg['From'] = f"TUMB APP <{self.gmail}>"
            msg['To'] = data.seller_email
            msg.attach(MIMEText(html, 'html'))

            await aiosmtplib.send(
                msg,
                hostname="smtp.gmail.com",
                port=465,
                use_tls=True,
                username=self.gmail,
                password=self.password
            )

            return True

        except Exception as e:
            print(f"[EmailService] Failed to send email: {e}")
            return False

    async def send_otp_email(self, email: str, otp: str) -> bool:
        try:
            html = f"""
            <div style="font-family: Arial, sans-serif; max-width: 600px; margin: auto; padding: 24px;">
                <h2 style="color: #2d6a4f;"># Verify Your Email | TUMB APP</h2>
                <p>Welcome to TUMB APP!</p>
                <p>Please use the following One-Time Password (OTP) to complete your registration:</p>
                <div style="background: #f4f4f4; padding: 16px; margin: 24px 0; text-align: center; font-size: 24px; font-weight: bold; letter-spacing: 4px; color: #333; border-radius: 8px;">
                    {otp}
                </div>
                <p style="color: #555;">This code will expire in 3 minutes.</p>
                <p style="color: #d32f2f; font-size: 12px; margin-bottom: 4px;">
                    <strong>Important Note:</strong> This message is part of a university graduation project testing phase. It may contain errors or unexpected behavior. If you are not the intended recipient, please disregard this message.
                </p>
                <p style="color: #999; font-size: 12px;">This is an automated message. Do not reply directly to this email.</p>
            </div>
            """

            msg = MIMEMultipart('alternative')
            msg['Subject'] = "Your Verification Code | TUMB APP"
            msg['From'] = f"TUMB APP <{self.gmail}>"
            msg['To'] = email
            msg.attach(MIMEText(html, 'html'))

            await aiosmtplib.send(
                msg,
                hostname="smtp.gmail.com",
                port=465,
                use_tls=True,
                username=self.gmail,
                password=self.password
            )
            return True
        except Exception as e:
            print(f"[EmailService] Failed to send OTP email: {e}")
            raise ApplicationError(
                "Failed to send verification email. Please try again later.",
                status_code=500
            )