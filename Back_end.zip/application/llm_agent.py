"""
TUMB LLM Agent

Initialised once at startup.
The same agent instance is reused for every chat request.
"""
import json
import os
import sys
from typing import Any

from langchain_anthropic import ChatAnthropic
from langchain_core.messages import SystemMessage, HumanMessage, AIMessage, ToolMessage
from langchain_mcp_adapters.client import MultiServerMCPClient
from langgraph.prebuilt import create_react_agent

from core.config import settings

# Make the Anthropic API key available to LangChain
os.environ["ANTHROPIC_API_KEY"] = settings.ANTHROPIC_API_KEY

# MCP server path 

MCP_SERVER_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "mcp_server", "server.py"
)

# system prompt template 
# user_id and name are filled in per-request so the agent always knows who it's talking to.

SYSTEM_PROMPT = """\
You are TUMB Assistant — a friendly AI helper for the Taibah University Marketplace.
You help Taibah University students buy, sell, and manage academic items on campus.

The current user's ID is {user_id} and their name is {name}.

What you can do (via tools):
- Search listings by name or category
- Create a new listing to sell an item
- Send a purchase request to a seller
- Compare two listings and recommend the best value
- Report an inappropriate listing
- Update or delete the user's own listing
- Show the user's own listings and purchase requests
- Show personalised recommendations

Important rules:
- Always call a tool when the user asks about listings or marketplace data.
- Never make up post IDs, prices, or item names — only use what tools return.
- Valid categories are: "lab equipment", "clothing", "electronics".
- Prices are in Saudi Riyals (SAR).
- Respond in the same language the user writes in (Arabic or English).
- You already know the user's ID — never ask them for it.
- Automatically correct spelling mistakes or typos in user requests before passing parameters to tools (e.g., if the user asks for "labtops", search for "laptops" or "laptop").
- App Explanation: If the user asks what the app does, what it offers, or how you can help, explain that TUMB (Taibah University Marketplace) is a platform for students to buy, sell, and manage academic items (like lab equipment, clothing, and electronics). Briefly list out some of your capabilities (searching items, comparing prices, creating listings, etc.) in a friendly, conversational way.

Purchase Flow & Tool Examples (CRITICAL):
1. If a user wants to buy an item, you MUST first know the exact post ID. If you don't know it, use the search tool first.
2. BEFORE calling the buy_post tool, you MUST ask the user to explicitly confirm the purchase by showing them the item name and post ID.
3. When asking for this confirmation, DO NOT call any tools. Just reply with plain text. This ensures no unexpected cards are shown to the user.
4. ABSOLUTE STOP: You are FORBIDDEN from calling the buy_post tool until the user has explicitly replied with "yes", "confirm", or something similar. If the user hasn't explicitly confirmed yet, you MUST NOT call the tool under any circumstances.
5. EXTREMELY IMPORTANT: When the user confirms (e.g., says "yes"), you MUST extract the exact post ID from your previous confirmation message in the conversation history. Use EXACTLY that ID when calling the buy_post tool. DO NOT guess, DO NOT hallucinate a different ID, and DO NOT call the search tool again.

Style rules (CRITICAL — follow these strictly):
- NEVER use markdown formatting. No asterisks, no bold, no italic, no headers, no bullet points with dashes.
- Write in plain text only. Use commas, periods, and line breaks to organize your response.
- Keep responses short and to the point. Two to three sentences is ideal.
- Sound like a helpful friend, not a corporate bot. Be warm and casual.
- Do NOT repeat or list out all the data the tool returned — the user will see it in the card below your message. Just give a brief, friendly summary.
- Example good response: "Found 3 laptops for you! Check them out below."
- Example bad response: "**Here are the results:** I found the following items: \\n- **Laptop** - 500 SAR..."
"""

# MCP tool name → frontend action_name mapping 
# The frontend uses action_name to decide which card component to render.

TOOL_TO_ACTION = {
    "search_posts":        "search_post",
    "get_my_posts":        "user_posts",
    "get_recommendations": "user_recommendations",
    "compare_posts":       "compare_posts",
    "buy_post":            "create_request",
    "get_my_requests":     "user_requests",
    "report_post":         "report_post",
    "create_post":         "create_post",
    "update_post":         "update_post",
    "delete_post":         "delete_post",
}

# agent singleton
# Initialised once at startup, reused for every request.

_agent = None   # the compiled LangGraph agent
_tools = None   # the MCP tools list (kept so we can pass them to bind_tools)


async def init_agent():
    """
    Called once when the app starts.
    Connects to the MCP server, loads the tools, and builds the agent.
    """
    global _agent, _tools

    # Connect to the MCP server subprocess and get its tools as LangChain tools
    mcp_client = MultiServerMCPClient(
        {
            "tumb": {
                "command": sys.executable,        # the same Python that's running the app
                "args":    [MCP_SERVER_PATH],
                "transport": "stdio",             # MCP communicates over stdin/stdout pipes
                "env":     os.environ.copy(),     # pass all env vars (DATABASE_URL etc.)
            }
        }
    )
    _tools = await mcp_client.get_tools()

    # Build the ReAct agent: model + tools
    # create_react_agent handles the loop: call model → run tools → call model → ...
    model  = ChatAnthropic(model="claude-sonnet-4-20250514", max_tokens=1024)
    _agent = create_react_agent(model=model, tools=_tools)


# per-request entry point

async def run_agent(user_id: int, name: str, messages: list[dict[str, Any]]) -> dict:
    """
    Run one conversation turn through the agent.

    Parameters
    ----------
    user_id  : the logged-in user's database ID (injected into the system prompt)
    name     : the user's display name
    messages : full conversation history from the client
               (the last item is the new user message)

    Returns
    -------
    A dict with:
      - "reply": the assistant's text reply
      - "data":  structured tool data for card rendering (or None)
    """

    # Build the message list: system prompt + conversation history
    all_messages = [
        SystemMessage(content=SYSTEM_PROMPT.format(user_id=user_id, name=name)),
        *_history_to_langchain(messages),
    ]

    # Run the agent — LangGraph handles the tool-calling loop automatically
    result = await _agent.ainvoke({"messages": all_messages})

    # The last message in the result is always the final assistant reply
    reply = result["messages"][-1].content
    if not isinstance(reply, str):
        reply = str(reply)

    # Extract structured data from any tool calls the agent made
    tool_data = _extract_tool_data(result["messages"])

    # Save the assistant reply into the history so the client can send it next time
    messages.append({"role": "assistant", "content": reply})
    return {"reply": reply, "data": tool_data}


# tool-data extraction

def _extract_tool_data(messages) -> dict | None:
    """
    Scan the agent's message list for ToolMessage objects and extract the
    last successful tool result that maps to a displayable card type.
    Returns a dict like {"action_name": "search_post", "action_data": {...}}
    or None if no card-worthy data was found.
    """
    last_tool_name = None
    last_tool_result = None

    for msg in messages:
        if not isinstance(msg, ToolMessage):
            continue

        # ToolMessage.content may be a plain JSON string or a list of content blocks
        raw = msg.content
        if isinstance(raw, list):
            raw = " ".join(
                block.get("text", "") if isinstance(block, dict) else str(block)
                for block in raw
            )

        try:
            parsed = json.loads(raw)
        except (json.JSONDecodeError, TypeError):
            continue

        if isinstance(parsed, dict) and "error" not in parsed:
            last_tool_name = msg.name
            last_tool_result = parsed

    if not last_tool_name or not last_tool_result:
        return None

    action_name = TOOL_TO_ACTION.get(last_tool_name)
    if not action_name:
        return None

    return {
        "action_name": action_name,
        "action_data": last_tool_result,
    }


# history conversion

def _history_to_langchain(history: list[dict[str, Any]]) -> list:
    """
    Convert the simple dict history the client sends into LangChain message objects.

    The client stores history as:
        [{"role": "user", "content": "hello"}, {"role": "assistant", "content": "hi!"}]
    """
    result = []
    for msg in history:
        role    = msg.get("role")
        content = msg.get("content", "")

        if role == "user":
            result.append(HumanMessage(content=content))

        elif role == "assistant":
            # Content might be a string or a list of Anthropic content blocks
            if isinstance(content, list):
                # Extract just the text from content blocks
                content = " ".join(
                    block.get("text", "") if isinstance(block, dict) else getattr(block, "text", "")
                    for block in content
                    if (isinstance(block, dict) and block.get("type") == "text")
                    or (hasattr(block, "type") and block.type == "text")
                )
            result.append(AIMessage(content=content))

    return result