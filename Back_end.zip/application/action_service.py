from dataclasses import dataclass, field

from application.email_service import EmailService, RequestEmailData
from application.exceptions import ActionError
from persistence.repository import UserRepository, PostRepository, ReportRepository, RequestRepository
from schemas.pydantic_model import PostUpdate
import asyncio


@dataclass
class ActionContext:
    # A simple container that carries all the data needed to execute an action.
    # Instead of passing user_id and data as separate arguments to every action,
    # we bundle them into a single object for cleaner function signatures.
    # Example:
    # ActionContext(
    #     user_id=42,
    #     data={'item_name': 'HP Laptop', 'price': '500', 'category': 'electronics'}
    # )
    user_id: int
    data: dict = field(default_factory=dict)


class ActionService:

    def __init__(
            self,
            user_repo: UserRepository,
            post_repo: PostRepository,
            report_repo: ReportRepository,
            request_repo: RequestRepository,

    ):

        self.user_repo = user_repo
        self.post_repo = post_repo
        self.report_repo = report_repo
        self.request_repo = request_repo

        # A registry that maps action names (strings) to their handler methods.
        # This allows the FlowManager to trigger actions by name (e.g. "create_post")
        # without needing to know which method handles it.
        # Example: flow.finish_action = "create_post" -> calls self.create_post(ctx)
        self._actions = {
            "create_post": self.create_post,
            "create_request": self.create_request,
            "search_post": self.search_posts,
            "compare_posts": self.compare_posts,
            "report_post": self.report_post,
            "update_post": self.update_post,
            "delete_post": self.delete_post,
            "user_posts": self.get_user_posts,
            "user_requests": self.get_user_requests,
            "user_recommendations": self.get_recommendations,
        }

    async def execute(self, action_name: str, ctx: ActionContext) -> dict:

        # Central dispatcher: finds and runs an action by name.
        # If the action doesn't exist, raise ActionError right away.
        # Expected errors (ActionError) are passed through as-is,
        # while any other unexpected errors are wrapped in ActionError
        # so the caller always gets the same error type.

        if action_name not in self._actions:
            raise ActionError(f"Action '{action_name}' is not found!")
        try:
            result_data = await self._actions[action_name](ctx)
            return {"action_name": action_name, "action_data": result_data}
        except ActionError:
            raise
        except Exception as e:
            print(f"Debug : {e}")
            raise ActionError(f"An internal error occurred during action execution")

    async def create_post(self, ctx: ActionContext) -> dict:
        # Creates a new post using the data collected from the user during the flow.
        # After creation, we call save() to commit the transaction.

        new_post = await self.post_repo.create_post(
            item_name=ctx.data.get("item_name"),
            category=ctx.data.get("category"),
            price=int(ctx.data.get("price")),
            description=ctx.data.get("description"),
            quantity=int(ctx.data.get("quantity")),
            image=ctx.data.get("image"),
            seller_id=ctx.user_id
        )
        await self.post_repo.save()

        return {
            "id": new_post.id,
            "item_name": new_post.item_name,
            "category": new_post.category,
            "price": new_post.price,
            "seller_id": new_post.seller_id
        }

    async def search_posts(self, ctx: ActionContext) -> dict:

        # Searches posts based on the filters provided by the user.
        # We use cursor-based pagination: we fetch (limit + 1) posts,
        # and if we get more than (limit), we know there are more pages.
        # The next_cursor is the ID of the last displayed post, used to fetch the next page.
        # This makes the app faster and prevents the interface from slowing down.
        limit = 4

        keyword = ctx.data.get("item_name")

        posts = await self.post_repo.search(
            user_id=ctx.user_id,
            name=None if keyword == "skip" else keyword,
            category=ctx.data.get("category"),
            last_id=ctx.data.get("last_id"),
            limit=limit + 1
        )
        has_more = len(posts) > limit
        display_posts = posts[:limit]
        next_cursor = display_posts[-1].id if display_posts and has_more else None

        return {
            "posts": [
                {
                    "id": p.id,
                    "item_name": p.item_name,
                    "category": p.category,
                    "price": p.price,
                    "quantity": p.quantity,
                    "description": p.description,
                    "seller_name": p.seller.name,
                    "seller_phone": p.seller.phone_number,
                    "seller_email": p.seller.email,
                    "image": p.image,
                }
                for p in display_posts
            ],
            "count": len(display_posts),
            "has_more": has_more,
            "next_cursor": next_cursor,
            "filters": {
                "item_name": ctx.data.get("item_name"),
                "category": ctx.data.get("category")
            }
        }

    async def compare_posts(self, ctx: ActionContext) -> dict:
        # Fetches two posts by their IDs (provided in ctx) and compares them.
        # The best_choice is simply the post with the lower price.
        p1 = await self.post_repo.get_by_id(int(ctx.data.get("post_id_1")))
        p2 = await self.post_repo.get_by_id(int(ctx.data.get("post_id_2")))

        best_post = p1 if p1.price < p2.price else p2

        return {
            "post1": {"id": p1.id, "item_name": p1.item_name, "category": p1.category,
                      "description": p1.description, "price": p1.price, "image": p1.image},
            "post2": {"id": p2.id, "item_name": p2.item_name, "category": p2.category,
                      "description": p2.description, "price": p2.price, "image": p2.image},
            "best_choice": {
                "id": best_post.id,
                "item_name": best_post.item_name,
                "price": best_post.price,
            }
        }

    async def report_post(self, ctx: ActionContext) -> dict:
        # Submits a report against a post.
        # Before creating the report, we check if the user has already reported
        # this exact post to prevent duplicate reports.
        item_id = int(ctx.data.get("report_item_id"))
        post = await self.post_repo.get_by_id(item_id)

        already_reported = await self.report_repo.has_reported_item(ctx.user_id, item_id)
        if already_reported:
            raise ActionError("You have already reported this post")

        new_report = await self.report_repo.create_report(
            reporter_id=ctx.user_id,
            reported_id=post.seller_id,
            item_id=item_id,
            reason=ctx.data.get("report_reason")
        )
        await self.report_repo.save()

        return {"report_id": new_report.id, "item_id": item_id}

    async def create_request(self, ctx: ActionContext) -> dict:
        # Sends a buy request from the buyer to the seller for a specific post.
        # We check for duplicate requests first to prevent the buyer from
        # sending multiple requests for the same post.
        # On success, we return the seller's contact info so the buyer can reach out.

        post_id = int(ctx.data.get("post_id"))

        post = await self.post_repo.get_by_id(post_id)

        existing_requests = await self.request_repo.has_requested_post(ctx.user_id, post_id)
        if existing_requests:
            raise ActionError(f"You have already sent a request for this post")

        amount = int(ctx.data.get("quantity", 1))
        success = await self.post_repo.decrement_quantity(post_id, amount)
        if not success:
            raise ActionError("Not enough quantity available")

        new_request = await self.request_repo.create_request(
            post_id=post_id,
            buyer_id=ctx.user_id,
            seller_id=post.seller_id,
            quantity=amount
        )
        await self.request_repo.save()

        seller = await self.user_repo.get_by_id(post.seller_id)
        buyer = await self.user_repo.get_by_id(ctx.user_id)

        email_service = EmailService()
        _email_task = asyncio.create_task(
            email_service.send_request_notification(RequestEmailData(
                seller_email=seller.email,
                seller_phone=seller.phone_number,
                seller_name=seller.name,
                buyer_name=buyer.name,
                item_name=post.item_name,
                quantity=amount,
                price=post.price,
                request_id=new_request.id,
            ))
        )

        return {
            "request_id": new_request.id,
            "item_name": post.item_name,
            "post_id": post.id,
            "price": post.price,
            "seller_name": seller.name,
            "seller_phone": seller.phone_number,
            "seller_email": seller.email,
            "quantity": amount
        }

    async def update_post(self, ctx: ActionContext) -> dict:
        # Updates an existing post with the new values provided by the user.
        # We cast price to int separately before building the update parameters,
        # since the user input arrives as a string from the chat flow.
        post_id = int(ctx.data.get("post_id"))

        update_params = PostUpdate(**ctx.data)
        updated_post = await self.post_repo.update_post(post_id, update_params)
        await self.post_repo.save()
        return {"item_name": updated_post.item_name}

    async def get_recommendations(self, ctx: ActionContext) -> dict:
        # Fetches personalized post recommendations based on the user's interest.
        user = await self.user_repo.get_by_id(ctx.user_id)
        posts = await self.post_repo.get_recommendations(ctx.user_id, user.interest, limit=5)
        return {
            "recommendations": [
                {
                    "id": p.id,
                    "item_name": p.item_name,
                    "category": p.category,
                    "price": p.price,
                    "description": p.description,
                    "quantity": p.quantity,
                    "image": p.image,
                    "seller_name": p.seller.name,
                    "seller_phone": p.seller.phone_number,
                    "seller_email": p.seller.email,
                }
                for p in posts
            ],
            "based_on": user.interest,
            "count": len(posts)
        }

    async def get_user_posts(self, ctx: ActionContext) -> dict:
        # Fetches the current user's own posts with cursor-based pagination.
        # Same pagination logic as search_posts: fetch limit+1, check has_more,
        # and return the last ID as next_cursor for the next page request.
        limit = 4
        posts = await self.post_repo.get_by_seller_id(
            seller_id=ctx.user_id,
            last_id=ctx.data.get("last_id"),
            limit=limit + 1
        )
        has_more = len(posts) > limit
        display_posts = posts[:limit]
        next_cursor = display_posts[-1].id if display_posts and has_more else None

        return {
            "posts": [
                {
                    "id": p.id,
                    "item_name": p.item_name,
                    "price": p.price,
                    "category": p.category,
                    "description": p.description,
                    "quantity": p.quantity,
                    "image": p.image,
                    "seller_id": p.seller_id,
                    "seller_name": p.seller.name,
                    "seller_phone": p.seller.phone_number,
                    "seller_email": p.seller.email,
                }
                for p in display_posts
            ],
            "count": len(display_posts),
            "has_more": has_more,
            "next_cursor": next_cursor,
            "filters": {
                "seller_id": ctx.user_id,
                "last_id": ctx.data.get("last_id")
            }
        }

    async def delete_post(self, ctx: ActionContext) -> dict:
        # Deletes a post by its ID.
        # We fetch the post first so we can return its details in the response
        # even after it's deleted (e.g. to confirm to the user what was removed).
        post_id = int(ctx.data.get("post_id"))

        post = await self.post_repo.get_by_id(post_id)

        await self.post_repo.delete_by_id(post_id)
        await self.post_repo.save()

        return {
            "post_id": post.id,
            "item_name": post.item_name,
        }

    async def get_user_requests(self, ctx: ActionContext) -> dict:
        # This method fetches all previous requests from the user.
        requests = await self.request_repo.get_user_requests(ctx.user_id)
        return {
            "requests": [
                {
                    "request_id": r.id,
                    "post_id": r.post_id,
                    "item_name": r.post.item_name,
                    "price": r.post.price,
                    "description": r.post.description,
                    "seller_name": r.seller.name,
                    "seller_phone": r.seller.phone_number,
                    "seller_email": r.seller.email,
                    "quantity": r.quantity,
                    "created_at": r.created_at.isoformat(),
                    "image": r.post.image,
                }
                for r in requests
            ],
            "count": len(requests)
        }

    # Async Validators:
    # Used by FlowManager to check user input at certain steps.
    # Validates the input against the database (e.g., checking ownership) before the flow continues.
    # if failure, they raise ActionError, which FlowManager treats
    # like any local validation error.

    async def validate_post_exists(self, value: str, _user_id: int):
        # Checks that the post ID entered by the user actually exists in the database.
        post_id = int(value)

        post = await self.post_repo.get_by_id(post_id)
        if not post:
            raise ActionError(f"Post with ID {value} does not exist.")
        return post

    async def validate_post_ownership(self, value: str, user_id: int):
        # Checks that the post belongs to the current user.
        # Used in flows like "edit post" or "delete post" to prevent
        # users from modifying posts they don't own.
        post = await self.validate_post_exists(value, user_id)
        if post.seller_id != user_id:
            raise ActionError("You can only perform this action on your own posts.")

    async def validate_post_not_owner(self, value: str, user_id: int):
        # Checks that the current user is NOT the owner of the post.
        # Used in the "buy" flow to prevent a user from sending
        # a purchase request on their own listing.
        post = await self.validate_post_exists(value, user_id)
        if post.seller_id == user_id:
            raise ActionError("You cannot perform this action your own post.")
