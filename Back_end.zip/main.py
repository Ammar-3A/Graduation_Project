from contextlib import asynccontextmanager

from fastapi import FastAPI
from api.v1 import chat, admin, auth
from fastapi.middleware.cors import CORSMiddleware

from persistence.database import close_db
from persistence.redis import close_redis
from application.llm_agent import init_agent


@asynccontextmanager
async def lifespan(_app: FastAPI):
    print("Starting up...")
    await init_agent()
    yield
    print("Shutting down...")
    await close_db()
    await close_redis()


app = FastAPI(lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(chat.router)
app.include_router(auth.router)
app.include_router(admin.router)
