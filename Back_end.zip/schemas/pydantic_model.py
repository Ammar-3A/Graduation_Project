from typing import Dict, Any, Optional, List
from pydantic import BaseModel, EmailStr


class AdminCreate(BaseModel):
    name: str
    email: EmailStr
    password: str


class UserRegister(BaseModel):
    email: EmailStr
    name: str
    phone_number: str
    password: str
    interest: str


class ChatRequest(BaseModel):
    message: str
    mode: str = "rule"
    history: List[Dict[str, Any]] = []


class ChatResponse(BaseModel):
    status: str
    messages: Optional[List[str]] = None
    flow_state: Optional[Dict[str, Any]] = None
    data: Optional[dict] = None


class AuthResponse(BaseModel):
    message: str
    access_token: str | None = None


class RegisterResponse(BaseModel):
    message: str
    expires_in: int


class VerifyOTPRequest(BaseModel):
    email: EmailStr
    otp: str


class ResendOTPRequest(BaseModel):
    email: EmailStr


class PostUpdate(BaseModel):
    item_name: Optional[str] = None
    price: Optional[int] = None
    quantity: Optional[int] = None
    description: Optional[str] = None
    category: Optional[str] = None
    image: Optional[str] = None


class ChatLoadRequest(BaseModel):
    action_name: str
    last_id: Optional[int] = None
    filters: Dict[str, Any] = {}
